/**
 * valueStore.ts
 * Reads values.jsonl written by wcf_value_capture.py and events.jsonl from watcher.
 * Provides a unified view of variable values over time.
 */

import * as fs from 'fs';
import * as path from 'path';
import { getWorkspaceRoot } from './settings';

export interface CapturedValue {
  name: string;
  ts_ns: number;
  type: string;
  repr: string;      // JSON-formatted or repr() string of the Python value
  scope: string;
}

export interface WatcherEvent {
  event_id?: string;
  timestamp_ns: number;
  variable_name: string;
  file?: string;
  line?: number;
  function?: string;
  deltas?: any[];
  thread_id?: number;
  sql_context?: any;
  scope?: string;
}

export interface MergedEvent {
  ts_ns: number;
  varName: string;
  repr: string;       // actual Python value
  type: string;
  scope: string;
  file?: string;
  line?: number;
  fn?: string;
  thread_id?: number;
  sql_context?: any;
}

function readJsonlFile<T>(filePath: string): T[] {
  const result: T[] = [];
  if (!fs.existsSync(filePath)) { return result; }
  try {
    const lines = fs.readFileSync(filePath, 'utf8').split('\n').filter(l => l.trim());
    for (const line of lines) {
      try { result.push(JSON.parse(line)); } catch {}
    }
  } catch {}
  return result;
}

export function loadValuesForVar(outputDir: string, varName: string): CapturedValue[] {
  const values = readJsonlFile<CapturedValue>(path.join(outputDir, 'values.jsonl'));
  return values.filter(v => v.name === varName).sort((a, b) => a.ts_ns - b.ts_ns);
}

export function loadAllValues(outputDir: string): Map<string, CapturedValue[]> {
  const values = readJsonlFile<CapturedValue>(path.join(outputDir, 'values.jsonl'));
  const map = new Map<string, CapturedValue[]>();
  for (const v of values) {
    if (!map.has(v.name)) { map.set(v.name, []); }
    map.get(v.name)!.push(v);
  }
  // Sort each by timestamp
  for (const arr of map.values()) { arr.sort((a, b) => a.ts_ns - b.ts_ns); }
  return map;
}

export function loadWatcherEvents(outputDir: string): Map<string, WatcherEvent[]> {
  const events = readJsonlFile<WatcherEvent>(path.join(outputDir, 'events.jsonl'));
  const map = new Map<string, WatcherEvent[]>();
  for (const ev of events) {
    if (!map.has(ev.variable_name)) { map.set(ev.variable_name, []); }
    map.get(ev.variable_name)!.push(ev);
  }
  for (const arr of map.values()) { arr.sort((a, b) => a.timestamp_ns - b.timestamp_ns); }
  return map;
}

/**
 * Merge values.jsonl and events.jsonl into unified timeline per variable.
 * values.jsonl has the repr; events.jsonl has file/line/thread/sql metadata.
 * We merge by nearest timestamp.
 */
export function mergeForVar(outputDir: string, varName: string): MergedEvent[] {
  const values = loadValuesForVar(outputDir, varName);
  const allEvents = readJsonlFile<WatcherEvent>(path.join(outputDir, 'events.jsonl'))
    .filter(e => e.variable_name === varName)
    .sort((a, b) => a.timestamp_ns - b.timestamp_ns);

  const merged: MergedEvent[] = [];

  for (const val of values) {
    // Find nearest watcher event by timestamp
    let nearest: WatcherEvent | undefined;
    let minDiff = Infinity;
    for (const ev of allEvents) {
      const diff = Math.abs(ev.timestamp_ns - val.ts_ns);
      if (diff < minDiff) { minDiff = diff; nearest = ev; }
    }

    merged.push({
      ts_ns: val.ts_ns,
      varName: val.name,
      repr: val.repr,
      type: val.type,
      scope: val.scope,
      file: nearest?.file,
      line: nearest?.line,
      fn: nearest?.function,
      thread_id: nearest?.thread_id,
      sql_context: nearest?.sql_context,
    });
  }

  // If no values.jsonl data but events exist, show byte delta fallback
  if (merged.length === 0 && allEvents.length > 0) {
    for (const ev of allEvents) {
      const deltaRepr = ev.deltas && ev.deltas.length > 0
        ? '// Byte-level delta\n' + ev.deltas.slice(0, 10).map((d: any) =>
            d.size_change ? `size: ${d.size_change}` : `[${d.offset}]: ${d.before} → ${d.after}`
          ).join('\n')
        : '(no value data)';
      merged.push({
        ts_ns: ev.timestamp_ns,
        varName: ev.variable_name,
        repr: deltaRepr,
        type: 'unknown',
        scope: ev.scope || 'unknown',
        file: ev.file,
        line: ev.line,
        fn: ev.function,
        thread_id: ev.thread_id,
        sql_context: ev.sql_context,
      });
    }
  }

  return merged;
}

export function mergeAllVars(outputDir: string): Map<string, MergedEvent[]> {
  const allValues = loadAllValues(outputDir);
  const allEvents = loadWatcherEvents(outputDir);
  const result = new Map<string, MergedEvent[]>();

  const allVarNames = new Set([...allValues.keys(), ...allEvents.keys()]);
  for (const name of allVarNames) {
    result.set(name, mergeForVar(outputDir, name));
  }
  return result;
}

export function clusterIntoRuns(allVars: Map<string, MergedEvent[]>): Array<Map<string, MergedEvent[]>> {
  // Flatten all events with their varName, sort by time
  const flat: MergedEvent[] = [];
  for (const evs of allVars.values()) { flat.push(...evs); }
  flat.sort((a, b) => a.ts_ns - b.ts_ns);

  if (flat.length === 0) { return []; }

  // Cluster by 1-second gaps
  const runBoundaries: number[] = [0]; // indices where new runs start
  for (let i = 1; i < flat.length; i++) {
    if (flat[i].ts_ns - flat[i - 1].ts_ns > 1e9) { runBoundaries.push(i); }
  }
  runBoundaries.push(flat.length);

  const runs: Array<Map<string, MergedEvent[]>> = [];
  for (let r = 0; r < runBoundaries.length - 1; r++) {
    const runEvents = flat.slice(runBoundaries[r], runBoundaries[r + 1]);
    const byVar = new Map<string, MergedEvent[]>();
    for (const ev of runEvents) {
      if (!byVar.has(ev.varName)) { byVar.set(ev.varName, []); }
      byVar.get(ev.varName)!.push(ev);
    }
    runs.push(byVar);
  }
  return runs;
}

export function getOutputDir(): string {
  const ws = require('./settings').SettingsManager.watcher;
  const wsRoot = getWorkspaceRoot();
  return ws.outputDir || path.join(wsRoot, 'watcher_output');
}
