import * as vscode from 'vscode';
import { scanAllVariables, WorkspaceVariable } from './workspaceScanner';
import { SettingsManager, TrackedVariable } from './settings';

export function openWatcherPanel(ctx: vscode.ExtensionContext) {
  const panel = vscode.window.createWebviewPanel(
    'wcfWatcher',
    'Variables',
    vscode.ViewColumn.Beside,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  let allVars: WorkspaceVariable[] = [];
  let tracked = SettingsManager.trackedVars;

  async function refresh() {
    allVars = await scanAllVariables();
    // Merge with existing tracked settings
    const existingMap = new Map(tracked.map(t => [`${t.file}::${t.name}`, t]));
    panel.webview.html = buildHtml(allVars, existingMap, tracked);
  }

  refresh();

  panel.webview.onDidReceiveMessage((msg) => {
    if (msg.type === 'toggleVar') {
      const key = `${msg.file}::${msg.name}`;
      const existing = tracked.find(t => t.file === msg.file && t.name === msg.name);
      if (existing) {
        existing.enabled = msg.enabled;
      } else {
        const v = allVars.find(v => v.file === msg.file && v.name === msg.name);
        if (v) {
          tracked.push({
            name: v.name,
            file: v.file,
            scope: v.scope,
            trackMode: 'single',
            trackCount: 5,
            enabled: msg.enabled,
          });
        }
      }
      SettingsManager.setTrackedVars(tracked);
    }

    if (msg.type === 'setTrackMode') {
      const existing = tracked.find(t => t.file === msg.file && t.name === msg.name);
      if (existing) {
        existing.trackMode = msg.mode;
        existing.trackCount = msg.count ?? 5;
        SettingsManager.setTrackedVars(tracked);
      }
    }

    if (msg.type === 'setScope') {
      const existing = tracked.find(t => t.file === msg.file && t.name === msg.name);
      const v = allVars.find(v => v.file === msg.file && v.name === msg.name);
      if (existing) {
        existing.scope = msg.scope;
        SettingsManager.setTrackedVars(tracked);
      } else if (v) {
        tracked.push({
          name: v.name, file: v.file, scope: msg.scope,
          trackMode: 'single', trackCount: 5, enabled: true,
        });
        SettingsManager.setTrackedVars(tracked);
      }
    }

    if (msg.type === 'refresh') {
      tracked = SettingsManager.trackedVars;
      refresh();
    }
  });
}

function buildHtml(
  vars: WorkspaceVariable[],
  existingMap: Map<string, TrackedVariable>,
  tracked: TrackedVariable[]
): string {
  // Group by scope category
  const session: WorkspaceVariable[] = [];
  const globals: WorkspaceVariable[] = [];
  const locals: WorkspaceVariable[] = [];

  for (const v of vars) {
    if (v.scope === 'global') { globals.push(v); }
    else if (v.scope === 'local') { locals.push(v); }
    else { session.push(v); } // 'both' shown as session-like
  }

  const varRow = (v: WorkspaceVariable) => {
    const key = `${v.file}::${v.name}`;
    const t = existingMap.get(key);
    const enabled = t?.enabled ?? false;
    const mode = t?.trackMode ?? 'single';
    const count = t?.trackCount ?? 5;
    const scope = t?.scope ?? v.scope;

    return `
    <div class="var-row" id="row-${cssId(key)}">
      <label class="checkbox-wrap">
        <input type="checkbox" class="var-check" data-name="${esc(v.name)}" data-file="${esc(v.file)}"
               ${enabled ? 'checked' : ''} onchange="toggleVar(this)">
        <span class="var-name">${esc(v.name)}</span>
      </label>
      <span class="var-meta">${esc(v.file)} - ${esc(scope)}</span>
      <div class="var-actions">
        <button class="eye-btn" title="Track mode" onclick="toggleModeDropdown('${cssId(key)}')" aria-label="Track mode">
          <span class="icon-eye">👁</span>
        </button>
        <button class="tracking-indicator ${enabled ? 'active' : ''}" title="${enabled ? 'Tracking' : 'Not tracking'}"
                onclick="toggleVar2('${esc(v.name)}', '${esc(v.file)}', this)"></button>
      </div>
      <div class="mode-dropdown hidden" id="mode-${cssId(key)}">
        <label><input type="radio" name="mode-${cssId(key)}" value="single" ${mode === 'single' ? 'checked' : ''}
               onchange="setMode('${esc(v.name)}', '${esc(v.file)}', 'single', 0)"> Track for single run</label>
        <label><input type="radio" name="mode-${cssId(key)}" value="multiple" ${mode === 'multiple' ? 'checked' : ''}
               onchange="setMode('${esc(v.name)}', '${esc(v.file)}', 'multiple', ${count})">
               Track for multiple runs
               <input type="number" class="run-count" value="${count}" min="1" max="100"
               onchange="setModeCount('${esc(v.name)}', '${esc(v.file)}', this.value)"
               onclick="event.stopPropagation()"></label>
      </div>
    </div>`;
  };

  const section = (title: string, items: WorkspaceVariable[]) => {
    if (items.length === 0) { return ''; }
    return `
    <div class="section">
      <div class="section-header" onclick="toggleSection(this)">
        <span class="chevron">▾</span> ${esc(title)}
      </div>
      <div class="section-body">
        ${items.map(varRow).join('')}
      </div>
    </div>`;
  };

  return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  body { font-family: var(--vscode-font-family); font-size: 13px;
         background: var(--vscode-sideBar-background); color: var(--vscode-foreground);
         margin: 0; padding: 0; }
  .toolbar { display: flex; align-items: center; padding: 6px 10px; border-bottom: 1px solid var(--vscode-panel-border); gap: 6px; }
  .filter-input { flex: 1; background: var(--vscode-input-background); color: var(--vscode-input-foreground);
                  border: 1px solid var(--vscode-input-border); border-radius: 4px; padding: 4px 8px; font-size: 12px; }
  .refresh-btn { background: none; border: none; color: var(--vscode-button-foreground);
                 cursor: pointer; padding: 4px 8px; font-size: 11px; opacity: 0.7; }
  .refresh-btn:hover { opacity: 1; }
  .section-header { padding: 5px 10px; font-size: 11px; font-weight: 600; letter-spacing: 0.05em;
                    text-transform: uppercase; color: var(--vscode-descriptionForeground);
                    cursor: pointer; display: flex; align-items: center; gap: 4px; user-select: none; }
  .section-header:hover { background: var(--vscode-list-hoverBackground); }
  .chevron { font-size: 10px; transition: transform 0.15s; }
  .section-header.collapsed .chevron { transform: rotate(-90deg); }
  .section-body { padding: 2px 0; }
  .var-row { padding: 4px 10px 4px 20px; display: flex; flex-direction: column; gap: 2px;
             border-bottom: 1px solid transparent; }
  .var-row:hover { background: var(--vscode-list-hoverBackground); border-color: var(--vscode-panel-border); }
  .checkbox-wrap { display: flex; align-items: center; gap: 6px; cursor: pointer; }
  .var-name { font-weight: 500; }
  .var-meta { font-size: 11px; color: var(--vscode-descriptionForeground); padding-left: 20px; }
  .var-actions { display: flex; align-items: center; gap: 6px; padding-left: 20px; }
  .eye-btn { background: none; border: none; cursor: pointer; padding: 2px; font-size: 14px; opacity: 0.6; }
  .eye-btn:hover { opacity: 1; }
  .tracking-indicator { width: 12px; height: 12px; border-radius: 50%;
                        background: var(--vscode-editor-inactiveSelectionBackground);
                        border: 1px solid var(--vscode-panel-border); cursor: pointer; }
  .tracking-indicator.active { background: #4ec9b0; border-color: #4ec9b0; }
  .mode-dropdown { margin: 4px 0 4px 20px; background: var(--vscode-dropdown-background);
                   border: 1px solid var(--vscode-dropdown-border); border-radius: 4px;
                   padding: 8px; display: flex; flex-direction: column; gap: 6px; }
  .mode-dropdown.hidden { display: none; }
  .mode-dropdown label { display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 12px; }
  .run-count { width: 50px; background: var(--vscode-input-background); color: var(--vscode-input-foreground);
               border: 1px solid var(--vscode-input-border); border-radius: 3px; padding: 2px 4px; font-size: 12px; }
  .empty { padding: 20px; text-align: center; color: var(--vscode-descriptionForeground); font-size: 12px; }
</style>
</head>
<body>
<div class="toolbar">
  <span style="font-size:12px;font-weight:600;">VARIABLES</span>
  <input class="filter-input" type="text" placeholder="Filter variables..." oninput="filterVars(this.value)" id="filterInput">
  <button class="refresh-btn" onclick="refresh()" title="Refresh">↺ Refresh</button>
</div>
${vars.length === 0
  ? '<div class="empty">No Python or JavaScript files found in workspace.<br>Open a project to begin.</div>'
  : section('Session Scopes', session) +
    section('Global Scopes', globals) +
    section('Local Scopes', locals)
}
<script>
const vscode = acquireVsCodeApi();

function toggleVar(el) {
  vscode.postMessage({ type: 'toggleVar', name: el.dataset.name, file: el.dataset.file, enabled: el.checked });
  const row = el.closest('.var-row');
  const ind = row.querySelector('.tracking-indicator');
  if (ind) { ind.classList.toggle('active', el.checked); }
}

function toggleVar2(name, file, ind) {
  const row = ind.closest('.var-row');
  const cb = row.querySelector('.var-check');
  const newState = !cb.checked;
  cb.checked = newState;
  ind.classList.toggle('active', newState);
  vscode.postMessage({ type: 'toggleVar', name, file, enabled: newState });
}

function toggleModeDropdown(key) {
  const dd = document.getElementById('mode-' + key);
  if (dd) { dd.classList.toggle('hidden'); }
}

function setMode(name, file, mode, count) {
  vscode.postMessage({ type: 'setTrackMode', name, file, mode, count: Number(count) });
}

function setModeCount(name, file, val) {
  vscode.postMessage({ type: 'setTrackMode', name, file, mode: 'multiple', count: Number(val) });
}

function toggleSection(hdr) {
  hdr.classList.toggle('collapsed');
  const body = hdr.nextElementSibling;
  if (body) { body.style.display = hdr.classList.contains('collapsed') ? 'none' : ''; }
}

function filterVars(query) {
  const q = query.toLowerCase();
  document.querySelectorAll('.var-row').forEach(row => {
    const name = (row.querySelector('.var-name')?.textContent || '').toLowerCase();
    const meta = (row.querySelector('.var-meta')?.textContent || '').toLowerCase();
    row.style.display = (!q || name.includes(q) || meta.includes(q)) ? '' : 'none';
  });
}

function refresh() {
  vscode.postMessage({ type: 'refresh' });
}
</script>
</body>
</html>`;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// CSS.escape polyfill (used in template strings but TypeScript needs it)
function cssId(s: string): string {
  // Convert a file::name key to a safe CSS id (alphanumeric + underscores)
  return s.replace(/[^a-zA-Z0-9]/g, '_');
}
