import * as vscode from 'vscode';
import * as path from 'path';
import { getOutputDir, mergeForVar, MergedEvent } from './valueStore';

export function openVariableInspector(ctx: vscode.ExtensionContext, varName: string, _unused: any[]) {
  const outputDir = getOutputDir();
  const events = mergeForVar(outputDir, varName);

  const panel = vscode.window.createWebviewPanel(
    'wcfVarInspector',
    'Single Variable Inspection',
    vscode.ViewColumn.One,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  panel.webview.html = buildHtml(varName, events);

  panel.webview.onDidReceiveMessage((msg) => {
    if (msg.type === 'goToLine' && msg.file && msg.line) {
      vscode.workspace.openTextDocument(msg.file).then(doc => {
        vscode.window.showTextDocument(doc).then(editor => {
          const line = Math.max(0, msg.line - 1);
          const pos = new vscode.Position(line, 0);
          editor.selection = new vscode.Selection(pos, pos);
          editor.revealRange(new vscode.Range(pos, pos), vscode.TextEditorRevealType.InCenter);
        });
      }).then(undefined, () => {});
    }
    if (msg.type === 'downloadPkl') {
      // The pkl snapshots are stored by the watcher in the output dir
      // They aren't yet directly accessible — inform user of the path
      vscode.window.showInformationMessage(
        `Pickle snapshots are in: ${outputDir}/snapshots/${msg.varName}/`,
        'Open Folder'
      ).then(sel => {
        if (sel === 'Open Folder') {
          vscode.commands.executeCommand('revealFileInOS', vscode.Uri.file(outputDir));
        }
      });
    }
  });
}

function fmtTs(ns: number): string {
  return new Date(ns / 1e6).toISOString().replace('T', 'T').slice(0, 23) + 'Z';
}

function buildHtml(varName: string, events: MergedEvent[]): string {
  const first = events[0];
  const last = events[events.length - 1];
  const totalVersions = events.length;

  const meta = {
    varName,
    scope:    first?.scope || 'unknown',
    type:     first?.type  || '—',
    sql:      first?.sql_context ? 'True' : 'False',
    threadsId: first?.thread_id != null ? String(first.thread_id) : 'None',
    firstSeen: first ? fmtTs(first.ts_ns) : 'N/A',
    lastSeen:  last  ? fmtTs(last.ts_ns)  : 'N/A',
    filePath:  first?.file || 'N/A',
    lineNo:    first?.line != null ? String(first.line) : 'N/A',
    codeLine:  first?.fn || 'N/A',
    totalVersions,
  };

  const evJson = JSON.stringify(events);

  // Dot color: most are orange/yellow like the mockup, active is teal
  const dots = events.map((_, i) => {
    const pct = i / Math.max(events.length - 1, 1);
    // Dots darken toward the end (unvisited = dark gray)
    const isDark = pct > 0.9;
    return `<div class="ev-dot ${isDark ? 'dark' : ''}" data-idx="${i}" onclick="selectEvent(${i})"></div>`;
  }).join('');

  return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  * { box-sizing: border-box; }
  body { font-family: var(--vscode-font-family); font-size: 13px;
         background: var(--vscode-editor-background); color: var(--vscode-foreground);
         margin: 0; padding: 0; display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
  .top-bar { display: flex; align-items: center; padding: 6px 14px;
             border-bottom: 1px solid var(--vscode-panel-border);
             background: var(--vscode-titleBar-activeBackground); }
  .top-section { font-size: 11px; font-weight: 700; letter-spacing: 0.05em;
                 text-transform: uppercase; color: var(--vscode-descriptionForeground); }
  .top-title { margin-left: auto; font-size: 15px; font-weight: 700; }
  .main-area { display: flex; flex: 1; overflow: hidden; }
  /* Left: value display */
  .value-pane { flex: 1; display: flex; flex-direction: column; overflow: hidden; padding: 14px 16px; }
  .pane-label { font-size: 10px; font-weight: 700; text-transform: uppercase;
                letter-spacing: 0.08em; color: var(--vscode-descriptionForeground); margin-bottom: 10px; }
  .value-content { flex: 1; font-family: var(--vscode-editor-font-family, monospace);
                   font-size: 12.5px; line-height: 1.65;
                   background: var(--vscode-textCodeBlock-background);
                   border: 1px solid var(--vscode-panel-border); border-radius: 4px;
                   padding: 14px; overflow-y: auto; white-space: pre-wrap; }
  /* Right: metadata */
  .meta-pane { width: 260px; border-left: 1px solid var(--vscode-panel-border);
               padding: 14px 12px; overflow-y: auto; flex-shrink: 0; }
  .meta-title { font-size: 14px; font-weight: 700; margin-bottom: 14px; }
  .meta-row { display: flex; flex-direction: column; margin-bottom: 10px; gap: 1px; }
  .meta-label { font-size: 11px; color: var(--vscode-descriptionForeground); }
  .meta-val { font-size: 12px; font-weight: 500; word-break: break-all; }
  .action-btns { display: flex; gap: 8px; margin-top: 16px; flex-wrap: wrap; }
  .abtn { background: var(--vscode-button-secondaryBackground);
          color: var(--vscode-button-secondaryForeground);
          border: 1px solid var(--vscode-button-border, transparent);
          border-radius: 4px; padding: 5px 12px; cursor: pointer; font-size: 11px; }
  .abtn:hover { background: var(--vscode-button-secondaryHoverBackground); }
  .code-block { margin-top: 16px; font-family: monospace; font-size: 10.5px;
                background: var(--vscode-textCodeBlock-background); padding: 8px 10px;
                border-radius: 4px; border: 1px solid var(--vscode-panel-border);
                white-space: pre; overflow-x: auto; color: var(--vscode-textPreformat-foreground); }
  /* Bottom timeline */
  .timeline { padding: 8px 14px; border-top: 1px solid var(--vscode-panel-border); }
  .tick-time { text-align: center; font-size: 11px; color: var(--vscode-descriptionForeground);
               margin-bottom: 6px; }
  .dots-row { display: flex; align-items: center; gap: 10px; overflow-x: auto; padding: 2px 0; }
  .ev-dot { width: 16px; height: 16px; border-radius: 50%; background: #d4900a; flex-shrink: 0;
            cursor: pointer; border: 2px solid transparent; transition: transform 0.12s; }
  .ev-dot:hover { transform: scale(1.25); }
  .ev-dot.selected { background: #4ec9b0; border-color: white; transform: scale(1.35); box-shadow: 0 0 6px #4ec9b040; }
  .ev-dot.dark { background: #555; }
  .no-data { padding: 32px; text-align: center; color: var(--vscode-descriptionForeground); font-size: 12px; }
</style>
</head>
<body>
<div class="top-bar">
  <span class="top-section">Watcher</span>
  <span class="top-title">Variable Inspector</span>
</div>

<div class="main-area">
  <div class="value-pane">
    <div class="pane-label">VALUE DISPLAY</div>
    ${events.length === 0
      ? '<div class="no-data">No data captured yet.<br>Run a tracked file to see variable values here.</div>'
      : `<div class="value-content" id="valueContent">Loading...</div>`}
  </div>

  <div class="meta-pane">
    <div class="meta-title">Metadata</div>
    <div class="meta-row"><div class="meta-label">Variable name</div><div class="meta-val">${esc(meta.varName)}</div></div>
    <div class="meta-row"><div class="meta-label">Scope</div><div class="meta-val" id="mScope">${esc(meta.scope)}</div></div>
    <div class="meta-row"><div class="meta-label">Type</div><div class="meta-val" id="mType">${esc(meta.type)}</div></div>
    <div class="meta-row"><div class="meta-label">SQL</div><div class="meta-val" id="mSql">${esc(meta.sql)}</div></div>
    <div class="meta-row"><div class="meta-label">Threads id</div><div class="meta-val" id="mTid">${esc(meta.threadsId)}</div></div>
    <div class="meta-row"><div class="meta-label">First seen</div><div class="meta-val" style="font-size:10.5px">${esc(meta.firstSeen)}</div></div>
    <div class="meta-row"><div class="meta-label">Last seen</div><div class="meta-val" style="font-size:10.5px">${esc(meta.lastSeen)}</div></div>
    <div class="meta-row"><div class="meta-label">File Path</div><div class="meta-val" id="mFile" style="font-size:10.5px">${esc(meta.filePath)}</div></div>
    <div class="meta-row"><div class="meta-label">Line no.</div><div class="meta-val" id="mLine">${esc(meta.lineNo)}</div></div>
    <div class="meta-row"><div class="meta-label">Code Line</div><div class="meta-val" id="mCode" style="font-size:10.5px">${esc(meta.codeLine)}</div></div>
    <div class="meta-row"><div class="meta-label">Total versions</div><div class="meta-val">${meta.totalVersions}</div></div>
    <div class="action-btns">
      <button class="abtn" onclick="downloadPkl()">Download .pkl</button>
      <button class="abtn" onclick="printValue()">Print Value</button>
    </div>
    <div class="code-block" id="codeBlock"></div>
  </div>
</div>

<div class="timeline">
  <div class="tick-time" id="tickTime">${events.length > 0 ? 'Click a dot to inspect' : ''}</div>
  <div class="dots-row" id="dotsRow">${dots}</div>
</div>

<script>
const vscode = acquireVsCodeApi();
const events = ${evJson};
let currentIdx = events.length > 0 ? events.length - 1 : -1;

function fmtTs(ns) {
  return new Date(ns / 1e6).toTimeString().slice(0, 12);
}

function selectEvent(idx) {
  if (idx < 0 || idx >= events.length) { return; }
  currentIdx = idx;
  const ev = events[idx];

  // Value display
  document.getElementById('valueContent').textContent = ev.repr || '(no value)';

  // Metadata updates
  document.getElementById('tickTime').textContent = 'Time: ' + fmtTs(ev.ts_ns);
  if (ev.scope)  { document.getElementById('mScope').textContent = ev.scope; }
  if (ev.type)   { document.getElementById('mType').textContent  = ev.type; }
  if (ev.sql_context !== undefined) { document.getElementById('mSql').textContent = ev.sql_context ? 'True' : 'False'; }
  if (ev.thread_id != null) { document.getElementById('mTid').textContent = String(ev.thread_id); }
  if (ev.file)   { document.getElementById('mFile').textContent = ev.file; }
  if (ev.line)   { document.getElementById('mLine').textContent = String(ev.line); }
  if (ev.fn)     { document.getElementById('mCode').textContent = ev.fn; }

  // Code snippet
  const snippet = ev.file && ev.line
    ? 'from some_import_name import s\ns.inspect(variable_name="' + ev.varName + '", runs=5)'
    : '';
  document.getElementById('codeBlock').textContent = snippet;

  // Highlight dots
  document.querySelectorAll('.ev-dot').forEach((d, i) => d.classList.toggle('selected', i === idx));

  // Navigate editor cursor
  if (ev.file && ev.line) {
    vscode.postMessage({ type: 'goToLine', file: ev.file, line: ev.line });
  }
}

function printValue() {
  if (currentIdx >= 0) {
    const ev = events[currentIdx];
    vscode.postMessage({ type: 'printValue', repr: ev.repr });
  }
}

function downloadPkl() {
  if (currentIdx >= 0) {
    const ev = events[currentIdx];
    vscode.postMessage({ type: 'downloadPkl', varName: ev.varName, ts_ns: ev.ts_ns });
  }
}

// Init with latest event
if (events.length > 0) { selectEvent(events.length - 1); }
</script>
</body>
</html>`;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
