import * as vscode from 'vscode';
import * as path from 'path';
import { RecordedFile, SettingsManager, getWorkspaceRoot } from './settings';
import { runCodevovle, listDiffFiles } from './codevovleRunner';

export function openInsightsWebview(ctx: vscode.ExtensionContext, rf: RecordedFile, branchIds: string[]) {
  const panel = vscode.window.createWebviewPanel(
    'wcfInsights',
    'Insight selection',
    vscode.ViewColumn.One,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  const wsRoot = getWorkspaceRoot();

  async function loadTree() {
    // Build tree data: for each branch, get its tick count
    const treeData: BranchNode[] = [];
    for (const bId of branchIds) {
      const ticks = listDiffFiles(wsRoot, rf.absPath, bId);
      treeData.push({
        id: bId,
        label: bId.split('/').pop() || bId,
        parent: bId.includes('/') ? bId.split('/').slice(0, -1).join('/') : null,
        ticks,
      });
    }
    if (treeData.length === 0) {
      // Default: main with whatever ticks exist
      const ticks = listDiffFiles(wsRoot, rf.absPath, rf.activeBranch);
      treeData.push({ id: rf.activeBranch, label: rf.activeBranch, parent: null, ticks });
    }

    panel.webview.html = buildHtml(rf, treeData);
  }

  loadTree();

  panel.webview.onDidReceiveMessage(async (msg) => {
    if (msg.type === 'getInsights') {
      const { fromSpec, toSpec } = msg;
      const cvModel = SettingsManager.codevovle.aiModel;
      const args = ['insights', '--file', rf.absPath, '--from', fromSpec, '--to', toSpec, '--model', cvModel];
      const res = await runCodevovle(ctx.extensionPath, args, wsRoot);
      panel.webview.postMessage({ type: 'insightsResult', text: res.stdout + (res.stderr ? '\n' + res.stderr : '') });
    }
  });
}

interface BranchNode {
  id: string;
  label: string;
  parent: string | null;
  ticks: number[];
}

function buildHtml(rf: RecordedFile, tree: BranchNode[]): string {
  // Build tree layout: main branch is horizontal, child branches go up/down
  // Each tick is a node on its branch line
  const treeJson = JSON.stringify(tree);
  const fileName = path.basename(rf.relPath);

  return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  body { font-family: var(--vscode-font-family); font-size: 13px;
         background: var(--vscode-editor-background); color: var(--vscode-foreground);
         margin: 0; padding: 0; display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
  #treeCanvas { flex: 1; overflow: auto; position: relative; }
  canvas { display: block; }
  .bottom-bar { display: flex; align-items: center; justify-content: center; gap: 12px;
                padding: 10px; border-top: 1px solid var(--vscode-panel-border);
                background: var(--vscode-editor-background); }
  #insightBtn { background: var(--vscode-button-background); color: var(--vscode-button-foreground);
                border: none; border-radius: 6px; padding: 8px 20px; cursor: pointer;
                font-size: 13px; }
  #insightBtn:hover { background: var(--vscode-button-hoverBackground); }
  #insightBtn:disabled { opacity: 0.5; cursor: not-allowed; }
  .legend { font-size: 11px; color: var(--vscode-descriptionForeground); display: flex; gap: 12px; }
  .legend-item { display: flex; align-items: center; gap: 4px; }
  .legend-dot { width: 10px; height: 10px; border-radius: 50%; }
  #insightsOutput { padding: 12px 16px; border-top: 1px solid var(--vscode-panel-border);
                    max-height: 200px; overflow-y: auto; font-size: 12px; white-space: pre-wrap;
                    display: none; background: var(--vscode-editor-background); }
</style>
</head>
<body>
<div id="treeCanvas"><canvas id="c"></canvas></div>
<div id="insightsOutput"></div>
<div class="bottom-bar">
  <div class="legend">
    <div class="legend-item"><div class="legend-dot" style="background:#4ec9b0;"></div> Main branch ticks</div>
    <div class="legend-item"><div class="legend-dot" style="background:#888;"></div> Branch ticks</div>
    <div class="legend-item"><div class="legend-dot" style="background:#f0c040;"></div> Selected point</div>
    <div class="legend-item"><div class="legend-dot" style="background:#e05060;"></div> First selection (from)</div>
  </div>
  <button id="insightBtn" onclick="getInsights()" disabled>Get Insights</button>
</div>

<script>
const vscode = acquireVsCodeApi();
const tree = ${treeJson};

const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');

const NODE_R = 14;
const H_GAP = 60;    // horizontal gap between ticks
const V_GAP = 70;    // vertical gap between branch lines
const MARGIN = 40;

// Layout: main branch horizontal in center, children branch up or down
// Build layout map
function buildLayout() {
  const mainBranch = tree.find(b => b.parent === null) || tree[0];
  if (!mainBranch) { return { nodes: [], lines: [] }; }

  const nodes = [];
  const lines = [];
  const branchY = {}; // branch id -> y center

  // Main branch goes in center row
  const mainY = 0;
  branchY[mainBranch.id] = mainY;

  // Child branches alternate up/down
  const children = tree.filter(b => b.parent === mainBranch.id);
  let upSlot = 1, downSlot = 1;
  for (const child of children) {
    if (upSlot <= downSlot) { branchY[child.id] = -upSlot * V_GAP; upSlot++; }
    else { branchY[child.id] = downSlot * V_GAP; downSlot++; }
  }

  // Assign x positions (each tick = H_GAP apart)
  const mainNodes = [];
  mainBranch.ticks.forEach((tick, i) => {
    mainNodes.push({ id: \`\${mainBranch.id}@\${tick}\`, branch: mainBranch.id, tick, x: MARGIN + i * H_GAP, y: mainY, isMain: true });
  });
  nodes.push(...mainNodes);

  // Main branch line
  if (mainNodes.length > 1) {
    lines.push({ x1: mainNodes[0].x, y1: mainY, x2: mainNodes[mainNodes.length-1].x, y2: mainY, color: '#4ec9b0' });
  }

  // Child branches fork from the main branch
  for (const child of children) {
    const childY = branchY[child.id] || 0;
    const forkX = mainNodes.length > 0 ? mainNodes[Math.floor(mainNodes.length / 2)].x : MARGIN;
    const childNodes = [];
    child.ticks.forEach((tick, i) => {
      childNodes.push({ id: \`\${child.id}@\${tick}\`, branch: child.id, tick, x: forkX + (i+1)*H_GAP, y: childY, isMain: false });
    });
    nodes.push(...childNodes);
    // Fork connector
    lines.push({ x1: forkX, y1: mainY, x2: forkX, y2: childY, color: 'white' });
    // Child branch line
    if (childNodes.length > 0) {
      lines.push({ x1: forkX, y1: childY, x2: childNodes[childNodes.length-1].x, y2: childY, color: 'white' });
    }
  }

  return { nodes, lines };
}

const layout = buildLayout();
const nodes = layout.nodes;
const lines = layout.lines;

let selected = []; // 0=from(red), 1=to(yellow)

function getCanvasSize() {
  if (nodes.length === 0) { return { w: 400, h: 300 }; }
  const ys = nodes.map(n => n.y);
  const xs = nodes.map(n => n.x);
  const minY = Math.min(...ys), maxY = Math.max(...ys);
  const maxX = Math.max(...xs);
  return { w: maxX + MARGIN + 20, h: maxY - minY + 2 * NODE_R + 2 * MARGIN };
}

function render() {
  const { w, h } = getCanvasSize();
  canvas.width = w;
  canvas.height = h;
  const minY = nodes.length > 0 ? Math.min(...nodes.map(n => n.y)) : 0;
  const offsetY = -minY + MARGIN + NODE_R;

  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#1e1e1e';
  ctx.fillRect(0, 0, w, h);

  // Draw lines
  for (const line of lines) {
    ctx.beginPath();
    ctx.strokeStyle = line.color;
    ctx.lineWidth = 2;
    ctx.moveTo(line.x1, line.y1 + offsetY);
    ctx.lineTo(line.x2, line.y2 + offsetY);
    ctx.stroke();
  }

  // Draw nodes
  for (const node of nodes) {
    const cy = node.y + offsetY;
    const sel = selected.find(s => s.nodeId === node.id);
    let fill = node.isMain ? '#4ec9b0' : '#666';
    if (sel) {
      fill = sel.which === 0 ? '#e05060' : '#f0c040';
    }
    ctx.beginPath();
    ctx.arc(node.x, cy, NODE_R / 1.4, 0, Math.PI * 2);
    ctx.fillStyle = fill;
    ctx.fill();
    // Tick label
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.font = '9px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(String(node.tick), node.x, cy + 3);
  }
}

canvas.addEventListener('click', e => {
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  const my = e.clientY - rect.top;
  const minY = nodes.length > 0 ? Math.min(...nodes.map(n => n.y)) : 0;
  const offsetY = -minY + MARGIN + NODE_R;

  for (const node of nodes) {
    const cy = node.y + offsetY;
    const dist = Math.sqrt((mx - node.x)**2 + (my - cy)**2);
    if (dist < NODE_R + 4) {
      // First click = red (from), second click = yellow (to)
      const existingIdx = selected.findIndex(s => s.nodeId === node.id);
      if (existingIdx >= 0) {
        // Deselect
        selected.splice(existingIdx, 1);
      } else if (selected.length < 2) {
        selected.push({ nodeId: node.id, which: selected.length, branch: node.branch, tick: node.tick });
      } else {
        // Replace the oldest
        selected.shift();
        selected.push({ nodeId: node.id, which: 1, branch: node.branch, tick: node.tick });
        selected[0].which = 0;
      }
      document.getElementById('insightBtn').disabled = selected.length < 2;
      render();
      break;
    }
  }
});

function getInsights() {
  if (selected.length < 2) { return; }
  // Sort by tick to determine from/to
  const sorted = [...selected].sort((a,b) => a.tick - b.tick);
  const fromSpec = sorted[0].branch + '@' + sorted[0].tick;
  const toSpec = sorted[1].branch + '@' + sorted[1].tick;
  document.getElementById('insightBtn').disabled = true;
  document.getElementById('insightBtn').textContent = 'Loading...';
  vscode.postMessage({ type: 'getInsights', fromSpec, toSpec });
}

window.addEventListener('message', e => {
  const msg = e.data;
  if (msg.type === 'insightsResult') {
    const out = document.getElementById('insightsOutput');
    out.style.display = 'block';
    out.textContent = msg.text;
    document.getElementById('insightBtn').disabled = false;
    document.getElementById('insightBtn').textContent = 'Get Insights';
  }
});

render();
</script>
</body>
</html>`;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
