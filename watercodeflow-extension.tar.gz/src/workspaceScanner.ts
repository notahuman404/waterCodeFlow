import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import { getWorkspaceRoot } from './settings';

export interface WorkspaceVariable {
  name: string;
  file: string;       // relative to workspace root
  scope: 'local' | 'global' | 'both';
}

export interface ScannedFile {
  relPath: string;
  absPath: string;
  lang: 'python' | 'javascript';
}

// ─── Scan for supported source files ────────────────────────────────────────
export async function scanWorkspaceFiles(): Promise<ScannedFile[]> {
  const wsRoot = getWorkspaceRoot();
  const pyFiles = await vscode.workspace.findFiles('**/*.py', '**/node_modules/**');
  const jsFiles = await vscode.workspace.findFiles('**/*.js', '**/node_modules/**');

  const result: ScannedFile[] = [];

  for (const f of pyFiles) {
    result.push({
      absPath: f.fsPath,
      relPath: path.relative(wsRoot, f.fsPath),
      lang: 'python',
    });
  }
  for (const f of jsFiles) {
    result.push({
      absPath: f.fsPath,
      relPath: path.relative(wsRoot, f.fsPath),
      lang: 'javascript',
    });
  }

  return result;
}

// ─── Extract variables from a Python file via simple AST-like regex parse ───
export function extractPythonVars(absPath: string, relPath: string): WorkspaceVariable[] {
  let src: string;
  try { src = fs.readFileSync(absPath, 'utf8'); }
  catch { return []; }

  const lines = src.split('\n');
  const globalNames = new Set<string>();
  const localNames = new Set<string>();

  let insideFunction = false;
  let funcIndent = 0;

  for (const line of lines) {
    const trimmed = line.trimStart();
    const indent = line.length - trimmed.length;

    // Detect function definition
    if (/^(async\s+)?def\s+\w+\s*\(/.test(trimmed)) {
      insideFunction = true;
      funcIndent = indent;
      continue;
    }

    // Leaving function scope (back to module level)
    if (insideFunction && indent <= funcIndent && /^\S/.test(line) && !/^(#|$)/.test(trimmed)) {
      insideFunction = false;
    }

    // Simple assignment detection: name = ...  or  name, name2 = ...
    const assignMatch = trimmed.match(/^([a-zA-Z_][a-zA-Z_0-9]*(?:\s*,\s*[a-zA-Z_][a-zA-Z_0-9]*)*)\s*=/);
    if (assignMatch && !trimmed.startsWith('#')) {
      const namesPart = assignMatch[1];
      const names = namesPart.split(',').map(n => n.trim()).filter(n => /^[a-zA-Z_]\w*$/.test(n));
      for (const n of names) {
        if (insideFunction) {
          localNames.add(n);
        } else {
          globalNames.add(n);
        }
      }
    }

    // for x in ...
    const forMatch = trimmed.match(/^for\s+([a-zA-Z_][a-zA-Z_0-9]*)\s+in\s/);
    if (forMatch) {
      if (insideFunction) { localNames.add(forMatch[1]); }
      else { globalNames.add(forMatch[1]); }
    }
  }

  const result: WorkspaceVariable[] = [];
  const all = new Set([...globalNames, ...localNames]);
  for (const name of all) {
    const isGlobal = globalNames.has(name);
    const isLocal = localNames.has(name);
    const scope: 'local' | 'global' | 'both' =
      isGlobal && isLocal ? 'both' : isGlobal ? 'global' : 'local';
    result.push({ name, file: relPath, scope });
  }
  return result;
}

// ─── Extract variables from a JavaScript file ─────────────────────────────
export function extractJsVars(absPath: string, relPath: string): WorkspaceVariable[] {
  let src: string;
  try { src = fs.readFileSync(absPath, 'utf8'); }
  catch { return []; }

  const lines = src.split('\n');
  const globalNames = new Set<string>();
  const localNames = new Set<string>();
  let braceDepth = 0;

  for (const line of lines) {
    const trimmed = line.trim();

    // Track brace depth to distinguish module vs function scope
    braceDepth += (line.match(/\{/g) || []).length;
    braceDepth -= (line.match(/\}/g) || []).length;
    if (braceDepth < 0) { braceDepth = 0; }

    // var/let/const declarations
    const declMatch = trimmed.match(/^(?:var|let|const)\s+([a-zA-Z_$][a-zA-Z_0-9$]*)\s*(?:=|;|,)/);
    if (declMatch) {
      if (braceDepth === 0) { globalNames.add(declMatch[1]); }
      else { localNames.add(declMatch[1]); }
    }

    // function name()
    const fnMatch = trimmed.match(/^(?:function\s+([a-zA-Z_$][a-zA-Z_0-9$]*)\s*\()/);
    if (fnMatch) { globalNames.add(fnMatch[1]); }
  }

  const result: WorkspaceVariable[] = [];
  const all = new Set([...globalNames, ...localNames]);
  for (const name of all) {
    const isGlobal = globalNames.has(name);
    const isLocal = localNames.has(name);
    const scope: 'local' | 'global' | 'both' =
      isGlobal && isLocal ? 'both' : isGlobal ? 'global' : 'local';
    result.push({ name, file: relPath, scope });
  }
  return result;
}

// ─── Scan whole workspace for variables ──────────────────────────────────────
export async function scanAllVariables(): Promise<WorkspaceVariable[]> {
  const files = await scanWorkspaceFiles();
  const vars: WorkspaceVariable[] = [];

  for (const f of files) {
    if (f.lang === 'python') {
      vars.push(...extractPythonVars(f.absPath, f.relPath));
    } else {
      vars.push(...extractJsVars(f.absPath, f.relPath));
    }
  }

  return vars;
}
