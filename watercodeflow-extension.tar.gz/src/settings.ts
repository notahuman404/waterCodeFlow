import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

// ─── Watcher Settings ───────────────────────────────────────────────────────
export interface WatcherSettings {
  trackThreads: boolean;
  trackLocals: boolean;
  trackSql: boolean;
  trackAll: boolean;
  mutationDepth: string; // 'FULL' or number string
  maxQueueSize: number;
  logLevel: 'INFO' | 'DEBUG';
  customProcessor: string;
  outputDir: string;
}

export const DEFAULT_WATCHER: WatcherSettings = {
  trackThreads: false,
  trackLocals: false,
  trackSql: false,
  trackAll: false,
  mutationDepth: 'FULL',
  maxQueueSize: 10000,
  logLevel: 'INFO',
  customProcessor: '',
  outputDir: '',
};

// ─── CodeVovle Settings ─────────────────────────────────────────────────────
export interface CodeVovleSettings {
  samplingInterval: number;
  daemonThreads: number;
  aiModel: 'gemini' | 'chatgpt' | 'claude';
  recordingMode: 'background' | 'foreground';
}

export const DEFAULT_CODEVOVLE: CodeVovleSettings = {
  samplingInterval: 0.5,
  daemonThreads: 4,
  aiModel: 'gemini',
  recordingMode: 'background',
};

// ─── Tracked Variable ────────────────────────────────────────────────────────
export interface TrackedVariable {
  name: string;
  file: string;          // relative path
  scope: 'local' | 'global' | 'both';
  trackMode: 'single' | 'multiple';
  trackCount: number;    // only used when trackMode === 'multiple'
  enabled: boolean;
}

// ─── Recorded File ───────────────────────────────────────────────────────────
export interface RecordedFile {
  absPath: string;
  relPath: string;
  enabled: boolean;
  activeBranch: string;
}

// ─── Settings Manager ───────────────────────────────────────────────────────
export class SettingsManager {
  private static ctx: vscode.ExtensionContext;

  static init(ctx: vscode.ExtensionContext) {
    SettingsManager.ctx = ctx;
  }

  static get watcher(): WatcherSettings {
    return SettingsManager.ctx.globalState.get<WatcherSettings>('wcf.watcher', DEFAULT_WATCHER);
  }

  static setWatcher(s: WatcherSettings) {
    SettingsManager.ctx.globalState.update('wcf.watcher', s);
  }

  static get codevovle(): CodeVovleSettings {
    return SettingsManager.ctx.globalState.get<CodeVovleSettings>('wcf.codevovle', DEFAULT_CODEVOVLE);
  }

  static setCodeVovle(s: CodeVovleSettings) {
    SettingsManager.ctx.globalState.update('wcf.codevovle', s);
  }

  static get trackedVars(): TrackedVariable[] {
    return SettingsManager.ctx.globalState.get<TrackedVariable[]>('wcf.trackedVars', []);
  }

  static setTrackedVars(vars: TrackedVariable[]) {
    SettingsManager.ctx.globalState.update('wcf.trackedVars', vars);
  }

  static get recordedFiles(): RecordedFile[] {
    return SettingsManager.ctx.globalState.get<RecordedFile[]>('wcf.recordedFiles', []);
  }

  static setRecordedFiles(files: RecordedFile[]) {
    SettingsManager.ctx.globalState.update('wcf.recordedFiles', files);
  }

  // Build watcher CLI args from settings and tracked variables
  static buildWatcherArgs(userScript: string): string[] {
    const ws = SettingsManager.watcher;
    const wsRoot = getWorkspaceRoot();
    const args: string[] = ['--user-script', userScript];

    if (ws.trackThreads) { args.push('--track-threads'); }
    if (ws.trackLocals)  { args.push('--track-locals'); }
    if (ws.trackSql)     { args.push('--track-sql'); }
    if (ws.trackAll)     { args.push('--track-all'); }

    args.push('--mutation-depth', ws.mutationDepth);
    args.push('--max-queue-size', String(ws.maxQueueSize));
    args.push('--log-level', ws.logLevel);

    const outDir = ws.outputDir || path.join(wsRoot, 'watcher_output');
    args.push('--output', outDir);

    if (ws.customProcessor) {
      args.push('--custom-processor', ws.customProcessor);
    }

    // Build scope config file if there are tracked vars
    const enabled = SettingsManager.trackedVars.filter(v => v.enabled);
    if (enabled.length > 0) {
      const scopeFile = writeScopeConfig(enabled, wsRoot);
      args.push('--files-scope', scopeFile);
    }

    return args;
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
export function getWorkspaceRoot(): string {
  const folders = vscode.workspace.workspaceFolders;
  if (folders && folders.length > 0) {
    return folders[0].uri.fsPath;
  }
  return process.cwd();
}

function writeScopeConfig(vars: TrackedVariable[], wsRoot: string): string {
  // Group by file
  const byFile: Record<string, TrackedVariable[]> = {};
  for (const v of vars) {
    if (!byFile[v.file]) { byFile[v.file] = []; }
    byFile[v.file].push(v);
  }

  const lines: string[] = [];
  for (const [file, fileVars] of Object.entries(byFile)) {
    const specs = fileVars.map(v => `${v.scope}:${v.name}`).join(',');
    lines.push(`${file}:(${specs})`);
  }

  const configPath = path.join(wsRoot, '.wcf_scope.txt');
  fs.writeFileSync(configPath, lines.join('\n'), 'utf8');
  return configPath;
}
