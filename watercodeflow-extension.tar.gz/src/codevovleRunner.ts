import * as vscode from 'vscode';
import * as cp from 'child_process';
import * as path from 'path';
import * as fs from 'fs';
import { getWorkspaceRoot } from './settings';

// Path to bundled codevovle inside the extension
export function codevovlePython(extPath: string): string {
  return path.join(extPath, 'backend', 'CodeVovle');
}

// Build env for codevovle subprocess: skip cwd check, set PYTHONPATH
function buildEnv(extPath: string, cwd: string): NodeJS.ProcessEnv {
  const backendDir = path.join(extPath, 'backend');
  const codevovleDir = path.join(backendDir, 'CodeVovle');
  const storageDir = path.join(backendDir, 'storage_utility');
  const existing = process.env.PYTHONPATH || '';
  return {
    ...process.env,
    CODEVOVLE_SKIP_CWD_CHECK: '1',
    PYTHONPATH: [codevovleDir, storageDir, existing].filter(Boolean).join(path.delimiter),
  };
}

export function runCodevovle(
  extPath: string,
  args: string[],
  cwd: string,
  onData?: (line: string) => void
): Promise<{ code: number; stdout: string; stderr: string }> {
  return new Promise((resolve) => {
    const env = buildEnv(extPath, cwd);
    // Try python3 then python
    const pythonBin = process.platform === 'win32' ? 'python' : 'python3';
    const proc = cp.spawn(
      pythonBin,
      ['-m', 'codevovle', ...args],
      { cwd, env, shell: false }
    );

    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (chunk: Buffer) => {
      const text = chunk.toString();
      stdout += text;
      if (onData) {
        text.split('\n').filter(l => l.trim()).forEach(l => onData(l));
      }
    });
    proc.stderr.on('data', (chunk: Buffer) => {
      const text = chunk.toString();
      stderr += text;
    });
    proc.on('close', (code) => {
      resolve({ code: code ?? 1, stdout, stderr });
    });
    proc.on('error', (err) => {
      resolve({ code: 1, stdout, stderr: err.message });
    });
  });
}

// Parse status output of `codevovle status --file ...`
export interface CodevovleStatus {
  activeBranch: string;
  cursorTick: number | null;
  branchHead: number | null;
  lastTickId: number;
  branchTickCount: number;
  interval: number | string;
}

export function parseStatus(stdout: string): CodevovleStatus | null {
  const get = (label: string): string | null => {
    const m = stdout.match(new RegExp(`${label}\\s*:\\s*(.+)`));
    return m ? m[1].trim() : null;
  };
  const branch = get('Active Branch');
  if (!branch) { return null; }
  return {
    activeBranch: branch,
    cursorTick: toNum(get('Current Tick')),
    branchHead: toNum(get('Branch Head')),
    lastTickId: toNum(get('Last Tick ID')) ?? 0,
    branchTickCount: toNum(get('Branch Tick Count')) ?? 0,
    interval: get('Interval') ?? 'unknown',
  };
}

function toNum(s: string | null): number | null {
  if (!s || s === 'N/A') { return null; }
  const n = Number(s);
  return isNaN(n) ? null : n;
}

// Read .codevovle/config.json for a workspace - returns tracked files info
export function readCodevovleConfig(wsRoot: string): Record<string, any> {
  const configPath = path.join(wsRoot, '.codevovle', 'config.json');
  try {
    const raw = fs.readFileSync(configPath, 'utf8');
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

// List diff files (ticks) for a file's active branch
export function listDiffFiles(wsRoot: string, filePath: string, branch: string): number[] {
  const branchDir = path.join(wsRoot, '.codevovle', 'branches', branch);
  const metaPath = path.join(branchDir, 'meta.json');
  try {
    const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
    return (meta.diff_chain as number[]) || [];
  } catch {
    return [];
  }
}

// Read a diff file content
export function readDiff(wsRoot: string, tickId: number): string {
  const diffPath = path.join(wsRoot, '.codevovle', 'diffs', `${tickId}.diff`);
  try { return fs.readFileSync(diffPath, 'utf8'); }
  catch { return ''; }
}

// Read state.json
export function readState(wsRoot: string): any {
  const statePath = path.join(wsRoot, '.codevovle', 'state.json');
  try { return JSON.parse(fs.readFileSync(statePath, 'utf8')); }
  catch { return {}; }
}

// Read base snapshot for a file
export function readBaseSnapshot(wsRoot: string, filePath: string): string {
  // Snapshots are stored by normalized path hash or index
  const snapDir = path.join(wsRoot, '.codevovle', 'snapshots');
  try {
    const files = fs.readdirSync(snapDir);
    for (const f of files) {
      const snapPath = path.join(snapDir, f);
      const meta = JSON.parse(fs.readFileSync(snapPath, 'utf8'));
      if (meta.file_path === filePath || snapPath.includes(path.basename(filePath))) {
        return meta.content || '';
      }
    }
  } catch {}
  return '';
}
