import * as vscode from 'vscode';
import * as path from 'path';
import { SettingsManager, getWorkspaceRoot } from './settings';
import { runCodevovle, readCodevovleConfig, listDiffFiles } from './codevovleRunner';
import { openTimelinePanel } from './timelinePanel';
import { openVariableInspector } from './variableInspector';
import { openRunInspector } from './runInspector';
import { mergeAllVars, clusterIntoRuns, getOutputDir, MergedEvent } from './valueStore';

export function openRecordingPanel(ctx: vscode.ExtensionContext) {
  const panel = vscode.window.createWebviewPanel(
    'wcfRecording',
    'Recording Viewer',
    vscode.ViewColumn.Beside,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  const wsRoot = getWorkspaceRoot();

  async function loadData() {
    const recorded = SettingsManager.recordedFiles.filter(r => r.enabled);
    const cv = SettingsManager.codevovle;
    const outputDir = getOutputDir();

    const fileData: FileData[] = [];
    for (const rf of recorded) {
      const ticks = listDiffFiles(wsRoot, rf.absPath, rf.activeBranch);
      fileData.push({
        relPath: rf.relPath,
        absPath: rf.absPath,
        activeBranch: rf.activeBranch,
        tickCount: ticks.length,
      });
    }

    const allVars = mergeAllVars(outputDir);
    const runs = clusterIntoRuns(allVars);
    panel.webview.html = buildHtml(fileData, allVars, runs);
  }

  loadData();

  panel.webview.onDidReceiveMessage(async (msg) => {
    if (msg.type === 'openTimeline') {
      const rf = SettingsManager.recordedFiles.find(r => r.relPath === msg.relPath);
      if (rf) { openTimelinePanel(ctx, rf); }
    }
    if (msg.type === 'openVarInspector') {
      openVariableInspector(ctx, msg.varName, []);
    }
    if (msg.type === 'openRunInspector') {
      openRunInspector(ctx, msg.runIndex, []);
    }
    if (msg.type === 'refresh') {
      await loadData();
    }
  });
}

interface FileData {
  relPath: string;
  absPath: string;
  activeBranch: string;
  tickCount: number;
}

function buildHtml(
  fileData: FileData[],
  allVars: Map<string, MergedEvent[]>,
  runs: Array<Map<string, MergedEvent[]>>
): string {
  const fileRows = fileData.map(f => `
    <div class="file-row" onclick="openTimeline('${esc(f.relPath)}')">
      <span class="check-icon">✓</span>
      <span class="file-name-bold">${esc(path.basename(f.relPath))}</span>
      <span class="file-path-sm">(./${esc(f.relPath)})</span>
    </div>`).join('');

  const varRows = Array.from(allVars.entries()).map(([name, events]) => `
    <div class="var-evo-row" onclick="openVarInspector('${esc(name)}')">
      <span class="var-evo-name">${esc(name)}</span>
      <span class="evo-count">evolutions: ${events.length}</span>
    </div>`).join('');

  const runRows = runs.map((runMap, i) => `
    <div class="run-row" onclick="openRunInspector(${i})">
      <span class="run-label">Run #${i + 1}</span>
      <span class="run-changes">${runMap.size} var changed</span>
    </div>`).join('');

  return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  body { font-family: var(--vscode-font-family); font-size: 13px;
         background: var(--vscode-sideBar-background); color: var(--vscode-foreground);
         margin: 0; padding: 0; }
  .section-hdr { padding: 8px 12px; font-size: 12px; font-weight: 700; letter-spacing: 0.05em;
                 display: flex; justify-content: space-between; align-items: center;
                 background: var(--vscode-sideBarSectionHeader-background);
                 border-bottom: 1px solid var(--vscode-panel-border); }
  .section-sub { font-size: 11px; color: var(--vscode-descriptionForeground); font-weight: 400; }
  .file-row { display: flex; align-items: center; gap: 6px; padding: 6px 12px;
              border-bottom: 1px solid var(--vscode-panel-border); cursor: pointer; }
  .file-row:hover { background: var(--vscode-list-hoverBackground); }
  .check-icon { color: #4ec9b0; font-size: 14px; }
  .file-name-bold { font-weight: 600; }
  .file-path-sm { font-size: 11px; color: var(--vscode-descriptionForeground); }
  .persist-note { padding: 5px 12px; font-size: 11px; color: var(--vscode-descriptionForeground);
                  border-bottom: 1px solid var(--vscode-panel-border); font-style: italic; }
  .var-evo-row { display: flex; align-items: center; justify-content: space-between;
                 padding: 7px 12px; border-bottom: 1px solid var(--vscode-panel-border); cursor: pointer; }
  .var-evo-row:hover { background: var(--vscode-list-hoverBackground); }
  .var-evo-name { font-weight: 500; }
  .evo-count { font-size: 11px; color: var(--vscode-descriptionForeground); }
  .evo-hint { padding: 5px 12px; font-size: 11px; color: var(--vscode-descriptionForeground);
              font-style: italic; border-bottom: 1px solid var(--vscode-panel-border); }
  .run-row { display: flex; align-items: center; justify-content: space-between;
             padding: 7px 12px; border-bottom: 1px solid var(--vscode-panel-border); cursor: pointer; }
  .run-row:hover { background: var(--vscode-list-hoverBackground); }
  .run-label { font-weight: 500; }
  .run-changes { font-size: 11px; color: var(--vscode-descriptionForeground); }
  .empty-hint { padding: 16px 12px; font-size: 12px; color: var(--vscode-descriptionForeground); text-align: center; }
  .refresh-btn { background: none; border: none; cursor: pointer; color: var(--vscode-foreground); opacity: 0.6; font-size: 11px; }
  .refresh-btn:hover { opacity: 1; }
</style>
</head>
<body>
<div class="section-hdr">
  <span>Files <span class="section-sub">— Tracked</span></span>
  <button class="refresh-btn" onclick="doRefresh()">↺</button>
</div>
${fileData.length === 0
  ? '<div class="empty-hint">No files being recorded. Use the 📷 Record panel to select files.</div>'
  : fileRows + '<div class="persist-note">Persisted in Volvo (.codevovle)</div>'}

<div class="section-hdr" style="margin-top:4px;">
  Variables <span class="section-sub">— Evolution</span>
</div>
${allVars.size === 0
  ? '<div class="empty-hint">Run a file with Watcher enabled to see variable evolution.</div>'
  : varRows + '<div class="evo-hint">Updates when variables change across runs</div>'}

<div class="section-hdr" style="margin-top:4px;">
  Runs <span class="section-sub">— Variable Changes</span>
</div>
${runs.length === 0
  ? '<div class="empty-hint">No run data yet. Execute a tracked script to see runs.</div>'
  : runRows}

<script>
const vscode = acquireVsCodeApi();
function openTimeline(relPath)     { vscode.postMessage({ type: 'openTimeline', relPath }); }
function openVarInspector(varName) { vscode.postMessage({ type: 'openVarInspector', varName }); }
function openRunInspector(idx)     { vscode.postMessage({ type: 'openRunInspector', runIndex: idx }); }
function doRefresh()               { vscode.postMessage({ type: 'refresh' }); }
</script>
</body>
</html>`;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
