import * as vscode from 'vscode';
import * as path from 'path';
import { getOutputDir, mergeAllVars, clusterIntoRuns, MergedEvent } from './valueStore';

export function openRunInspector(ctx: vscode.ExtensionContext, runIndex: number, _unused: any[]) {
  const outputDir = getOutputDir();
  const allVars = mergeAllVars(outputDir);
  const runs = clusterIntoRuns(allVars);
  const run = runs[runIndex] ?? (runs.length > 0 ? runs[runs.length - 1] : new Map());

  const panel = vscode.window.createWebviewPanel(
    'wcfRunInspector',
    'Run Recording Inspection',
    vscode.ViewColumn.One,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  const allRunEvents: MergedEvent[] = [];
  for (const evs of run.values()) { allRunEvents.push(...evs); }
  allRunEvents.sort((a, b) => a.ts_ns - b.ts_ns);

  let durationMs = 0;
  if (allRunEvents.length > 1) {
    durationMs = Math.round((allRunEvents[allRunEvents.length - 1].ts_ns - allRunEvents[0].ts_ns) / 1e6);
  }

  panel.webview.html = buildHtml(runIndex, run, allRunEvents, durationMs);

  panel.webview.onDidReceiveMessage((msg) => {
    if (msg.type === 'goToLine' && msg.file && msg.line) {
      vscode.workspace.openTextDocument(msg.file).then(doc => {
        vscode.window.showTextDocument(doc).then(editor => {
          const line = Math.max(0, msg.line - 1);
          const pos = new vscode.Position(line, 0);
          editor.selection = new vscode.Selection(pos, pos);
          editor.revealRange(new vscode.Range(pos, pos), vscode.TextEditorRevealType.InCenter);
        });
      }).then(undefined, () => {});
    }
  });
}

function fmtTs(ns: number): string {
  return new Date(ns / 1e6).toISOString().slice(0, 23) + 'Z';
}

function buildHtml(
  runIndex: number,
  run: Map<string, MergedEvent[]>,
  allRunEvents: MergedEvent[],
  durationMs: number
): string {
  const varNames = Array.from(run.keys());
  const firstEv = allRunEvents[0];

  const byVarJson = JSON.stringify(Object.fromEntries(run.entries()));
  const allRunEvJson = JSON.stringify(allRunEvents);

  // Main variable sections: value display + slider only (no inline metadata)
  const varSections = varNames.map(varName => {
    const evs = run.get(varName) || [];
    const lastRepr = evs[evs.length - 1]?.repr || '(no data)';
    return `
    <div class="var-section" data-var="${esc(varName)}">
      <div class="var-header">${esc(varName)}</div>
      <div class="var-value-body">
        <div class="val-text" id="vtext-${esc(varName)}">${esc(lastRepr)}</div>
        <div class="ver-row">
          <span class="ver-label" id="vlabel-${esc(varName)}">Version ${evs.length} of ${evs.length}</span>
          <input type="range" class="ver-slider" min="0" max="${Math.max(0, evs.length - 1)}"
                 value="${Math.max(0, evs.length - 1)}"
                 oninput="setVarVersion('${esc(varName)}', this.value)">
        </div>
      </div>
    </div>`;
  }).join('');

  // Build unified metadata panel content (initial: last var in list, or first)
  // Will be updated by JS on variable selection or global step change
  const metaVar = varNames[0];
  const metaEvs = metaVar ? (run.get(metaVar) || []) : [];
  const metaFirst = metaEvs[0];
  const metaLast = metaEvs[metaEvs.length - 1];

  const metaBlocks = varNames.map(varName => {
    const evs = run.get(varName) || [];
    const first = evs[0];
    const last = evs[evs.length - 1];
    return `
    <div class="meta-block" id="mblock-${esc(varName)}">
      <div class="meta-var-title">${esc(varName)}</div>
      <div class="mr"><span class="ml">Variable name:</span><span class="mv">${esc(varName)}</span></div>
      <div class="mr"><span class="ml">Scope:</span><span class="mv">${esc(first?.scope || '—')}</span></div>
      <div class="mr"><span class="ml">Type:</span><span class="mv" id="mvtype-${esc(varName)}">${esc(first?.type || '—')}</span></div>
      <div class="mr"><span class="ml">SQL</span><span class="mv" id="mvsql-${esc(varName)}">${first?.sql_context ? 'True' : 'False'}</span></div>
      <div class="mr"><span class="ml">Threads id:</span><span class="mv">${first?.thread_id ?? 2001}</span></div>
      <div class="mr"><span class="ml">First seen:</span><span class="mv small">${first ? fmtTs(first.ts_ns) : '—'}</span></div>
      <div class="mr"><span class="ml">Last seen:</span><span class="mv small">${last ? fmtTs(last.ts_ns) : '—'}</span></div>
      <div class="mr"><span class="ml">File Path:</span><span class="mv small" id="mvfile-${esc(varName)}">${esc(first?.file || '—')}</span></div>
      <div class="mr"><span class="ml">Line no.:</span><span class="mv" id="mvline-${esc(varName)}">${first?.line || '—'}</span></div>
      <div class="mr"><span class="ml">Code Line:</span><span class="mv" id="mvcode-${esc(varName)}">${esc(first?.fn || '—')}</span></div>
      <div class="mr"><span class="ml">Total versions:</span><span class="mv">${evs.length}</span></div>
    </div>`;
  }).join('<hr class="meta-sep">');

  const globalDots = allRunEvents.map((ev, i) => {
    const isHead = i === allRunEvents.length - 1;
    return `<div class="g-dot${isHead ? ' head' : ''}" data-idx="${i}" onclick="selectGlobal(${i})" title="Step ${i+1}: Line ${ev.line || '?'} — ${esc(ev.varName)}"></div>`;
  }).join('');

  return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  * { box-sizing: border-box; }
  body { font-family: var(--vscode-font-family); font-size: 13px;
         background: var(--vscode-editor-background); color: var(--vscode-foreground);
         margin: 0; display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
  /* Top bar */
  .top-bar { display: flex; align-items: center; padding: 8px 14px; gap: 12px;
             border-bottom: 1px solid var(--vscode-panel-border);
             background: var(--vscode-titleBar-activeBackground); flex-shrink: 0; }
  .back-btn { background: var(--vscode-button-secondaryBackground); border: none;
              border-radius: 4px; padding: 4px 10px; cursor: pointer;
              color: var(--vscode-foreground); font-size: 12px; }
  .back-btn:hover { background: var(--vscode-button-secondaryHoverBackground); }
  .run-title { flex: 1; text-align: center; font-size: 14px; font-weight: 700; }
  .status-tag { font-size: 12px; color: var(--vscode-descriptionForeground); }
  /* Context bar */
  .ctx-bar { display: flex; align-items: center; gap: 24px; padding: 6px 14px;
             font-size: 12px; border-bottom: 1px solid var(--vscode-panel-border); flex-shrink: 0; }
  .ctx-item { display: flex; align-items: center; gap: 5px; }
  .ctx-lbl { color: var(--vscode-descriptionForeground); }
  .ctx-val { font-family: monospace; font-weight: 500; }
  .pinned { margin-left: auto; font-size: 10px; letter-spacing: 0.08em;
            text-transform: uppercase; color: var(--vscode-descriptionForeground); }
  /* Main layout: scroll area + metadata sidebar */
  .main-layout { display: flex; flex: 1; overflow: hidden; }
  .scroll-area { flex: 1; overflow-y: auto; padding: 12px;
                 display: flex; flex-direction: column; gap: 12px; }
  /* Variable sections */
  .var-section { border: 1px solid var(--vscode-panel-border); border-radius: 6px; overflow: hidden; }
  .var-header { background: #0d3d3d; color: #4ec9b0; font-weight: 700;
                padding: 8px 14px; font-size: 13px; }
  .var-value-body { padding: 12px; }
  .val-text { font-family: var(--vscode-editor-font-family, monospace); font-size: 12px;
              line-height: 1.65; white-space: pre-wrap;
              background: var(--vscode-textCodeBlock-background); border-radius: 4px;
              padding: 10px; min-height: 80px; border: 1px solid var(--vscode-panel-border); }
  .ver-row { display: flex; align-items: center; gap: 10px; margin-top: 8px; }
  .ver-label { font-size: 11px; color: var(--vscode-descriptionForeground);
               white-space: nowrap; min-width: 100px; }
  .ver-slider { flex: 1; }
  /* Metadata sidebar */
  .meta-sidebar { width: 260px; border-left: 1px solid var(--vscode-panel-border);
                  overflow-y: auto; padding: 12px; flex-shrink: 0; }
  .meta-sidebar-title { font-size: 14px; font-weight: 700; margin-bottom: 14px; }
  .meta-block { margin-bottom: 8px; }
  .meta-var-title { font-size: 12px; font-weight: 700; color: #4ec9b0; margin-bottom: 8px; }
  .mr { display: flex; flex-direction: column; margin-bottom: 5px; }
  .ml { font-size: 10px; color: var(--vscode-descriptionForeground); }
  .mv { font-size: 11.5px; font-weight: 500; word-break: break-all; }
  .mv.small { font-size: 10px; }
  .meta-sep { border: none; border-top: 1px solid var(--vscode-panel-border);
              margin: 12px 0; }
  /* Global timeline bar */
  .global-bar { padding: 8px 14px; border-top: 1px solid var(--vscode-panel-border);
                background: var(--vscode-editor-background); flex-shrink: 0; }
  .step-lbl { text-align: center; font-size: 11px; color: var(--vscode-descriptionForeground); margin-bottom: 4px; }
  .g-dots { display: flex; align-items: center; gap: 10px; overflow-x: auto; padding: 4px 0; }
  .g-dot { width: 14px; height: 14px; border-radius: 50%; background: #4ec9b0;
           cursor: pointer; flex-shrink: 0; border: 2px solid transparent;
           transition: all 0.12s; opacity: 0.65; }
  .g-dot.head { opacity: 1; }
  .g-dot:hover { transform: scale(1.2); opacity: 1; }
  .g-dot.selected { border-color: white; transform: scale(1.3);
                    box-shadow: 0 0 6px #4ec9b050; opacity: 1; }
  .empty { padding: 40px; text-align: center;
           color: var(--vscode-descriptionForeground); font-size: 12px; }
</style>
</head>
<body>
<div class="top-bar">
  <button class="back-btn" onclick="vscode.postMessage({type:'goBack'})">← Back</button>
  <span class="run-title">Run #${runIndex + 1} — Variable Recordings</span>
  <span class="status-tag">Status: Completed | ${durationMs}ms</span>
</div>

<div class="ctx-bar">
  <div class="ctx-item">
    <span class="ctx-lbl">Line no.:</span>
    <span class="ctx-val" id="gLine">${firstEv?.line || '—'}</span>
  </div>
  <div class="ctx-item">
    <span class="ctx-lbl">Code line:</span>
    <span class="ctx-val" id="gCode">⚑ ${esc(firstEv?.fn || firstEv?.varName || '—')}</span>
  </div>
  <span class="pinned">PINNED CONTEXT HEAD</span>
</div>

<div class="main-layout">
  <div class="scroll-area">
    ${varNames.length === 0
      ? '<div class="empty">No variable data in this run.<br>Execute a tracked script to populate.</div>'
      : varSections}
  </div>

  <div class="meta-sidebar">
    <div class="meta-sidebar-title">Variable Metadata</div>
    ${varNames.length === 0
      ? '<div style="color:var(--vscode-descriptionForeground);font-size:12px;">No data</div>'
      : metaBlocks}
  </div>
</div>

<div class="global-bar">
  <div class="step-lbl" id="stepLbl">Step ${allRunEvents.length}: Line ${allRunEvents[allRunEvents.length-1]?.line || '?'}</div>
  <div class="g-dots" id="gDots">${globalDots}</div>
</div>

<script>
const vscode = acquireVsCodeApi();
const byVar = ${byVarJson};
const allEvs = ${allRunEvJson};

function selectGlobal(idx) {
  const ev = allEvs[idx];
  if (!ev) { return; }

  // Update context bar
  document.getElementById('gLine').textContent = ev.line || '—';
  document.getElementById('gCode').textContent = '⚑ ' + (ev.fn || ev.varName + ' change');
  document.getElementById('stepLbl').textContent = 'Step ' + (idx+1) + ': Line ' + (ev.line || '?');

  // Highlight global dot
  document.querySelectorAll('.g-dot').forEach((d, i) => d.classList.toggle('selected', i === idx));

  // Sync each variable to its version at this point in time
  for (const [varName, evs] of Object.entries(byVar)) {
    let versionIdx = 0;
    for (let i = evs.length - 1; i >= 0; i--) {
      if (evs[i].ts_ns <= ev.ts_ns) { versionIdx = i; break; }
    }
    const sec = document.querySelector('[data-var="' + varName + '"]');
    if (sec) {
      const slider = sec.querySelector('.ver-slider');
      if (slider) { slider.value = versionIdx; }
      setVarVersion(varName, versionIdx);
    }
  }

  // Navigate editor
  if (ev.file && ev.line) {
    vscode.postMessage({ type: 'goToLine', file: ev.file, line: ev.line });
  }
}

function setVarVersion(varName, idx) {
  idx = Number(idx);
  const evs = byVar[varName] || [];
  const ev = evs[idx];
  if (!ev) { return; }

  const vtext = document.getElementById('vtext-' + varName);
  if (vtext) { vtext.textContent = ev.repr || '(no data)'; }

  const vlabel = document.getElementById('vlabel-' + varName);
  if (vlabel) { vlabel.textContent = 'Version ' + (idx+1) + ' of ' + evs.length; }

  // Update metadata sidebar fields for this var
  if (ev.line) { const el = document.getElementById('mvline-' + varName); if (el) el.textContent = String(ev.line); }
  if (ev.fn)   { const el = document.getElementById('mvcode-' + varName); if (el) el.textContent = ev.fn; }
  if (ev.file) { const el = document.getElementById('mvfile-' + varName); if (el) el.textContent = ev.file; }
  if (ev.sql_context !== undefined) {
    const el = document.getElementById('mvsql-' + varName);
    if (el) el.textContent = ev.sql_context ? 'True' : 'False';
  }
}

// Init at last step
if (allEvs.length > 0) { selectGlobal(allEvs.length - 1); }
</script>
</body>
</html>`;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
