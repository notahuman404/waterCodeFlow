import * as vscode from 'vscode';
import * as cp from 'child_process';
import * as path from 'path';
import * as fs from 'fs';
import { SettingsManager, getWorkspaceRoot } from './settings';

let watcherTerminal: vscode.Terminal | undefined;

export function buildWatcherEnv(extPath: string, outputDir: string): NodeJS.ProcessEnv {
  const backendDir = path.join(extPath, 'backend');
  const watcherDir = path.join(backendDir, 'watcher');
  const storageDir = path.join(backendDir, 'storage_utility');
  const existing = process.env.PYTHONPATH || '';
  return {
    ...process.env,
    PYTHONPATH: [watcherDir, storageDir, existing].filter(Boolean).join(path.delimiter),
    WCF_OUTPUT_DIR: outputDir,
  };
}

/**
 * Generate a wrapper user-script that:
 * 1. Imports our value-capture preamble (wraps watch() to log real Python values)
 * 2. Runs the actual user script
 */
function generateWrapper(extPath: string, userScript: string, outputDir: string): string {
  const wrapperPath = path.join(outputDir, '.wcf_wrapper.py');
  const preamblePath = path.join(extPath, 'backend', 'wcf_value_capture.py');

  const content = `# WCF auto-generated wrapper — do not edit
import os, sys, runpy

os.environ.setdefault("WCF_OUTPUT_DIR", ${JSON.stringify(outputDir)})

try:
    with open(${JSON.stringify(preamblePath)}, "r") as _f:
        exec(compile(_f.read(), ${JSON.stringify(preamblePath)}, "exec"), {"__file__": ${JSON.stringify(preamblePath)}})
except Exception as _e:
    pass  # preamble failure is non-fatal

sys.argv = [${JSON.stringify(userScript)}] + sys.argv[1:]
runpy.run_path(${JSON.stringify(userScript)}, run_name="__main__")
`;

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(wrapperPath, content, 'utf8');
  return wrapperPath;
}

export function runWithWatcher(extPath: string, userScript: string): void {
  const wsRoot = getWorkspaceRoot();
  const ws = SettingsManager.watcher;
  const outputDir = ws.outputDir || path.join(wsRoot, 'watcher_output');

  const wrapperScript = generateWrapper(extPath, userScript, outputDir);
  const args = SettingsManager.buildWatcherArgs(wrapperScript);
  const env = buildWatcherEnv(extPath, outputDir);

  if (watcherTerminal) {
    try { watcherTerminal.dispose(); } catch {}
  }

  watcherTerminal = vscode.window.createTerminal({
    name: 'WCF Watcher',
    cwd: wsRoot,
    env,
  });

  const python = process.platform === 'win32' ? 'python' : 'python3';
  const cmdArgs = args.map(a => (a.includes(' ') ? `"${a}"` : a)).join(' ');
  watcherTerminal.sendText(`${python} -m watcher.cli.main ${cmdArgs}`);
  watcherTerminal.show(false);
}

export function runNormally(filePath: string, lang: string): void {
  const wsRoot = getWorkspaceRoot();
  const term = vscode.window.createTerminal({ name: 'WCF Run', cwd: wsRoot });

  let cmd: string;
  if (lang === 'python') {
    cmd = `python3 "${filePath}"`;
  } else if (lang === 'javascript') {
    cmd = `node "${filePath}"`;
  } else {
    const ext = path.extname(filePath).slice(1);
    const base = path.basename(filePath, path.extname(filePath));
    const outBin = path.join(path.dirname(filePath), base);
    if (['c', 'cpp', 'cc'].includes(ext)) {
      const compiler = ext === 'c' ? 'gcc' : 'g++';
      cmd = `${compiler} -O1 -o "${outBin}" "${filePath}" && "${outBin}"`;
    } else {
      cmd = `"${filePath}"`;
    }
  }

  term.sendText(cmd);
  term.show(false);
}
