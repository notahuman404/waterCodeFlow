import * as vscode from 'vscode';
import * as path from 'path';
import { SettingsManager, WatcherSettings, CodeVovleSettings } from './settings';

export function openConfigPanel(ctx: vscode.ExtensionContext) {
  const panel = vscode.window.createWebviewPanel(
    'wcfConfig',
    'WCF Settings',
    vscode.ViewColumn.Beside,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  const ws = SettingsManager.watcher;
  const cv = SettingsManager.codevovle;
  panel.webview.html = buildHtml(ws, cv);

  panel.webview.onDidReceiveMessage((msg) => {
    if (msg.type === 'saveWatcher') {
      SettingsManager.setWatcher(msg.settings as WatcherSettings);
      vscode.window.showInformationMessage('Watcher settings saved.');
    }
    if (msg.type === 'saveCodeVovle') {
      SettingsManager.setCodeVovle(msg.settings as CodeVovleSettings);
      vscode.window.showInformationMessage('CodeVovle settings saved.');
    }
    if (msg.type === 'browseProcessor') {
      vscode.window.showOpenDialog({
        canSelectFiles: true,
        canSelectFolders: false,
        filters: { 'Script': ['py', 'js'] },
        title: 'Select Custom Processor',
      }).then(uris => {
        if (uris && uris.length > 0) {
          panel.webview.postMessage({ type: 'setProcessor', path: uris[0].fsPath });
        }
      });
    }
  });
}

function buildHtml(ws: WatcherSettings, cv: CodeVovleSettings): string {
  const toggle = (id: string, label: string, val: boolean, onChange: string) => `
    <div class="setting-row">
      <span class="setting-label">${label}</span>
      <label class="toggle">
        <input type="checkbox" id="${id}" ${val ? 'checked' : ''} onchange="${onChange}">
        <span class="slider"></span>
      </label>
    </div>`;

  const select = (id: string, label: string, options: string[], val: string, onChange: string) => `
    <div class="setting-row">
      <span class="setting-label">${label}</span>
      <select id="${id}" class="select-ctrl" onchange="${onChange}">
        ${options.map(o => `<option value="${o}" ${o === val ? 'selected' : ''}>${o}</option>`).join('')}
      </select>
    </div>`;

  return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  body { font-family: var(--vscode-font-family); font-size: 13px;
         background: var(--vscode-sideBar-background); color: var(--vscode-foreground);
         margin: 0; padding: 0; }
  .section-title { padding: 10px 14px 6px; font-size: 13px; font-weight: 600;
                   border-bottom: 1px solid var(--vscode-panel-border);
                   background: var(--vscode-sideBarSectionHeader-background); }
  .setting-row { display: flex; align-items: center; justify-content: space-between;
                 padding: 8px 14px; border-bottom: 1px solid var(--vscode-panel-border); }
  .setting-label { font-size: 13px; }
  .toggle { position: relative; display: inline-block; width: 36px; height: 20px; }
  .toggle input { opacity: 0; width: 0; height: 0; }
  .slider { position: absolute; cursor: pointer; inset: 0;
            background: var(--vscode-button-secondaryBackground); border-radius: 20px; transition: .2s; }
  .slider:before { position: absolute; content: ""; height: 14px; width: 14px; left: 3px; bottom: 3px;
                   background: white; border-radius: 50%; transition: .2s; }
  input:checked + .slider { background: var(--vscode-button-background); }
  input:checked + .slider:before { transform: translateX(16px); }
  .select-ctrl { background: var(--vscode-dropdown-background); color: var(--vscode-dropdown-foreground);
                 border: 1px solid var(--vscode-dropdown-border); border-radius: 4px; padding: 4px 8px;
                 font-size: 12px; min-width: 130px; }
  .input-ctrl { background: var(--vscode-input-background); color: var(--vscode-input-foreground);
                border: 1px solid var(--vscode-input-border); border-radius: 4px; padding: 4px 8px;
                font-size: 12px; width: 80px; }
  .browse-row { display: flex; gap: 6px; }
  .browse-input { flex: 1; background: var(--vscode-input-background); color: var(--vscode-input-foreground);
                  border: 1px solid var(--vscode-input-border); border-radius: 4px; padding: 4px 8px;
                  font-size: 11px; }
  .browse-btn { background: var(--vscode-button-secondaryBackground); color: var(--vscode-button-secondaryForeground);
                border: 1px solid var(--vscode-button-border, transparent); border-radius: 4px;
                padding: 4px 8px; cursor: pointer; font-size: 11px; display:flex;align-items:center;gap:4px; }
  .browse-btn:hover { background: var(--vscode-button-secondaryHoverBackground); }
  .rec-mode-btns { display: flex; gap: 6px; }
  .rec-btn { background: var(--vscode-button-secondaryBackground); color: var(--vscode-button-secondaryForeground);
             border: 1px solid var(--vscode-button-border, transparent); border-radius: 4px;
             padding: 4px 12px; cursor: pointer; font-size: 12px; }
  .rec-btn.active { background: var(--vscode-button-background); color: var(--vscode-button-foreground); }
  .hint { font-size: 11px; color: var(--vscode-descriptionForeground); }
</style>
</head>
<body>
<div class="section-title">Watcher Settings</div>

${toggle('trackThreads', 'Track Threads', ws.trackThreads, 'save()')}
${toggle('trackLocals', 'Track Locals', ws.trackLocals, 'save()')}
${toggle('trackSql', 'Track SQL', ws.trackSql, 'save()')}
${toggle('trackAll', 'Track All', ws.trackAll, 'save()')}

<div class="setting-row">
  <span class="setting-label">Mutation Depth</span>
  <select id="mutationDepth" class="select-ctrl" onchange="save()">
    <option value="FULL" ${ws.mutationDepth === 'FULL' ? 'selected' : ''}>Full</option>
    <option value="FULL" ${ws.mutationDepth === 'FULL' ? 'selected' : ''}>Custom &amp; Full</option>
    <option value="1024" ${ws.mutationDepth === '1024' ? 'selected' : ''}>1024 bytes</option>
    <option value="4096" ${ws.mutationDepth === '4096' ? 'selected' : ''}>4096 bytes</option>
  </select>
</div>

<div class="setting-row">
  <span class="setting-label">Files Scope</span>
  <span class="hint">Configured via Variables panel</span>
</div>

<div class="setting-row">
  <span class="setting-label">Max Queue Size</span>
  <input type="number" id="maxQueueSize" class="input-ctrl" value="${ws.maxQueueSize}" min="100" max="100000" onchange="save()">
</div>

${select('logLevel', 'Log Level', ['INFO', 'DEBUG'], ws.logLevel, 'save()')}

<div class="setting-row">
  <span class="setting-label">Custom Processor</span>
  <div class="browse-row">
    <input type="text" id="customProcessor" class="browse-input" value="${esc(ws.customProcessor)}" placeholder="Attach...">
    <button class="browse-btn" onclick="browse()">📁</button>
  </div>
</div>

<div class="section-title" style="margin-top:8px;">Code Volvo (Recording) Settings</div>

<div class="setting-row">
  <span class="setting-label">Sampling Interval</span>
  <span style="display:flex;align-items:center;gap:4px;">
    <input type="number" id="samplingInterval" class="input-ctrl" value="${cv.samplingInterval}"
           min="0.1" max="60" step="0.1" onchange="saveCV()">
    <span class="hint">s</span>
    <span class="hint" style="margin-left:4px;">hint timing</span>
  </span>
</div>

<div class="setting-row">
  <span class="setting-label">Daemon Threads</span>
  <input type="number" id="daemonThreads" class="input-ctrl" value="${cv.daemonThreads}"
         min="1" max="32" onchange="saveCV()">
</div>

${select('aiModel', 'AI Model', ['gemini', 'chatgpt', 'claude'], cv.aiModel, 'saveCV()')}

<div class="setting-row">
  <span class="setting-label">Recording Mode</span>
  <div class="rec-mode-btns">
    <button class="rec-btn ${cv.recordingMode === 'foreground' ? '' : 'active'}" id="btnBg" onclick="setRecMode('background')">Background</button>
    <button class="rec-btn ${cv.recordingMode === 'foreground' ? 'active' : ''}" id="btnFg" onclick="setRecMode('foreground')">Reset</button>
  </div>
</div>

<script>
const vscode = acquireVsCodeApi();

let recMode = '${cv.recordingMode}';

function save() {
  vscode.postMessage({ type: 'saveWatcher', settings: {
    trackThreads: document.getElementById('trackThreads').checked,
    trackLocals:  document.getElementById('trackLocals').checked,
    trackSql:     document.getElementById('trackSql').checked,
    trackAll:     document.getElementById('trackAll').checked,
    mutationDepth: document.getElementById('mutationDepth').value,
    maxQueueSize: Number(document.getElementById('maxQueueSize').value),
    logLevel:     document.getElementById('logLevel').value,
    customProcessor: document.getElementById('customProcessor').value,
    outputDir:    '',
  }});
}

function saveCV() {
  vscode.postMessage({ type: 'saveCodeVovle', settings: {
    samplingInterval: Number(document.getElementById('samplingInterval').value),
    daemonThreads:    Number(document.getElementById('daemonThreads').value),
    aiModel:          document.getElementById('aiModel').value,
    recordingMode:    recMode,
  }});
}

function setRecMode(mode) {
  recMode = mode;
  document.getElementById('btnBg').classList.toggle('active', mode === 'background');
  document.getElementById('btnFg').classList.toggle('active', mode === 'foreground');
  saveCV();
}

function browse() {
  vscode.postMessage({ type: 'browseProcessor' });
}

window.addEventListener('message', e => {
  const msg = e.data;
  if (msg.type === 'setProcessor') {
    document.getElementById('customProcessor').value = msg.path;
    save();
  }
});
</script>
</body>
</html>`;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
