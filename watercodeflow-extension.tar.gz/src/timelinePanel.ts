import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import { RecordedFile, SettingsManager, getWorkspaceRoot } from './settings';
import { runCodevovle, listDiffFiles, readDiff } from './codevovleRunner';
import { openInsightsWebview } from './insightsWebview';

let timelinePanel: vscode.WebviewPanel | undefined;

export function openTimelinePanel(ctx: vscode.ExtensionContext, rf: RecordedFile) {
  if (timelinePanel) {
    try { timelinePanel.dispose(); } catch {}
  }

  timelinePanel = vscode.window.createWebviewPanel(
    'wcfTimeline',
    'Recording Viewer',
    { viewColumn: vscode.ViewColumn.Beside, preserveFocus: false },
    { enableScripts: true, retainContextWhenHidden: true }
  );
  // Move to bottom by setting the view column appropriately
  // In VS Code, to get a bottom panel we use the bottom editor group
  // We'll open in a new editor group instead and let the user drag it

  const wsRoot = getWorkspaceRoot();

  async function loadTimeline() {
    const ticks = listDiffFiles(wsRoot, rf.absPath, rf.activeBranch);

    // Get branch list
    const branchRes = await runCodevovle(ctx.extensionPath, ['branch', 'list', '--file', rf.absPath], wsRoot);
    const branches = parseBranchList(branchRes.stdout);

    // Current status
    const statusRes = await runCodevovle(ctx.extensionPath, ['status', '--file', rf.absPath], wsRoot);

    timelinePanel!.webview.html = buildHtml(rf, ticks, branches, statusRes.stdout);
  }

  loadTimeline();

  timelinePanel.webview.onDidReceiveMessage(async (msg) => {
    if (msg.type === 'revertTo') {
      const args = ['revert', '--file', rf.absPath, '--at', String(msg.tick)];
      const res = await runCodevovle(ctx.extensionPath, args, wsRoot);
      if (res.code === 0) {
        vscode.window.showInformationMessage(`Reverted to tick ${msg.tick}`);
        // Reload the active editor document
        const doc = vscode.workspace.textDocuments.find(d => d.fileName === rf.absPath);
        if (doc) {
          await vscode.commands.executeCommand('workbench.action.revertFile');
        }
      } else {
        vscode.window.showErrorMessage(`Revert failed: ${res.stderr || res.stdout}`);
      }
    }

    if (msg.type === 'openInsights') {
      openInsightsWebview(ctx, rf, msg.branches);
    }

    if (msg.type === 'jumpBranch') {
      const args = ['branch', 'jump', '--file', rf.absPath, msg.branch];
      const res = await runCodevovle(ctx.extensionPath, args, wsRoot);
      if (res.code === 0) {
        rf.activeBranch = msg.branch;
        const recs = SettingsManager.recordedFiles;
        const found = recs.find(r => r.absPath === rf.absPath);
        if (found) { found.activeBranch = msg.branch; SettingsManager.setRecordedFiles(recs); }
        await loadTimeline();
        vscode.window.showInformationMessage(`Jumped to branch: ${msg.branch}`);
      } else {
        vscode.window.showErrorMessage(`Branch jump failed: ${res.stderr || res.stdout}`);
      }
    }

    if (msg.type === 'renameBranch') {
      const args = ['branch', 'rename', '--file', rf.absPath, msg.branch, msg.newName];
      const res = await runCodevovle(ctx.extensionPath, args, wsRoot);
      if (res.code === 0) {
        await loadTimeline();
        vscode.window.showInformationMessage(`Branch renamed to: ${msg.newName}`);
      } else {
        vscode.window.showErrorMessage(`Rename failed: ${res.stderr || res.stdout}`);
      }
    }

    if (msg.type === 'refresh') {
      await loadTimeline();
    }
  });
}

interface BranchInfo {
  id: string;
  label: string;
  parent: string | null;
  headTick: number | null;
  diffCount: number;
}

function parseBranchList(stdout: string): BranchInfo[] {
  const branches: BranchInfo[] = [];
  // Branch list output: bullet points with branch names
  const lines = stdout.split('\n').filter(l => l.includes('•') || l.match(/^\s*[\w/]+/));
  for (const line of lines) {
    const trimmed = line.replace(/^[\s•*-]+/, '').trim();
    if (trimmed && !trimmed.startsWith('📋') && !trimmed.startsWith('ℹ️')) {
      branches.push({
        id: trimmed,
        label: trimmed.split('/').pop() || trimmed,
        parent: trimmed.includes('/') ? trimmed.split('/').slice(0, -1).join('/') : null,
        headTick: null,
        diffCount: 0,
      });
    }
  }
  if (branches.length === 0) {
    branches.push({ id: 'main', label: 'main', parent: null, headTick: null, diffCount: 0 });
  }
  return branches;
}

function buildHtml(rf: RecordedFile, ticks: number[], branches: BranchInfo[], statusText: string): string {
  const totalDiffs = ticks.length;
  const fileName = path.basename(rf.relPath);

  // Build tick dots for timeline scrubber
  const dots = ticks.map((t, i) => `
    <div class="tick-dot" data-tick="${t}" data-idx="${i}" title="Tick ${t}" onclick="selectTick(${t}, ${i})">
      <div class="dot"></div>
    </div>`).join('');

  const branchRows = branches.map(b => `
    <div class="branch-row">
      <span class="branch-name" onclick="jumpBranch('${esc(b.id)}')">${esc(b.label)}</span>
      <button class="rename-btn" onclick="startRename('${esc(b.id)}', '${esc(b.label)}', this)">rename</button>
      <input type="text" class="rename-input hidden" placeholder="${esc(b.label)}"
             onkeydown="submitRename(event, '${esc(b.id)}', this)" onblur="cancelRename(this)">
    </div>`).join('');

  return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  body { font-family: var(--vscode-font-family); font-size: 13px;
         background: var(--vscode-editor-background); color: var(--vscode-foreground);
         margin: 0; padding: 0; display: flex; flex-direction: column; height: 100vh; }
  .title-bar { display: flex; align-items: center; justify-content: space-between;
               padding: 6px 14px; border-bottom: 1px solid var(--vscode-panel-border);
               background: var(--vscode-titleBar-activeBackground); }
  .title-bar-text { font-size: 12px; font-weight: 600; opacity: 0.8; }
  .close-btn { background: none; border: none; cursor: pointer; color: var(--vscode-foreground);
               opacity: 0.7; font-size: 14px; }
  .timeline-wrap { padding: 10px 14px; border-bottom: 1px solid var(--vscode-panel-border); }
  .scrubber { display: flex; align-items: center; gap: 4px; overflow-x: auto; padding: 8px 0; }
  .nav-btn { background: var(--vscode-button-secondaryBackground); border: none; border-radius: 4px;
             cursor: pointer; color: var(--vscode-foreground); padding: 6px 10px; font-size: 13px; flex-shrink: 0; }
  .nav-btn:hover { background: var(--vscode-button-secondaryHoverBackground); }
  .pause-btn { background: var(--vscode-button-secondaryBackground); border: none; border-radius: 4px;
               cursor: pointer; color: var(--vscode-foreground); padding: 6px 10px; flex-shrink: 0; }
  .tick-dots { display: flex; gap: 12px; align-items: center; flex: 1; overflow-x: auto; padding: 0 8px; }
  .tick-dot { cursor: pointer; display: flex; flex-direction: column; align-items: center; flex-shrink: 0; }
  .tick-dot .dot { width: 14px; height: 14px; border-radius: 50%;
                   background: var(--vscode-editor-selectionBackground);
                   border: 2px solid var(--vscode-panel-border); transition: all 0.15s; }
  .tick-dot:hover .dot { background: var(--vscode-button-background); border-color: var(--vscode-button-background); }
  .tick-dot.selected .dot { background: #4ec9b0; border-color: #4ec9b0; }
  .diff-label { display: flex; justify-content: space-between; padding: 2px 0; font-size: 11px;
                color: var(--vscode-descriptionForeground); }
  .bottom-controls { display: flex; gap: 8px; padding: 10px 14px; border-bottom: 1px solid var(--vscode-panel-border);
                     align-items: center; }
  .action-btn { background: var(--vscode-button-secondaryBackground); border: none; border-radius: 6px;
                color: var(--vscode-button-secondaryForeground); padding: 6px 14px; cursor: pointer;
                font-size: 12px; display: flex; align-items: center; gap: 6px; }
  .action-btn:hover { background: var(--vscode-button-secondaryHoverBackground); }
  .branch-dropdown { position: relative; }
  .branch-menu { display: none; position: absolute; bottom: 100%; left: 0; z-index: 10;
                 background: var(--vscode-dropdown-background); border: 1px solid var(--vscode-dropdown-border);
                 border-radius: 6px; min-width: 200px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); }
  .branch-menu.open { display: block; }
  .branch-row { display: flex; align-items: center; gap: 8px; padding: 6px 12px;
                border-bottom: 1px solid var(--vscode-panel-border); }
  .branch-row:last-child { border-bottom: none; }
  .branch-name { flex: 1; cursor: pointer; font-size: 12px; }
  .branch-name:hover { text-decoration: underline; }
  .rename-btn { background: none; border: none; color: var(--vscode-textLink-foreground);
                cursor: pointer; font-size: 11px; padding: 2px 6px; }
  .rename-btn:hover { text-decoration: underline; }
  .rename-input { font-size: 11px; padding: 2px 6px; background: var(--vscode-input-background);
                  color: var(--vscode-input-foreground); border: 1px solid var(--vscode-input-border);
                  border-radius: 3px; }
  .hidden { display: none; }
  .diff-info { padding: 6px 14px; font-size: 12px; color: var(--vscode-descriptionForeground); }
  .selected-tick-info { padding: 6px 14px; font-size: 12px; font-weight: 500; }
</style>
</head>
<body>
<div class="title-bar">
  <span class="title-bar-text">Recording Viewer — ${esc(fileName)}</span>
  <button class="close-btn" onclick="closePanel()" title="Close">✕</button>
</div>

<div class="timeline-wrap">
  <div class="scrubber">
    <button class="nav-btn" onclick="navigate(-1)" title="Previous">◀</button>
    <button class="pause-btn" title="Pause/Play">❚❚ ❚</button>
    <div class="tick-dots" id="tickDots">
      ${totalDiffs === 0 ? '<span style="font-size:12px;color:var(--vscode-descriptionForeground);">No diffs recorded yet</span>' : dots}
    </div>
    <button class="nav-btn" onclick="navigate(1)" title="Next">▶</button>
  </div>
  <div class="diff-label">
    <span>Diff Points</span>
    <span>${totalDiffs} changes</span>
  </div>
</div>

<div id="selectedTickInfo" class="selected-tick-info"></div>

<div class="bottom-controls">
  <div class="branch-dropdown">
    <button class="action-btn" onclick="toggleBranchMenu()" title="Branches">
      🌿 Branches ▾
    </button>
    <div class="branch-menu" id="branchMenu">
      ${branchRows || '<div style="padding:8px 12px;font-size:12px;color:var(--vscode-descriptionForeground);">No branches</div>'}
    </div>
  </div>
  <button class="action-btn" onclick="openInsights()">📊 Insights</button>
</div>

<script>
const vscode = acquireVsCodeApi();
const ticks = ${JSON.stringify(ticks)};
const branches = ${JSON.stringify(branches.map(b => b.id))};
let currentIdx = ticks.length > 0 ? ticks.length - 1 : -1;
let branchMenuOpen = false;

// Select last tick by default
if (currentIdx >= 0) { selectTick(ticks[currentIdx], currentIdx); }

function selectTick(tick, idx) {
  currentIdx = idx;
  document.querySelectorAll('.tick-dot').forEach((d, i) => {
    d.classList.toggle('selected', i === idx);
  });
  document.getElementById('selectedTickInfo').textContent =
    tick ? \`Selected: Tick \${tick} — click to revert file to this point\` : '';
  vscode.postMessage({ type: 'revertTo', tick });
}

function navigate(dir) {
  if (ticks.length === 0) { return; }
  currentIdx = Math.max(0, Math.min(ticks.length - 1, currentIdx + dir));
  selectTick(ticks[currentIdx], currentIdx);
  // Scroll the selected dot into view
  const dots = document.querySelectorAll('.tick-dot');
  if (dots[currentIdx]) { dots[currentIdx].scrollIntoView({ block: 'nearest', inline: 'center' }); }
}

function toggleBranchMenu() {
  branchMenuOpen = !branchMenuOpen;
  document.getElementById('branchMenu').classList.toggle('open', branchMenuOpen);
}

document.addEventListener('click', e => {
  if (!e.target.closest('.branch-dropdown')) {
    branchMenuOpen = false;
    const m = document.getElementById('branchMenu');
    if (m) { m.classList.remove('open'); }
  }
});

function jumpBranch(branchId) {
  branchMenuOpen = false;
  document.getElementById('branchMenu').classList.remove('open');
  vscode.postMessage({ type: 'jumpBranch', branch: branchId });
}

function startRename(branchId, currentLabel, btn) {
  const row = btn.closest('.branch-row');
  const input = row.querySelector('.rename-input');
  input.value = currentLabel;
  input.classList.remove('hidden');
  btn.classList.add('hidden');
  input.focus();
}

function submitRename(e, branchId, input) {
  if (e.key === 'Enter') {
    const newName = input.value.trim();
    if (newName && newName !== branchId.split('/').pop()) {
      vscode.postMessage({ type: 'renameBranch', branch: branchId, newName });
    }
    cancelRename(input);
  }
  if (e.key === 'Escape') { cancelRename(input); }
}

function cancelRename(input) {
  const row = input.closest('.branch-row');
  const btn = row.querySelector('.rename-btn');
  input.classList.add('hidden');
  btn.classList.remove('hidden');
}

function openInsights() {
  vscode.postMessage({ type: 'openInsights', branches });
}

function closePanel() {
  // Can't close programmatically, but give feedback
  vscode.postMessage({ type: 'close' });
}
</script>
</body>
</html>`;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
