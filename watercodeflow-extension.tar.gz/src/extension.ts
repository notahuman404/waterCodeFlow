import * as vscode from 'vscode';
import * as path from 'path';
import { SettingsManager, getWorkspaceRoot } from './settings';
import { openWatcherPanel } from './watcherPanel';
import { openConfigPanel } from './configPanel';
import { openRecordPanel } from './recordPanel';
import { openRecordingPanel } from './recordingPanel';
import { runWithWatcher, runNormally } from './watcherRunner';

export function activate(ctx: vscode.ExtensionContext) {
  // Initialize settings
  SettingsManager.init(ctx);

  // ── Run button ─────────────────────────────────────────────────────────────
  ctx.subscriptions.push(
    vscode.commands.registerCommand('watercodeflow.runFile', () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) {
        vscode.window.showWarningMessage('No active file to run.');
        return;
      }
      const filePath = editor.document.fileName;
      const lang = editor.document.languageId;
      const extName = path.extname(filePath).toLowerCase();

      const isPythonOrJs = lang === 'python' || lang === 'javascript' ||
                           extName === '.py' || extName === '.js';

      if (!isPythonOrJs) {
        // Non-supported lang: run normally
        runNormally(filePath, lang);
        return;
      }

      // Check if user has any watcher variables configured
      const trackedVars = SettingsManager.trackedVars.filter(v => v.enabled);
      if (trackedVars.length > 0) {
        // Run through watcher
        runWithWatcher(ctx.extensionPath, filePath);
      } else {
        // Ask user
        vscode.window.showInformationMessage(
          'No watcher variables configured. Run normally or open Watcher panel to configure tracking.',
          'Run Normally',
          'Configure Watcher'
        ).then(choice => {
          if (choice === 'Run Normally') {
            runNormally(filePath, lang);
          } else if (choice === 'Configure Watcher') {
            vscode.commands.executeCommand('watercodeflow.openWatcher');
          }
        });
      }
    })
  );

  // ── Watcher (eye) button ────────────────────────────────────────────────
  ctx.subscriptions.push(
    vscode.commands.registerCommand('watercodeflow.openWatcher', () => {
      openWatcherPanel(ctx);
    })
  );

  // ── Record (camera) button ──────────────────────────────────────────────
  ctx.subscriptions.push(
    vscode.commands.registerCommand('watercodeflow.openRecord', () => {
      openRecordPanel(ctx);
    })
  );

  // ── Recording viewer (tape) button ─────────────────────────────────────
  ctx.subscriptions.push(
    vscode.commands.registerCommand('watercodeflow.openRecording', () => {
      openRecordingPanel(ctx);
    })
  );

  // ── Config (gear) button ────────────────────────────────────────────────
  ctx.subscriptions.push(
    vscode.commands.registerCommand('watercodeflow.openConfig', () => {
      openConfigPanel(ctx);
    })
  );

  // ── Auto-open watcher on Python/JS file open ───────────────────────────
  // (passive - just show status bar hint)
  const statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
  statusBar.text = '$(eye) WCF';
  statusBar.tooltip = 'WaterCodeFlow active - use toolbar buttons to track variables';
  statusBar.command = 'watercodeflow.openWatcher';
  ctx.subscriptions.push(statusBar);

  const updateStatusBar = () => {
    const editor = vscode.window.activeTextEditor;
    if (editor) {
      const lang = editor.document.languageId;
      const ext = path.extname(editor.document.fileName).toLowerCase();
      if (lang === 'python' || lang === 'javascript' || ext === '.py' || ext === '.js') {
        const tracked = SettingsManager.trackedVars.filter(v => v.enabled).length;
        statusBar.text = tracked > 0 ? `$(eye) WCF: ${tracked} tracked` : '$(eye) WCF';
        statusBar.show();
      } else {
        statusBar.hide();
      }
    } else {
      statusBar.hide();
    }
  };

  ctx.subscriptions.push(vscode.window.onDidChangeActiveTextEditor(updateStatusBar));
  updateStatusBar();
}

export function deactivate() {
  // Clean up daemon processes on extension exit
  // Note: daemons are managed by CodeVovle itself, they persist
}
