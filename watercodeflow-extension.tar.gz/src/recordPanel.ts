import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import { SettingsManager, RecordedFile, getWorkspaceRoot } from './settings';
import { scanWorkspaceFiles, ScannedFile } from './workspaceScanner';
import { runCodevovle, readCodevovleConfig } from './codevovleRunner';

export function openRecordPanel(ctx: vscode.ExtensionContext) {
  const panel = vscode.window.createWebviewPanel(
    'wcfRecord',
    'Record Files',
    vscode.ViewColumn.Beside,
    { enableScripts: true, retainContextWhenHidden: true }
  );

  let files: ScannedFile[] = [];
  let recorded = SettingsManager.recordedFiles;

  async function refresh() {
    files = await scanWorkspaceFiles();
    const wsRoot = getWorkspaceRoot();
    const config = readCodevovleConfig(wsRoot);
    // Update active branch from config
    for (const rf of recorded) {
      const entry = config[rf.absPath];
      if (entry) { rf.activeBranch = entry.active_branch || 'main'; }
    }
    panel.webview.html = buildHtml(files, recorded);
  }

  refresh();

  panel.webview.onDidReceiveMessage(async (msg) => {
    const wsRoot = getWorkspaceRoot();
    const cv = SettingsManager.codevovle;

    if (msg.type === 'toggleFile') {
      const existing = recorded.find(r => r.relPath === msg.relPath);
      if (msg.enabled) {
        if (!existing) {
          const sf = files.find(f => f.relPath === msg.relPath);
          if (sf) {
            recorded.push({
              absPath: sf.absPath,
              relPath: sf.relPath,
              enabled: true,
              activeBranch: 'main',
            });
          }
        } else {
          existing.enabled = true;
        }
        // Start daemon
        const rf = recorded.find(r => r.relPath === msg.relPath);
        if (rf) {
          const args = ['daemon', 'start', '--file', rf.absPath, '--interval', String(cv.samplingInterval)];
          const result = await runCodevovle(ctx.extensionPath, args, wsRoot);
          if (result.code !== 0) {
            // If already running, that's fine
            if (!result.stderr.includes('already running')) {
              vscode.window.showWarningMessage(`Recording: ${result.stderr.trim() || result.stdout.trim()}`);
            }
          }
          // Also set daemon threads
          const threadsArgs = ['daemon', 'set-threads', '--count', String(cv.daemonThreads)];
          await runCodevovle(ctx.extensionPath, threadsArgs, wsRoot);
        }
      } else {
        if (existing) { existing.enabled = false; }
        // Stop daemon
        const rf = files.find(f => f.relPath === msg.relPath);
        if (rf) {
          const args = ['daemon', 'stop', '--file', rf.absPath];
          await runCodevovle(ctx.extensionPath, args, wsRoot);
        }
      }
      SettingsManager.setRecordedFiles(recorded);
    }

    if (msg.type === 'refresh') {
      recorded = SettingsManager.recordedFiles;
      await refresh();
    }
  });
}

function buildHtml(files: ScannedFile[], recorded: RecordedFile[]): string {
  const recordedMap = new Map(recorded.map(r => [r.relPath, r]));

  const rows = files.map(f => {
    const r = recordedMap.get(f.relPath);
    const enabled = r?.enabled ?? false;
    const branch = r?.activeBranch ?? 'main';
    return `
    <div class="file-row ${enabled ? 'active' : ''}">
      <label class="check-wrap">
        <input type="checkbox" ${enabled ? 'checked' : ''} data-rel="${esc(f.relPath)}"
               onchange="toggleFile(this)">
        <span class="file-icon">${f.lang === 'python' ? '🐍' : '📜'}</span>
        <span class="file-name">${esc(path.basename(f.relPath))}</span>
        <span class="file-path">${esc(f.relPath)}</span>
      </label>
      <span class="branch-tag">${esc(branch)}</span>
    </div>`;
  });

  return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  body { font-family: var(--vscode-font-family); font-size: 13px;
         background: var(--vscode-sideBar-background); color: var(--vscode-foreground);
         margin: 0; padding: 0; }
  .toolbar { padding: 8px 12px; border-bottom: 1px solid var(--vscode-panel-border);
             display: flex; align-items: center; gap: 8px; }
  .search { flex: 1; background: var(--vscode-input-background); color: var(--vscode-input-foreground);
            border: 1px solid var(--vscode-input-border); border-radius: 4px; padding: 5px 10px; font-size: 12px; }
  .file-row { display: flex; align-items: center; justify-content: space-between;
              padding: 7px 12px; border-bottom: 1px solid var(--vscode-panel-border); }
  .file-row:hover { background: var(--vscode-list-hoverBackground); }
  .file-row.active { background: var(--vscode-list-activeSelectionBackground); }
  .file-row.active .file-path { color: var(--vscode-list-activeSelectionForeground); }
  .check-wrap { display: flex; align-items: center; gap: 8px; cursor: pointer; flex: 1; }
  .file-icon { font-size: 14px; }
  .file-name { font-weight: 600; }
  .file-path { font-size: 11px; color: var(--vscode-descriptionForeground); margin-left: 4px; }
  .branch-tag { font-size: 11px; background: var(--vscode-badge-background);
                color: var(--vscode-badge-foreground); padding: 2px 8px; border-radius: 10px; }
  .refresh-btn { background: none; border: none; color: var(--vscode-foreground); cursor: pointer;
                 padding: 4px 8px; font-size: 11px; opacity: 0.7; }
  .refresh-btn:hover { opacity: 1; }
  .empty { padding: 20px; text-align: center; color: var(--vscode-descriptionForeground); font-size: 12px; }
</style>
</head>
<body>
<div class="toolbar">
  <input class="search" type="text" placeholder="Enter file path..." oninput="filterFiles(this.value)">
  <button class="refresh-btn" onclick="doRefresh()">↺</button>
</div>
${files.length === 0
  ? '<div class="empty">Type to filter files by name or path.</div>'
  : '<div class="hint-row" style="padding:6px 12px;font-size:11px;color:var(--vscode-descriptionForeground);">Type to filter files by name or path.</div>'}
<div id="fileList">${rows.join('')}</div>

<script>
const vscode = acquireVsCodeApi();

function toggleFile(el) {
  vscode.postMessage({ type: 'toggleFile', relPath: el.dataset.rel, enabled: el.checked });
  const row = el.closest('.file-row');
  row.classList.toggle('active', el.checked);
}

function filterFiles(q) {
  const lq = q.toLowerCase();
  document.querySelectorAll('.file-row').forEach(row => {
    const name = (row.querySelector('.file-name')?.textContent || '').toLowerCase();
    const pathStr = (row.querySelector('.file-path')?.textContent || '').toLowerCase();
    row.style.display = (!lq || name.includes(lq) || pathStr.includes(lq)) ? '' : 'none';
  });
}

function doRefresh() {
  vscode.postMessage({ type: 'refresh' });
}
</script>
</body>
</html>`;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
