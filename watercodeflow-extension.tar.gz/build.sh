#!/usr/bin/env bash
set -euo pipefail

# ─────────────────────────────────────────────────────────────────────────────
# WaterCodeFlow VS Code Extension — Build Script
# Compiles TypeScript, bundles backend, packages .vsix
# ─────────────────────────────────────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Allow override via env var or first argument
BACKEND_SRC="${BACKEND_SRC:-${1:-${SCRIPT_DIR}/../watercodeflow-v7}}"
EXT_DIR="${SCRIPT_DIR}"
BACKEND_DST="${EXT_DIR}/backend"

log() { echo "[build] $*"; }
err() { echo "[build ERROR] $*" >&2; exit 1; }

# ── 1. Verify prerequisites ──────────────────────────────────────────────────
log "Checking prerequisites..."
command -v node  >/dev/null 2>&1 || err "node not found"
command -v npm   >/dev/null 2>&1 || err "npm not found"
command -v npx   >/dev/null 2>&1 || err "npx not found"

# Check if backend source exists
if [ ! -d "${BACKEND_SRC}" ]; then
  err "Backend source not found at ${BACKEND_SRC}. Pass path as arg or set BACKEND_SRC env var."
fi
log "Backend source: ${BACKEND_SRC}"

# ── 2. Install npm dependencies ───────────────────────────────────────────────
log "Installing npm dependencies..."
cd "${EXT_DIR}"
npm install --quiet

# ── 3. Compile TypeScript ─────────────────────────────────────────────────────
log "Compiling TypeScript..."
npx tsc -p tsconfig.json
log "TypeScript compilation complete. Output in ./out/"

# ── 4. Copy backend directories ───────────────────────────────────────────────
log "Copying backend modules..."
rm -rf "${BACKEND_DST}"
mkdir -p "${BACKEND_DST}"

# Copy CodeVovle
if [ -d "${BACKEND_SRC}/CodeVovle" ]; then
  cp -r "${BACKEND_SRC}/CodeVovle" "${BACKEND_DST}/CodeVovle"
  log "  ✓ CodeVovle"
else
  err "CodeVovle directory not found in ${BACKEND_SRC}"
fi

# Copy watcher
if [ -d "${BACKEND_SRC}/watcher" ]; then
  cp -r "${BACKEND_SRC}/watcher" "${BACKEND_DST}/watcher"
  log "  ✓ watcher"
else
  err "watcher directory not found in ${BACKEND_SRC}"
fi

# Copy storage_utility (top-level)
if [ -d "${BACKEND_SRC}/storage_utility" ]; then
  cp -r "${BACKEND_SRC}/storage_utility" "${BACKEND_DST}/storage_utility"
  log "  ✓ storage_utility"
else
  err "storage_utility directory not found in ${BACKEND_SRC}"
fi

# Also copy storage_utility into CodeVovle dir (CodeVovle imports it)
cp -r "${BACKEND_SRC}/storage_utility" "${BACKEND_DST}/CodeVovle/storage_utility" 2>/dev/null || true

# Ensure CodeVovle has storage_utility.py at root level (it imports storage_utility directly)
if [ -f "${BACKEND_SRC}/CodeVovle/storage_utility.py" ]; then
  cp "${BACKEND_SRC}/CodeVovle/storage_utility.py" "${BACKEND_DST}/CodeVovle/storage_utility.py"
fi

# ── 5. Build storage_utility native extension if possible ─────────────────────
log "Checking storage_utility native build..."
if [ -f "${BACKEND_SRC}/storage_utility/faststorage.c" ]; then
  log "  Attempting to build faststorage_c.so..."
  cd "${BACKEND_DST}/storage_utility"
  python3 -c "
import ctypes.util, subprocess, sys, os
c_src = 'faststorage.c'
out = 'faststorage_c.so'
if os.path.exists(c_src) and not os.path.exists(out):
    ret = subprocess.call(['gcc', '-O2', '-shared', '-fPIC', '-o', out, c_src])
    if ret == 0:
        print('  ✓ faststorage_c.so built')
    else:
        print('  ⚠ faststorage_c.so build failed (will use fallback)')
else:
    print('  ✓ faststorage_c.so already exists or no source')
" 2>/dev/null || true
  cd "${EXT_DIR}"
fi

# ── 6. Update .vscodeignore to exclude dev files ──────────────────────────────
log "Writing .vscodeignore..."
cat > "${EXT_DIR}/.vscodeignore" << 'VSCODE_IGNORE'
.vscode/**
.vscode-test/**
src/**
node_modules/**
**/*.ts
!out/**
**/.git
**/.gitignore
**/tsconfig.json
**/.eslintrc*
**/TESTING*
**/tests/**
**/test_*
backend/watcher/tests/**
backend/watcher/examples/**
backend/CodeVovle/tests/**
**/.env
VSCODE_IGNORE

# ── 7. Install vsce if needed and package ─────────────────────────────────────
log "Packaging .vsix..."
cd "${EXT_DIR}"

if ! command -v vsce >/dev/null 2>&1 && ! npx vsce --version >/dev/null 2>&1; then
  log "Installing @vscode/vsce..."
  npm install --save-dev @vscode/vsce --quiet
fi

# Package without verifying publisher (local build)
npx @vscode/vsce package --no-dependencies --allow-missing-repository --allow-package-env-file 2>&1 | tail -20

VSIX_FILE=$(ls -t "${EXT_DIR}"/*.vsix 2>/dev/null | head -1)
if [ -n "${VSIX_FILE}" ]; then
  log ""
  log "════════════════════════════════════════════"
  log " ✅ Build complete!"
  log " 📦 VSIX: ${VSIX_FILE}"
  log " Install: code --install-extension '${VSIX_FILE}'"
  log "════════════════════════════════════════════"
else
  err "VSIX file not found after packaging."
fi
