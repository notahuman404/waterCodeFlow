import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { GlueBridge } from '../GlueBridge';
import { getNonce } from '../utils';

export class RecordingsPanel {
    public static currentPanel: RecordingsPanel | undefined;
    private readonly _panel: vscode.WebviewPanel;
    private _disposables: vscode.Disposable[] = [];
    private _extensionUri: vscode.Uri;

    public static createOrShow(extensionUri: vscode.Uri, bridge: GlueBridge) {
        const column = vscode.window.activeTextEditor?.viewColumn ?? vscode.ViewColumn.One;
        if (RecordingsPanel.currentPanel) {
            RecordingsPanel.currentPanel._panel.reveal(column);
            return;
        }
        const panel = vscode.window.createWebviewPanel(
            'watercodeflow.recordings', 'Recordings', column,
            { enableScripts: true, localResourceRoots: [vscode.Uri.joinPath(extensionUri, 'media')] }
        );
        RecordingsPanel.currentPanel = new RecordingsPanel(panel, extensionUri, bridge);
    }

    /** Forward a run lifecycle event (stdout, stderr, done, error) into the webview. */
    public postRunEvent(type: string, data: string) {
        this._panel.webview.postMessage({ command: 'run.event', type, data });
    }

    private constructor(panel: vscode.WebviewPanel, extensionUri: vscode.Uri, private bridge: GlueBridge) {
        this._panel = panel;
        this._extensionUri = extensionUri;
        this._panel.webview.html = this._getHtml(panel.webview, extensionUri);
        this._panel.onDidDispose(() => this.dispose(), null, this._disposables);

        this._panel.webview.onDidReceiveMessage(async (msg: any) => {
            switch (msg.command) {
                case 'ready':
                    await this._pushData();
                    break;

                case 'openRunInspector':
                    vscode.commands.executeCommand('watercodeflow.openRunInspector');
                    break;

                case 'openVariableInspector':
                    vscode.commands.executeCommand('watercodeflow.openInspector');
                    break;

                case 'deleteRun': {
                    const fp = vscode.window.activeTextEditor?.document.fileName || '';
                    if (fp) {
                        try {
                            await this.bridge.send('deleteRun', { filePath: fp, runId: msg.runId });
                            await this._pushData();
                        } catch (e: any) {
                            vscode.window.showErrorMessage('Delete run failed: ' + e.message);
                        }
                    }
                    break;
                }

                case 'deleteRecording': {
                    const extPath = this._extensionUri.fsPath;
                    const recordingsDir = path.join(extPath, 'built', 'recordings');
                    // Remove JSON file by runId prefix
                    try {
                        const files = fs.readdirSync(recordingsDir);
                        const match = files.find(f => f.startsWith(msg.runId) || f === `${msg.runId}.json`);
                        if (match) {
                            fs.unlinkSync(path.join(recordingsDir, match));
                        }
                    } catch (_) {}
                    // Also tell glue to remove it
                    try {
                        await this.bridge.send('deleteRecording', { runId: msg.runId });
                    } catch (_) {}
                    this._panel.webview.postMessage({ command: 'recordingDeleted', runId: msg.runId });
                    await this._pushData();
                    break;
                }

                case 'exportRecording': {
                    const rec = msg.recording;
                    if (!rec) { break; }
                    const uri = await vscode.window.showSaveDialog({
                        defaultUri: vscode.Uri.file(`recording-${rec.runId || 'export'}.json`),
                        filters: { 'JSON': ['json'] }
                    });
                    if (uri) {
                        fs.writeFileSync(uri.fsPath, JSON.stringify(rec, null, 2));
                        vscode.window.showInformationMessage(`Recording exported to ${uri.fsPath}`);
                    }
                    break;
                }
            }
        });
    }

    private async _pushData() {
        const fp = vscode.window.activeTextEditor?.document.fileName || '';
        const extPath = this._extensionUri.fsPath;

        // ── 1. Real recordings from built/recordings/*.json ──────────────────
        let recordings: any[] = [];
        const recordingsDir = path.join(extPath, 'built', 'recordings');
        try {
            if (fs.existsSync(recordingsDir)) {
                const files = fs.readdirSync(recordingsDir)
                    .filter(f => f.endsWith('.json'))
                    .sort()
                    .reverse(); // newest first
                recordings = files.map(f => {
                    try {
                        return JSON.parse(fs.readFileSync(path.join(recordingsDir, f), 'utf8'));
                    } catch (_) { return null; }
                }).filter(Boolean);
                // Filter to current file if open, but show all if no file active
                if (fp) {
                    const forFile = recordings.filter(r => r.filePath === fp || r.file_path === fp);
                    // Show file-specific recordings if any, otherwise show all
                    if (forFile.length > 0) {
                        recordings = forFile;
                    }
                }
            }
        } catch (_) {}

        // ── 2. Tracked files — derived from recordings ───────────────────────
        let trackedFiles: any[] = [];
        if (fp) {
            try {
                const recs = await this.bridge.send('listRecordings', { filePath: fp }) as any[];
                if (recs && recs.length > 0) {
                    trackedFiles = [{ name: path.basename(fp), path: fp }];
                }
            } catch (_) {}
        }
        // Also derive from the recordings we already loaded
        if (trackedFiles.length === 0 && recordings.length > 0) {
            const seen = new Set<string>();
            recordings.forEach(r => {
                const p = r.filePath || r.file_path || '';
                if (p && !seen.has(p)) {
                    seen.add(p);
                    trackedFiles.push({ name: path.basename(p), path: p });
                }
            });
        }

        // ── 3. Variable evolutions from glue (AST-based, real) ───────────────
        let vars: any[] = [];
        if (fp) {
            try {
                vars = await this.bridge.send('listTrackedVariables', { filePath: fp }) as any[];
            } catch (_) {}
        }

        // ── 4. NO fake fallback data ──────────────────────────────────────────
        // If the real sources returned nothing we show empty states in the UI.
        // Fake placeholder data was removed deliberately.

        this._panel.webview.postMessage({
            command: 'setData',
            trackedFiles,
            vars,
            runs: [],         // runs are already in recordings; no duplicate
            recordings,
        });
    }

    public dispose() {
        RecordingsPanel.currentPanel = undefined;
        this._panel.dispose();
        while (this._disposables.length) { this._disposables.pop()?.dispose(); }
    }

    private _getHtml(webview: vscode.Webview, extensionUri: vscode.Uri): string {
        const scriptUri = webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, 'media', 'recordings.js'));
        const styleUri  = webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, 'media', 'recordings.css'));
        const nonce = getNonce();
        return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Security-Policy"
    content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}';">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="${styleUri}" rel="stylesheet">
</head>
<body>
  <div class="recordings-container" id="recordings-container"><div class="loading">Loading…</div></div>
  <script nonce="${nonce}" src="${scriptUri}"></script>
</body>
</html>`;
    }
}
