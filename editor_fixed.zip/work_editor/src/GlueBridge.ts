import * as vscode from 'vscode';
import * as cp from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

export interface GlueResponse {
    id: string;
    success: boolean;
    result?: any;
    error?: string;
}

export interface SpawnRunOptions {
    filePath: string;
    extPath: string;
    language: 'python' | 'javascript';
    onStdout?: (chunk: string) => void;
    onStderr?: (chunk: string) => void;
}

export interface RunResult {
    runId: string;
    filePath: string;
    language: string;
    exitCode: number;
    recordingPath: string;
    timestamp: string;
    durationMs: number;
    useWatcher: boolean;
}

/**
 * GlueBridge: Persistent child process bridge to the Python glue adapter.
 * Sends JSON commands to stdin, reads JSON responses from stdout.
 *
 * PYTHONPATH order matters:
 *   1. extPath/CodeVovle  — codevovle package + its storage_utility.py
 *   2. extPath            — watcher package, storage_utility/ C-ext (lower priority)
 *
 * spawnRun() runs the user's file through:
 *   - Python: watcher CLI (variable mutation tracking, requires C++ core)
 *             Falls back to plain python3 if watcher CLI is unavailable.
 *   - JS:     watcher JS adapter or plain node.
 *
 * A recording JSON is always written to built/recordings/<runId>.json.
 */
export class GlueBridge {
    private _proc: cp.ChildProcess | null = null;
    private _pending = new Map<string, (res: GlueResponse) => void>();
    private _buf = '';
    private _extensionPath: string;

    constructor(extensionPath: string) {
        this._extensionPath = extensionPath;
    }

    private _spawn() {
        if (this._proc) { return; }

        const adapterPath = path.join(this._extensionPath, 'glue', 'adapter.py');

        // CodeVovle MUST come before extensionPath so codevovle gets the right storage_utility
        const pythonPath = [
            path.join(this._extensionPath, 'CodeVovle'),
            this._extensionPath,
        ].join(path.delimiter);

        this._proc = cp.spawn('python3', [adapterPath], {
            cwd: this._extensionPath,
            env: { ...process.env, PYTHONPATH: pythonPath },
        });

        this._proc.stdout?.on('data', (chunk: Buffer) => {
            this._buf += chunk.toString();
            let nl: number;
            while ((nl = this._buf.indexOf('\n')) !== -1) {
                const line = this._buf.slice(0, nl).trim();
                this._buf = this._buf.slice(nl + 1);
                if (!line) { continue; }
                try {
                    const res: GlueResponse = JSON.parse(line);
                    const cb = this._pending.get(res.id);
                    if (cb) {
                        this._pending.delete(res.id);
                        cb(res);
                    }
                } catch (_) {}
            }
        });

        this._proc.on('exit', () => {
            this._proc = null;
            for (const [, cb] of this._pending) {
                cb({ id: '', success: false, error: 'Bridge process exited' });
            }
            this._pending.clear();
        });

        this._proc.stderr?.on('data', (_chunk: Buffer) => {
            // swallow stderr — python tracebacks are debug-only
        });
    }

    send(command: string, args: Record<string, any> = {}): Promise<any> {
        return new Promise((resolve, reject) => {
            this._spawn();
            const id = Math.random().toString(36).slice(2);
            const msg = JSON.stringify({ id, command, ...args }) + '\n';

            this._pending.set(id, (res) => {
                if (res.success) { resolve(res.result); }
                else { reject(new Error(res.error || 'Glue error')); }
            });

            try {
                this._proc?.stdin?.write(msg);
            } catch (e) {
                this._pending.delete(id);
                reject(e);
            }
        });
    }

    /**
     * Spawn a tracked run for a Python or JavaScript file.
     *
     * Python path:
     *   1. Try watcher CLI  — python3 <extPath>/watcher/cli/main.py --user-script <file>
     *      (tracks variable mutations if C++ core is available)
     *   2. Fallback: plain python3 <file>
     *      (captures stdout/stderr, no mutation tracking)
     *
     * JS path:
     *   node <watcher-js-adapter> <file>  or  node <file>
     *
     * In all cases a recording JSON is written to built/recordings/<runId>.json.
     * The glue adapter is also notified via saveRecording so it can merge metadata.
     */
    async spawnRun(opts: SpawnRunOptions): Promise<RunResult> {
        const { filePath, extPath, language, onStdout, onStderr } = opts;
        const runId = `run-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const timestamp = new Date().toISOString();
        const startMs = Date.now();

        const recordingsDir = path.join(extPath, 'built', 'recordings');
        fs.mkdirSync(recordingsDir, { recursive: true });
        const recordingPath = path.join(recordingsDir, `${runId}.json`);

        // PYTHONPATH: CodeVovle first (correct storage_utility), then root (watcher package)
        const pythonPath = [
            path.join(extPath, 'CodeVovle'),
            extPath,
        ].join(path.delimiter);

        // Watcher CLI is invoked as a script, not as a module (-m watcher.cli breaks)
        const watcherCliScript = path.join(extPath, 'watcher', 'cli', 'main.py');
        const watcherOutputDir = path.join(extPath, 'built', 'watcher_events', runId);

        let proc: cp.ChildProcess;
        let usedWatcher = false;

        if (language === 'python') {
            if (fs.existsSync(watcherCliScript)) {
                // Attempt watcher CLI for variable mutation tracking
                proc = cp.spawn('python3', [
                    watcherCliScript,
                    '--user-script', filePath,
                    '--output', watcherOutputDir,
                    '--log-level', 'WARNING',
                ], {
                    cwd: extPath,
                    env: { ...process.env, PYTHONPATH: pythonPath },
                });
                usedWatcher = true;
            } else {
                proc = cp.spawn('python3', [filePath], {
                    cwd: path.dirname(filePath),
                    env: { ...process.env },
                });
            }
        } else {
            // JavaScript
            const jsAdapterPath = path.join(extPath, 'watcher', 'adapters', 'javascript', 'index.js');
            if (fs.existsSync(jsAdapterPath)) {
                proc = cp.spawn('node', [jsAdapterPath, filePath], { cwd: extPath });
                usedWatcher = true;
            } else {
                proc = cp.spawn('node', [filePath], { cwd: path.dirname(filePath) });
            }
        }

        const stdoutParts: string[] = [];
        const stderrParts: string[] = [];

        proc.stdout?.on('data', (chunk: Buffer) => {
            const s = chunk.toString();
            stdoutParts.push(s);
            onStdout?.(s);
        });

        proc.stderr?.on('data', (chunk: Buffer) => {
            const s = chunk.toString();
            stderrParts.push(s);
            onStderr?.(s);
        });

        let exitCode = await new Promise<number>((resolve) => {
            proc.on('close', (code) => resolve(code ?? 0));
            proc.on('error', () => resolve(1));
        });

        // If watcher failed with EXIT_VALIDATION_ERROR (2) due to missing C++ core,
        // retry as plain python3 so the user still gets their output
        if (usedWatcher && language === 'python' && exitCode === 2) {
            const retryProc = cp.spawn('python3', [filePath], {
                cwd: path.dirname(filePath),
                env: { ...process.env },
            });
            const retryStdout: string[] = [];
            const retryStderr: string[] = [];
            retryProc.stdout?.on('data', (chunk: Buffer) => {
                const s = chunk.toString();
                retryStdout.push(s);
                onStdout?.(s);
            });
            retryProc.stderr?.on('data', (chunk: Buffer) => {
                const s = chunk.toString();
                retryStderr.push(s);
                onStderr?.(s);
            });
            exitCode = await new Promise<number>((resolve) => {
                retryProc.on('close', (code) => resolve(code ?? 0));
                retryProc.on('error', () => resolve(1));
            });
            stdoutParts.push(...retryStdout);
            stderrParts.push(...retryStderr);
            usedWatcher = false;
        }

        const durationMs = Date.now() - startMs;
        const stdoutStr = stdoutParts.join('');
        const stderrStr = stderrParts.join('');

        // Scan watcher output dir for any JSONL event files
        let watcherEventFiles: string[] = [];
        try {
            if (fs.existsSync(watcherOutputDir)) {
                watcherEventFiles = fs.readdirSync(watcherOutputDir)
                    .filter(f => f.endsWith('.jsonl'))
                    .map(f => path.join(watcherOutputDir, f));
            }
        } catch (_) {}

        const recording: RunResult & { stdout: string; stderr: string; watcherEvents?: string[] } = {
            runId,
            filePath,
            language,
            exitCode,
            recordingPath,
            timestamp,
            durationMs,
            useWatcher: usedWatcher,
            stdout: stdoutStr,
            stderr: stderrStr,
            ...(watcherEventFiles.length > 0 ? { watcherEvents: watcherEventFiles } : {}),
        };

        fs.writeFileSync(recordingPath, JSON.stringify(recording, null, 2));

        // Notify glue adapter (non-fatal if it fails)
        this.send('saveRecording', {
            runId,
            recordingPath,
            filePath,
            timestamp,
            durationMs,
            exitCode,
        }).catch(() => {});

        return recording;
    }

    dispose() {
        this._proc?.kill();
        this._proc = null;
    }
}
