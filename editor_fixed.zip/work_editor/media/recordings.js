(function () {
'use strict';
const vscode = acquireVsCodeApi();
const container = document.getElementById('recordings-container');

// ── Helpers ──────────────────────────────────────────────────────────────────

function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}

function fmtDuration(ms) {
  if (ms == null || ms === 0) return '—';
  if (ms < 1000) return ms + 'ms';
  return (ms / 1000).toFixed(2) + 's';
}

function fmtTime(iso) {
  if (!iso) return '—';
  try {
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
      + '  ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch (_) { return iso; }
}

function fmtExit(code) {
  if (code == null) return '';
  return code === 0 ? 'exit 0' : `exit ${code}`;
}

// ── Run log panel ─────────────────────────────────────────────────────────────

let runLogEl = null;

function ensureRunLog() {
  if (runLogEl) return runLogEl;
  runLogEl = el('div', 'run-log');
  runLogEl.appendChild(el('div', 'run-log-title', '⟳ Run output'));
  const pre = el('pre', 'run-log-pre', '');
  pre.id = 'run-log-pre';
  runLogEl.appendChild(pre);
  container.insertBefore(runLogEl, container.firstChild);
  return runLogEl;
}

function appendRunLog(text) {
  const log = ensureRunLog();
  const pre = log.querySelector('#run-log-pre');
  pre.textContent += text;
  pre.scrollTop = pre.scrollHeight;
}

function clearRunLog() {
  if (runLogEl) { runLogEl.remove(); runLogEl = null; }
}

// ── Recording card ────────────────────────────────────────────────────────────

function buildRecordingCard(r) {
  const card = el('div', 'rec-card');
  const runId = r.runId || r.run_id || '';
  card.dataset.runId = runId;
  card.dataset.expanded = 'false';

  // Header
  const header = el('div', 'rec-card-header');
  header.setAttribute('role', 'button');
  header.setAttribute('tabindex', '0');
  header.setAttribute('aria-expanded', 'false');

  const chevron = el('span', 'rec-chevron', '▶');

  const title = el('span', 'rec-card-title');
  const fname = (r.filePath || r.file_path || '').split('/').pop() || 'run';
  title.textContent = fname;

  const meta = el('span', 'rec-card-meta');
  const parts = [
    r.language || '',
    fmtDuration(r.durationMs),
    fmtTime(r.timestamp),
    fmtExit(r.exitCode),
  ].filter(Boolean);
  meta.textContent = parts.join('  ·  ');

  const exitOk = (r.exitCode === 0 || r.exitCode == null);
  const badge = el('span', 'rec-status-badge ' + (exitOk ? 'badge-ok' : 'badge-err'));
  badge.textContent = exitOk ? '✓' : '✗';

  const actions = el('div', 'rec-card-actions');
  actions.addEventListener('click', e => e.stopPropagation());

  const exportBtn = el('button', 'rec-action-btn', '⬆ Export');
  exportBtn.title = 'Export recording as JSON';
  const deleteBtn = el('button', 'rec-action-btn rec-action-delete', '✕');
  deleteBtn.title = 'Delete this recording';

  actions.appendChild(exportBtn);
  actions.appendChild(deleteBtn);

  header.appendChild(chevron);
  header.appendChild(title);
  header.appendChild(meta);
  header.appendChild(badge);
  header.appendChild(actions);

  // Detail section
  const detail = el('div', 'rec-detail');
  detail.setAttribute('aria-hidden', 'true');
  detail.hidden = true;

  // Run metadata table
  const metaTable = el('table', 'rec-meta-table');
  const rows = [
    ['Run ID',    runId || '—'],
    ['File',      r.filePath || r.file_path || '—'],
    ['Language',  r.language || '—'],
    ['Exit code', r.exitCode != null ? String(r.exitCode) : '—'],
    ['Duration',  fmtDuration(r.durationMs)],
    ['Timestamp', r.timestamp ? new Date(r.timestamp).toLocaleString() : '—'],
  ];
  rows.forEach(([k, v]) => {
    const tr = el('tr', '');
    tr.innerHTML = `<td class="rec-meta-key">${k}</td><td class="rec-meta-val">${v}</td>`;
    metaTable.appendChild(tr);
  });
  detail.appendChild(metaTable);

  // Variables captured by watcher
  const vars = r.vars || r.variables || [];
  if (vars.length > 0) {
    detail.appendChild(el('div', 'rec-detail-section-title', 'Captured variables'));
    const table = el('table', 'rec-var-table');
    table.innerHTML = '<thead><tr><th>Name</th><th>Value</th><th>Evolutions</th></tr></thead>';
    const tbody = el('tbody', '');
    vars.forEach(v => {
      const tr = el('tr', '');
      const name = v.name || v;
      const val  = v.value != null ? v.value : '—';
      const evo  = v.evolutions != null ? v.evolutions : 0;
      tr.innerHTML = `<td class="rec-var-name-cell">${name}</td><td class="rec-var-val" data-varname="${name}">${val}</td><td>${evo}</td>`;
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    detail.appendChild(table);
  }

  // stdout
  const stdout = (r.stdout || '').trim();
  if (stdout) {
    detail.appendChild(el('div', 'rec-detail-section-title', 'Output (stdout)'));
    const pre = el('pre', 'rec-detail-pre', '');
    pre.textContent = stdout.length > 4000 ? stdout.slice(0, 4000) + '\n…(truncated)' : stdout;
    detail.appendChild(pre);
  }

  // stderr
  const stderr = (r.stderr || '').trim();
  if (stderr) {
    detail.appendChild(el('div', 'rec-detail-section-title rec-section-err', 'Errors (stderr)'));
    const pre = el('pre', 'rec-detail-pre rec-detail-err', '');
    pre.textContent = stderr.length > 2000 ? stderr.slice(0, 2000) + '\n…(truncated)' : stderr;
    detail.appendChild(pre);
  }

  if (!stdout && !stderr && vars.length === 0) {
    detail.appendChild(el('p', 'rec-hint', 'No output captured.'));
  }

  card.appendChild(header);
  card.appendChild(detail);

  // Expand / collapse
  function toggle() {
    const expanded = card.dataset.expanded === 'true';
    card.dataset.expanded = expanded ? 'false' : 'true';
    header.setAttribute('aria-expanded', String(!expanded));
    chevron.textContent = expanded ? '▶' : '▼';
    detail.hidden = expanded;
    detail.setAttribute('aria-hidden', String(expanded));
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
  });

  exportBtn.addEventListener('click', () => {
    vscode.postMessage({ command: 'exportRecording', runId: card.dataset.runId, recording: r });
  });

  deleteBtn.addEventListener('click', () => {
    vscode.postMessage({ command: 'deleteRecording', runId: card.dataset.runId });
    card.style.opacity = '0.4';
    card.style.pointerEvents = 'none';
  });

  return card;
}

// ── Main render ───────────────────────────────────────────────────────────────

function render(data) {
  container.innerHTML = '';
  const { trackedFiles = [], vars = [], recordings = [] } = data || {};

  // ── SECTION 1: Files — Tracked ────────────────────────────────────────────
  const s1 = el('div', 'rec-section');
  const s1hdr = el('div', 'rec-section-header');
  s1hdr.innerHTML = '<strong>Files</strong><span class="header-normal"> — Tracked</span>';
  s1.appendChild(s1hdr);

  if (trackedFiles.length === 0) {
    s1.appendChild(el('p', 'rec-hint', 'No tracked files yet. Press ▶ to run a Python or JS file.'));
  } else {
    trackedFiles.forEach(f => {
      const row = el('div', 'rec-row');
      row.style.cursor = 'pointer';
      const name = f.name || (f.path || '').split('/').pop() || f.path;
      const fpath = f.path || '';
      row.innerHTML = `<span class="teal-check">&#10003;</span><span class="rec-filename">${name}</span><span class="rec-filepath"> ${fpath}</span>`;
      row.addEventListener('click', () => vscode.postMessage({ command: 'openRunInspector' }));
      s1.appendChild(row);
    });
    s1.appendChild(el('p', 'rec-hint', 'Persisted in Vovle (.codevovle)'));
  }
  container.appendChild(s1);

  // ── SECTION 2: Variables — Evolution ─────────────────────────────────────
  const s2 = el('div', 'rec-section');
  const s2hdr = el('div', 'rec-section-header');
  s2hdr.innerHTML = '<strong>Variables</strong><span class="header-normal"> — Evolution</span>';
  s2.appendChild(s2hdr);

  if (vars.length === 0) {
    s2.appendChild(el('p', 'rec-hint', 'Open a Python or JS file to see its variables.'));
  } else {
    vars.forEach(v => {
      const row = el('div', 'rec-row');
      row.style.cursor = 'pointer';
      const name = typeof v === 'string' ? v : (v.name || String(v));
      const evolutions = v.evolutions != null ? v.evolutions : 0;
      const scope = v.scope ? ` <span class="rec-var-scope">${v.scope}</span>` : '';
      row.innerHTML = `<span class="rec-var-name">${name}</span>${scope}<span class="rec-count">evolutions: ${evolutions}</span>`;
      row.addEventListener('click', () => vscode.postMessage({ command: 'openVariableInspector' }));
      s2.appendChild(row);
    });
    s2.appendChild(el('p', 'rec-hint', 'Updates when variables change across runs'));
  }
  container.appendChild(s2);

  // ── SECTION 3: Runs — Recordings ─────────────────────────────────────────
  const s3 = el('div', 'rec-section');
  const s3hdr = el('div', 'rec-section-header');
  s3hdr.innerHTML = '<strong>Runs</strong><span class="header-normal"> — Recordings</span>';
  s3.appendChild(s3hdr);

  if (recordings.length === 0) {
    s3.appendChild(el('p', 'rec-hint', 'No runs recorded yet. Press ▶ to start.'));
  } else {
    recordings.forEach(r => s3.appendChild(buildRecordingCard(r)));
  }
  container.appendChild(s3);
}

// ── Message handler ───────────────────────────────────────────────────────────

window.addEventListener('message', evt => {
  const msg = evt.data;

  if (msg.command === 'setData') {
    clearRunLog();
    render(msg);
    return;
  }

  if (msg.command === 'run.event') {
    if (msg.type === 'run.start') {
      clearRunLog();
      ensureRunLog();
      appendRunLog('▶ Starting: ' + msg.data + '\n');
    } else if (msg.type === 'run.stdout') {
      appendRunLog(msg.data);
    } else if (msg.type === 'run.stderr') {
      appendRunLog('[stderr] ' + msg.data);
    } else if (msg.type === 'run.done') {
      appendRunLog('\n✓ Run complete\n');
      vscode.postMessage({ command: 'ready' }); // refresh
    } else if (msg.type === 'run.error') {
      appendRunLog('\n✗ Error: ' + msg.data + '\n');
    }
    return;
  }

  if (msg.command === 'recordingDeleted') {
    vscode.postMessage({ command: 'ready' });
    return;
  }
});

vscode.postMessage({ command: 'ready' });
render(null);
})();
