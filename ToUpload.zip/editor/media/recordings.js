(function(){
'use strict';
const vscode = acquireVsCodeApi();
const container = document.getElementById('recordings-container');

// ── Helpers ──────────────────────────────────────────────────────────────────

function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}

function fmtDuration(ms) {
  if (!ms) return '—';
  if (ms < 1000) return ms + 'ms';
  return (ms / 1000).toFixed(2) + 's';
}

function fmtTime(iso) {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleTimeString(); } catch(_){ return iso; }
}

// ── Run log panel (streams stdout/stderr during a live run) ───────────────────

let runLogEl = null;

function ensureRunLog() {
  if (runLogEl) return runLogEl;
  runLogEl = el('div', 'run-log');
  const title = el('div', 'run-log-title', '⟳ Run output');
  runLogEl.appendChild(title);
  const pre = el('pre', 'run-log-pre', '');
  pre.id = 'run-log-pre';
  runLogEl.appendChild(pre);
  container.insertBefore(runLogEl, container.firstChild);
  return runLogEl;
}

function appendRunLog(text) {
  const log = ensureRunLog();
  const pre = log.querySelector('#run-log-pre');
  pre.textContent += text;
  pre.scrollTop = pre.scrollHeight;
}

function clearRunLog() {
  if (runLogEl) { runLogEl.remove(); runLogEl = null; }
}

// ── Recording card builder ────────────────────────────────────────────────────

function buildRecordingCard(r) {
  const card = el('div', 'rec-card');
  card.dataset.runId = r.runId || r.run_id || '';
  card.dataset.expanded = 'false';

  // Header row
  const header = el('div', 'rec-card-header');
  header.setAttribute('role', 'button');
  header.setAttribute('tabindex', '0');
  header.setAttribute('aria-expanded', 'false');

  const chevron = el('span', 'rec-chevron', '▶');
  const title = el('span', 'rec-card-title');
  const fname = (r.filePath || r.file_path || '').split('/').pop() || 'unknown';
  title.textContent = fname;

  const meta = el('span', 'rec-card-meta');
  const lang = r.language || 'python';
  const exit = r.exitCode !== undefined ? `exit ${r.exitCode}` : '';
  const dur  = fmtDuration(r.durationMs);
  const ts   = fmtTime(r.timestamp);
  meta.textContent = [lang, dur, ts, exit].filter(Boolean).join('  ·  ');

  const badge = el('span', 'rec-status-badge ' + (r.exitCode === 0 ? 'badge-ok' : 'badge-err'));
  badge.textContent = r.exitCode === 0 ? '✓' : '✗';

  const actions = el('div', 'rec-card-actions');
  actions.addEventListener('click', e => e.stopPropagation());

  const playBtn = el('button', 'rec-action-btn', '▶ Play');
  playBtn.title = 'Replay variable value changes';
  playBtn.setAttribute('aria-label', 'Play replay');

  const exportBtn = el('button', 'rec-action-btn', '⬆ Export');
  exportBtn.title = 'Export recording as JSON';
  exportBtn.setAttribute('aria-label', 'Export recording');

  const deleteBtn = el('button', 'rec-action-btn rec-action-delete', '✕');
  deleteBtn.title = 'Delete this recording';
  deleteBtn.setAttribute('aria-label', 'Delete recording');

  actions.appendChild(playBtn);
  actions.appendChild(exportBtn);
  actions.appendChild(deleteBtn);

  header.appendChild(chevron);
  header.appendChild(title);
  header.appendChild(meta);
  header.appendChild(badge);
  header.appendChild(actions);

  // Detail section (collapsed by default)
  const detail = el('div', 'rec-detail');
  detail.setAttribute('aria-hidden', 'true');
  detail.hidden = true;

  // Variable table
  const vars = r.vars || r.variables || [];
  if (vars.length > 0) {
    const vtitle = el('div', 'rec-detail-section-title', 'Captured variables');
    detail.appendChild(vtitle);
    const table = el('table', 'rec-var-table');
    table.innerHTML = '<thead><tr><th>Name</th><th>Value</th><th>Evolutions</th></tr></thead>';
    const tbody = el('tbody', '');
    vars.forEach(v => {
      const tr = el('tr', '');
      tr.innerHTML = `<td class="rec-var-name-cell">${v.name||v}</td><td class="rec-var-val" data-varname="${v.name||v}">${v.value||'—'}</td><td>${v.evolutions||0}</td>`;
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    detail.appendChild(table);
  } else {
    detail.appendChild(el('p', 'rec-hint', 'No variable data captured.'));
  }

  // Stdout preview
  if (r.stdout && r.stdout.trim()) {
    detail.appendChild(el('div', 'rec-detail-section-title', 'Output'));
    const pre = el('pre', 'rec-detail-pre', '');
    pre.textContent = r.stdout.slice(0, 2000) + (r.stdout.length > 2000 ? '\n…' : '');
    detail.appendChild(pre);
  }

  // Replay animation bar
  const replayBar = el('div', 'rec-replay-bar');
  replayBar.hidden = true;
  replayBar.innerHTML = '<span class="rec-replay-label">Replaying…</span><div class="rec-replay-track"><div class="rec-replay-fill"></div></div>';
  detail.appendChild(replayBar);

  card.appendChild(header);
  card.appendChild(detail);

  // ── Expand / collapse ──
  function toggle() {
    const expanded = card.dataset.expanded === 'true';
    card.dataset.expanded = expanded ? 'false' : 'true';
    header.setAttribute('aria-expanded', String(!expanded));
    chevron.textContent = expanded ? '▶' : '▼';
    detail.hidden = expanded;
    detail.setAttribute('aria-hidden', String(expanded));
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }});

  // ── Play replay ──
  playBtn.addEventListener('click', () => {
    if (!vars.length) { return; }
    replayBar.hidden = false;
    detail.hidden = false;
    card.dataset.expanded = 'true';
    header.setAttribute('aria-expanded', 'true');
    chevron.textContent = '▼';

    const fill = replayBar.querySelector('.rec-replay-fill');
    const valCells = detail.querySelectorAll('.rec-var-val');
    const steps = Math.max(vars.reduce((m,v) => Math.max(m, v.evolutions||0), 1), 1);
    let step = 0;
    fill.style.width = '0%';

    const interval = setInterval(() => {
      step++;
      fill.style.width = ((step / steps) * 100) + '%';
      // Animate each variable cell with a synthetic value progression
      valCells.forEach(cell => {
        const name = cell.dataset.varname;
        const v = vars.find(x => (x.name||x) === name);
        if (v && typeof v.value === 'number') {
          const animated = +(v.value * (step / steps)).toFixed(4);
          cell.textContent = String(animated);
          cell.classList.add('rec-var-animating');
        }
      });
      if (step >= steps) {
        clearInterval(interval);
        // Restore final values
        valCells.forEach(cell => {
          const name = cell.dataset.varname;
          const v = vars.find(x => (x.name||x) === name);
          if (v) cell.textContent = String(v.value || '—');
          cell.classList.remove('rec-var-animating');
        });
        setTimeout(() => { replayBar.hidden = true; }, 600);
      }
    }, Math.max(40, Math.round(1200 / steps)));
  });

  // ── Export ──
  exportBtn.addEventListener('click', () => {
    vscode.postMessage({ command: 'exportRecording', runId: card.dataset.runId, recording: r });
  });

  // ── Delete ──
  deleteBtn.addEventListener('click', () => {
    vscode.postMessage({ command: 'deleteRecording', runId: card.dataset.runId });
    card.style.opacity = '0.4';
    card.style.pointerEvents = 'none';
  });

  return card;
}

// ── Main render ───────────────────────────────────────────────────────────────

function render(data) {
  container.innerHTML = '';
  const { trackedFiles=[], vars=[], runs=[], recordings=[] } = data || {};

  // SECTION 1: Files — Tracked
  const s1 = el('div', 'rec-section');
  s1.innerHTML = '<div class="rec-section-header"><strong>Files</strong><span class="header-normal"> — Tracked</span></div>';
  if (trackedFiles.length === 0) {
    s1.appendChild(el('p', 'rec-hint', 'No tracked files yet. Press ▶ to run a Python or JS file.'));
  }
  trackedFiles.forEach(f => {
    const row = el('div', 'rec-row');
    row.style.cursor = 'pointer';
    row.innerHTML = `<span class="teal-check">&#10003;</span><span class="rec-filename">${f.name||(f.path||'').split('/').pop()}</span><span class="rec-filepath"> (${f.path})</span>`;
    row.addEventListener('click', () => vscode.postMessage({ command: 'openRunInspector' }));
    s1.appendChild(row);
  });
  s1.appendChild(el('p', 'rec-hint', 'Persisted in Vovle (.codevovle)'));
  container.appendChild(s1);

  // SECTION 2: Variables — Evolution
  const s2 = el('div', 'rec-section');
  s2.innerHTML = '<div class="rec-section-header"><strong>Variables</strong><span class="header-normal"> — Evolution</span></div>';
  vars.forEach(v => {
    const row = el('div', 'rec-row');
    row.style.cursor = 'pointer';
    const name = typeof v === 'string' ? v : (v.name || v);
    const count = v.evolutions || v.match_count || 0;
    row.innerHTML = `<span class="rec-var-name">${name}</span><span class="rec-count">evolutions: ${count}</span>`;
    row.addEventListener('click', () => vscode.postMessage({ command: 'openVariableInspector' }));
    s2.appendChild(row);
  });
  if (!vars.length) s2.appendChild(el('p', 'rec-hint', 'No variable evolutions recorded.'));
  s2.appendChild(el('p', 'rec-hint', 'Updates when variables change across runs'));
  container.appendChild(s2);

  // SECTION 3: Runs — Interactive recording cards driven from JSON
  const s3 = el('div', 'rec-section');
  s3.innerHTML = '<div class="rec-section-header"><strong>Runs</strong><span class="header-normal"> — Recordings</span></div>';

  // Merge runs + recordings arrays; prefer recordings (richer data)
  const allRuns = [
    ...recordings,
    ...runs.filter(r => !recordings.find(rec => rec.runId === `run-${r.run_id}`))
  ];

  if (allRuns.length === 0) {
    s3.appendChild(el('p', 'rec-hint', 'No runs recorded yet. Press ▶ to start.'));
  }
  allRuns.forEach(r => s3.appendChild(buildRecordingCard(r)));
  container.appendChild(s3);
}

// ── Message handler ───────────────────────────────────────────────────────────

window.addEventListener('message', evt => {
  const msg = evt.data;

  if (msg.command === 'setData') {
    clearRunLog();
    render(msg);
    return;
  }

  if (msg.command === 'run.event') {
    if (msg.type === 'run.start') {
      clearRunLog();
      ensureRunLog();
      appendRunLog('▶ Starting run: ' + msg.data + '\n');
    } else if (msg.type === 'run.stdout') {
      appendRunLog(msg.data);
    } else if (msg.type === 'run.stderr') {
      appendRunLog('[stderr] ' + msg.data);
    } else if (msg.type === 'run.done') {
      appendRunLog('\n✓ Run complete\n');
      // Refresh recordings list
      vscode.postMessage({ command: 'ready' });
    } else if (msg.type === 'run.error') {
      appendRunLog('\n✗ Error: ' + msg.data + '\n');
    }
    return;
  }

  if (msg.command === 'recordingDeleted') {
    vscode.postMessage({ command: 'ready' });
    return;
  }
});

vscode.postMessage({ command: 'ready' });
render(null);
})();
