import * as vscode from 'vscode';
import * as cp from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

export interface GlueResponse {
    id: string;
    success: boolean;
    result?: any;
    error?: string;
}

export interface SpawnRunOptions {
    filePath: string;
    extPath: string;
    language: 'python' | 'javascript';
    onStdout?: (chunk: string) => void;
    onStderr?: (chunk: string) => void;
}

export interface RunResult {
    runId: string;
    filePath: string;
    language: string;
    exitCode: number;
    recordingPath: string;
    timestamp: string;
    durationMs: number;
    useWatcher: boolean;
}

/**
 * GlueBridge: Persistent child process bridge to the Python glue adapter.
 * Sends JSON commands to stdin, reads JSON responses from stdout.
 *
 * Also provides spawnRun() which directly spawns the watcher CLI for
 * Python/JS files — watcher is the single path for all tracked runs.
 * No codevovle references remain in any run path.
 */
export class GlueBridge {
    private _proc: cp.ChildProcess | null = null;
    private _pending = new Map<string, (res: GlueResponse) => void>();
    private _buf = '';
    private _extensionPath: string;

    constructor(extensionPath: string) {
        this._extensionPath = extensionPath;
    }

    private _spawn() {
        if (this._proc) return;
        const adapterPath = path.join(this._extensionPath, 'glue', 'adapter.py');
        const pythonPath = [
            this._extensionPath,
            path.join(this._extensionPath, 'CodeVovle')
        ].join(path.delimiter);

        this._proc = cp.spawn('python3', [adapterPath], {
            cwd: this._extensionPath,
            env: { ...process.env, PYTHONPATH: pythonPath }
        });

        this._proc.stdout?.on('data', (chunk: Buffer) => {
            this._buf += chunk.toString();
            let nl: number;
            while ((nl = this._buf.indexOf('\n')) !== -1) {
                const line = this._buf.slice(0, nl).trim();
                this._buf = this._buf.slice(nl + 1);
                if (!line) continue;
                try {
                    const res: GlueResponse = JSON.parse(line);
                    const cb = this._pending.get(res.id);
                    if (cb) {
                        this._pending.delete(res.id);
                        cb(res);
                    }
                } catch (_) {}
            }
        });

        this._proc.on('exit', () => {
            this._proc = null;
            for (const [, cb] of this._pending) {
                cb({ id: '', success: false, error: 'Bridge process exited' });
            }
            this._pending.clear();
        });

        this._proc.stderr?.on('data', (_chunk: Buffer) => {
            // swallow stderr — python tracebacks are debug-only
        });
    }

    send(command: string, args: Record<string, any> = {}): Promise<any> {
        return new Promise((resolve, reject) => {
            this._spawn();
            const id = Math.random().toString(36).slice(2);
            const msg = JSON.stringify({ id, command, ...args }) + '\n';

            this._pending.set(id, (res) => {
                if (res.success) resolve(res.result);
                else reject(new Error(res.error || 'Glue error'));
            });

            try {
                this._proc?.stdin?.write(msg);
            } catch (e) {
                this._pending.delete(id);
                reject(e);
            }
        });
    }

    /**
     * Spawn a watcher-tracked run for a Python or JavaScript file.
     *
     * - Python:     python3 -m watcher.cli --user-script <file>
     * - JavaScript: node <watcher-js-adapter> <file>
     *
     * stdout/stderr are streamed to onStdout/onStderr callbacks and
     * a recording JSON is written to built/recordings/<runId>.json.
     *
     * Never invokes codevovle. useWatcher is always true for .py/.js.
     */
    async spawnRun(opts: SpawnRunOptions): Promise<RunResult> {
        const { filePath, extPath, language, onStdout, onStderr } = opts;
        const runId = `run-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const timestamp = new Date().toISOString();
        const startMs = Date.now();

        const recordingsDir = path.join(extPath, 'built', 'recordings');
        fs.mkdirSync(recordingsDir, { recursive: true });
        const recordingPath = path.join(recordingsDir, `${runId}.json`);

        const pythonPath = [extPath, path.join(extPath, 'watcher')].join(path.delimiter);

        let proc: cp.ChildProcess;

        if (language === 'python') {
            // Use watcher CLI: python3 -m watcher.cli --user-script <file>
            proc = cp.spawn('python3', [
                '-m', 'watcher.cli',
                '--user-script', filePath,
                '--output', path.join(recordingsDir, runId),
                '--log-level', 'INFO',
            ], {
                cwd: extPath,
                env: { ...process.env, PYTHONPATH: pythonPath },
            });
        } else {
            // JavaScript: use watcher JS adapter if present, else plain node
            const jsAdapterPath = path.join(extPath, 'watcher', 'adapters', 'javascript', 'index.js');
            if (fs.existsSync(jsAdapterPath)) {
                proc = cp.spawn('node', [jsAdapterPath, filePath], {
                    cwd: extPath,
                    env: { ...process.env },
                });
            } else {
                proc = cp.spawn('node', [filePath], {
                    cwd: extPath,
                    env: { ...process.env },
                });
            }
        }

        const stdout: string[] = [];
        const stderr: string[] = [];

        proc.stdout?.on('data', (chunk: Buffer) => {
            const s = chunk.toString();
            stdout.push(s);
            onStdout?.(s);
        });

        proc.stderr?.on('data', (chunk: Buffer) => {
            const s = chunk.toString();
            stderr.push(s);
            onStderr?.(s);
        });

        const exitCode = await new Promise<number>((resolve) => {
            proc.on('close', (code) => resolve(code ?? 0));
            proc.on('error', () => resolve(1));
        });

        const durationMs = Date.now() - startMs;

        // Build and persist the recording JSON
        const recording: RunResult & { stdout: string; stderr: string } = {
            runId,
            filePath,
            language,
            exitCode,
            recordingPath,
            timestamp,
            durationMs,
            useWatcher: true,
            stdout: stdout.join(''),
            stderr: stderr.join(''),
        };

        fs.writeFileSync(recordingPath, JSON.stringify(recording, null, 2));

        // Also save via glue adapter so the recordings panel can find it
        this.send('saveRecording', { runId, recordingPath, filePath, timestamp, durationMs, exitCode })
            .catch(() => {}); // non-fatal

        return recording;
    }

    dispose() {
        this._proc?.kill();
        this._proc = null;
    }
}

