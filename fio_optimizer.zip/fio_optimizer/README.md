# fio_optimizer

Background cross-filesystem storage optimizer for FIO7 files (separate module
from your `fast_io`/`fio7` storage module — `store()`/`load()` are untouched).

## Build

```bash
pip install setuptools --break-system-packages   # or a venv
python3 setup.py build_ext --inplace
```

Produces `fio_optimizer.cpython-*.so`, importable directly.

## Python API

```python
import fio_optimizer

fio_optimizer.optimize(directory, *, cpu_percent=10, io_priority=7,
                        min_size=1 << 20, recursive=True, skip_optimized=True)
fio_optimizer.optimizer_status()   # -> dict, see fields below
fio_optimizer.stop_optimization()  # requests stop, blocks until the worker exits
```

`optimize()` returns immediately; it starts one background thread. Call it
again while a run is active and it raises `RuntimeError` (call
`stop_optimization()` first).

`optimizer_status()` returns: `filesystem`, `backend`, `capabilities`
(`native_compression`/`native_dedup`/`cow_clone`/`sparse_holes`/
`volume_dedup_seen`), `files_examined/changed/skipped`,
`logical_bytes_examined`, `physical_bytes_before/after`,
`physical_bytes_saved` (measured, never estimated), `compression_saved_bytes`,
`shared_bytes`, `cpu_time_s`, `wall_time_s`, `last_error`, `state`
(`idle`/`running`/`stopped`/`done`).

## What's implemented, per backend

| Backend | Mechanism | Build status |
|---|---|---|
| **Btrfs** | zstd compression via `BTRFS_IOC_DEFRAG_RANGE`, extent dedup via generic `FIDEDUPERANGE` | Compiles here; **not runtime-tested** — this sandbox has no Btrfs kernel module/`mkfs.btrfs` available |
| **ext4** | zero-range hole punching via `FALLOC_FL_PUNCH_HOLE` | **Compiled and runtime-tested** in this sandbox (see below) |
| **NTFS** | per-file compression (`FSCTL_SET_COMPRESSION`), Data Deduplication detection | Written from Win32 docs; **only compiles under `_WIN32`**, never built or run (no Windows host available) — treat as a first draft, and note the sparse zero-range half is stubbed with a comment pointing at the ext4 algorithm to port |
| **APFS** | exact-duplicate CoW clone via `clonefile()` | Written from Apple docs; **only compiles under `__APPLE__`**, never built or run (no macOS host available) — the optional "similar files, patch differing ranges" path is intentionally left unimplemented (no stable public partial-clone API to do it safely) |

The common pieces (filesystem detection, candidate scan, fingerprint +
mandatory exact-byte verification, incremental state file, cpu/io
throttling, atomic-commit discipline, reporting) are shared by all four and
are what actually got exercised end-to-end.

## What I actually verified (ext4, this sandbox)

- A file with a 2 MiB all-zero region: physical allocation dropped from
  4 MiB to 2 MiB; **logical bytes read back byte-for-byte identical**.
- An exact duplicate of that file processed alongside it: both optimized
  independently, remain **separate inodes** (no hard-linking, per spec).
- Re-running `optimize()` on an already-optimized directory: second run
  skips every file (`files_changed: 0`) — the state file makes repeat runs
  cheap.
- `optimizer_status()` while idle, `stop_optimization()` on an idle
  controller, and process exit with the singleton's background thread
  properly joined (no `std::terminate`).

Two real bugs surfaced and got fixed during this testing (not left as
theoretical concerns):
1. `fallocate(PUNCH_HOLE)` bumps `mtime` on this kernel, which broke a
   naive "re-check identity before every commit" — fixed to verify once per
   file-level commit rather than once per block.
2. The state file must record the *post-optimization* mtime, or every
   future run sees a "changed" file (caused by the optimizer's own previous
   run) and redoes the work forever.

## Known gaps / next steps if you want the untested backends hardened

- NTFS: the sparse zero-range half isn't filled in (see comment in
  `windows_backend.hpp`); Data Deduplication detection is a coarse proxy,
  not a real policy query.
- Test both on real Windows/macOS hosts before pointing them at real data —
  I said this plainly rather than quietly shipping unverified I/O code as
  if it were equally trustworthy to the ext4 path.
