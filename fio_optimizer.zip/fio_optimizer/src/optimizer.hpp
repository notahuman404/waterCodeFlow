// optimizer.hpp
// Ties backend selection, throttling, and reporting together behind the
// three functions the spec asks for: optimize(), optimizer_status(),
// stop_optimization(). Only one optimization run is active at a time.
#pragma once

#include <chrono>
#include <ctime>
#include <memory>

#include "backend.hpp"
#include "common.hpp"
#if defined(__linux__)
  #include "linux_backends.hpp"
#elif defined(_WIN32)
  #include "windows_backend.hpp"
#elif defined(__APPLE__)
  #include "macos_backend.hpp"
#endif

namespace fopt {

inline std::unique_ptr<Backend> select_backend(FsKind kind) {
    switch (kind) {
#if defined(__linux__)
        case FsKind::BTRFS: return std::make_unique<BtrfsBackend>();
        case FsKind::EXT4:  return std::make_unique<Ext4Backend>();
#elif defined(_WIN32)
        case FsKind::NTFS:  return std::make_unique<NtfsBackend>();
#elif defined(__APPLE__)
        case FsKind::APFS:  return std::make_unique<ApfsBackend>();
#endif
        default: return nullptr;
    }
}

class OptimizerController {
public:
    static OptimizerController& instance() {
        static OptimizerController inst;
        return inst;
    }

    // Returns an error string, or empty on success. Never blocks; the
    // background thread does the actual work (spec: "optimize() returns
    // immediately").
    std::string start(const Options& opts) {
        std::lock_guard<std::mutex> lock(control_mtx_);
        if (running_.load()) {
            return "an optimization run is already in progress; call stop_optimization() first";
        }

        FsKind kind = detect_filesystem(opts.directory);
        auto backend = select_backend(kind);

        report_ = Report{}; // fresh report per run
        report_.filesystem = fs_kind_name(kind);

        if (!backend) {
            report_.state = "done";
            report_.last_error = std::string("no supported native optimizer backend for filesystem '") +
                                  fs_kind_name(kind) + "' on this platform";
            return {}; // not a hard error: spec says "leave the file alone" when no native path exists
        }

        report_.backend = backend->name();
        report_.caps = backend->capabilities();
        report_.state = "running";

        stop_flag_.store(false);
        running_.store(true);

        if (worker_.joinable()) worker_.join();
        worker_ = std::thread([this, opts, backend = std::move(backend)]() mutable {
            run(opts, std::move(backend));
        });
        return {};
    }

    Report status() {
        std::lock_guard<std::mutex> lock(control_mtx_);
        return report_.copy();
    }

    void stop() {
        stop_flag_.store(true);
        std::thread::id this_id = std::this_thread::get_id();
        if (worker_.joinable() && worker_.get_id() != this_id) {
            worker_.join();
        }
    }

    ~OptimizerController() {
        // A joinable std::thread that outlives its destructor calls
        // std::terminate; make sure process/interpreter shutdown can never
        // hit that even if the caller never called stop_optimization().
        stop_flag_.store(true);
        if (worker_.joinable()) worker_.join();
    }

private:
    void run(const Options& opts, std::unique_ptr<Backend> backend) {
        auto wall_start = std::chrono::steady_clock::now();
        std::clock_t cpu_start = std::clock();

        StateStore state(opts.directory);
        Throttle throttle(opts.cpu_percent);
#if defined(__linux__)
        apply_io_priority(opts.io_priority);
#endif

        try {
            backend->optimize_directory(opts, state, report_, stop_flag_, throttle);
        } catch (const std::exception& e) {
            std::lock_guard<std::mutex> lock(report_.mtx);
            report_.last_error = e.what();
        }

        state.flush();

        double wall_s = std::chrono::duration<double>(
                            std::chrono::steady_clock::now() - wall_start)
                            .count();
        double cpu_s = static_cast<double>(std::clock() - cpu_start) / CLOCKS_PER_SEC;

        {
            std::lock_guard<std::mutex> lock(report_.mtx);
            report_.wall_time_s = wall_s;
            report_.cpu_time_s = cpu_s;
            report_.state = stop_flag_.load() ? "stopped" : "done";
        }
        running_.store(false);
    }

    std::mutex control_mtx_;
    std::thread worker_;
    std::atomic<bool> running_{false};
    std::atomic<bool> stop_flag_{false};
    Report report_;
};

} // namespace fopt
