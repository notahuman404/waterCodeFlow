// linux_backends.hpp
// Btrfs and ext4 backends. These are the two backends actually compiled and
// exercised in a Linux CI/sandbox environment.
#pragma once
#if defined(__linux__)

#include <cmath>
#include <cstring>
#include <fcntl.h>
#include <map>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <linux/btrfs.h>
#include <linux/fs.h>
#include <linux/magic.h>

#include "backend.hpp"
#include "common.hpp"

namespace fopt {

namespace detail {

constexpr uint32_t BTRFS_COMPRESS_NONE = 0;
constexpr uint32_t BTRFS_COMPRESS_ZSTD = 3;

// Rough Shannon-entropy estimate over a sample, in bits/byte (0..8). Used
// only to skip compression attempts on data that is already compressed or
// encrypted, so repeated runs don't keep re-trying futile work.
inline double sample_entropy(const std::string& path, uint64_t size) {
    int fd = open(path.c_str(), O_RDONLY);
    if (fd < 0) return 8.0; // assume incompressible if unreadable
    constexpr size_t SAMPLE = 65536;
    std::vector<unsigned char> buf(std::min<uint64_t>(SAMPLE, size));
    ssize_t n = pread(fd, buf.data(), buf.size(), 0);
    close(fd);
    if (n <= 0) return 8.0;
    uint64_t freq[256] = {0};
    for (ssize_t i = 0; i < n; ++i) freq[buf[i]]++;
    double h = 0.0;
    for (int i = 0; i < 256; ++i) {
        if (!freq[i]) continue;
        double p = static_cast<double>(freq[i]) / n;
        h -= p * std::log2(p);
    }
    return h;
}

inline bool dedupe_whole_file(int src_fd, int dst_fd, uint64_t length) {
    std::vector<char> raw(sizeof(file_dedupe_range) + sizeof(file_dedupe_range_info));
    auto* args = reinterpret_cast<file_dedupe_range*>(raw.data());
    args->src_offset = 0;
    args->src_length = length;
    args->dest_count = 1;
    args->reserved1 = 0;
    args->reserved2 = 0;
    args->info[0].dest_fd = dst_fd;
    args->info[0].dest_offset = 0;
    args->info[0].bytes_deduped = 0;
    args->info[0].status = 0;
    if (ioctl(src_fd, FIDEDUPERANGE, args) != 0) return false;
    return args->info[0].status == FILE_DEDUPE_RANGE_SAME &&
           args->info[0].bytes_deduped == length;
}

// Some in-place physical-layout operations (defrag-with-compress, dedupe)
// bump mtime as a side effect on some kernels. Re-stat after committing so
// the state file records what we actually did, not the pre-commit mtime --
// otherwise every later run would see a "changed" file forever and redo
// the work every time (defeats "repeated runs incremental and cheap").
inline int64_t current_mtime_ns(const std::string& path, int64_t fallback) {
    struct stat st;
    if (stat(path.c_str(), &st) != 0) return fallback;
    return static_cast<int64_t>(st.st_mtim.tv_sec) * 1000000000ll + st.st_mtim.tv_nsec;
}

} // namespace detail

class BtrfsBackend : public Backend {
public:
    const char* name() const override { return "btrfs-native"; }
    BackendCaps capabilities() const override {
        BackendCaps c;
        c.native_compression = true;
        c.native_dedup = true;
        return c;
    }

    void optimize_directory(const Options& opts, StateStore& state, Report& report,
                             std::atomic<bool>& stop_flag, Throttle& throttle) override {
        // Group candidates by (dev, size, fast fingerprint). A group with
        // more than one member is a dedup *candidate* set; every member is
        // still exact-byte-verified before anything is shared.
        std::map<std::string, std::vector<FileCandidate>> groups;

        walk_directory(opts.directory, opts.recursive, [&](const std::string& path) {
            if (stop_flag.load()) return;
            throttle.maybe_pause(stop_flag);

            struct stat st;
            if (stat(path.c_str(), &st) != 0) return;
            if (static_cast<uint64_t>(st.st_size) < opts.min_size) return;

            int64_t mtime_ns = static_cast<int64_t>(st.st_mtim.tv_sec) * 1000000000ll + st.st_mtim.tv_nsec;
            {
                std::lock_guard<std::mutex> lock(report.mtx);
                report.files_examined++;
                report.logical_bytes_examined += st.st_size;
                uint64_t alloc = physical_allocation(path);
                report.physical_bytes_before += alloc;
                report.physical_bytes_after += alloc; // reduced later on real savings
            }

            if (opts.skip_optimized &&
                state.already_done(st.st_dev, st.st_ino, st.st_size, mtime_ns)) {
                std::lock_guard<std::mutex> lock(report.mtx);
                report.files_skipped++;
                return;
            }

            FileCandidate c;
            c.path = path;
            c.dev = st.st_dev;
            c.ino = st.st_ino;
            c.size = st.st_size;
            c.mtime_ns = mtime_ns;

            // Fast fingerprint: size is part of the key already; hash a
            // head+tail sample so we don't read whole large files twice.
            int fd = open(path.c_str(), O_RDONLY);
            if (fd < 0) return;
            constexpr size_t SAMPLE = 65536;
            std::vector<unsigned char> head(std::min<uint64_t>(SAMPLE, c.size));
            if (pread(fd, head.data(), head.size(), 0) < 0) { /* best-effort */ }
            uint64_t h = fnv1a(head.data(), head.size());
            if (c.size > SAMPLE) {
                std::vector<unsigned char> tail(std::min<uint64_t>(SAMPLE, c.size));
                if (pread(fd, tail.data(), tail.size(),
                          static_cast<off_t>(c.size - tail.size())) < 0) { /* best-effort */ }
                h = fnv1a(tail.data(), tail.size(), h);
            }
            close(fd);
            c.fast_fp = h;

            char key[64];
            std::snprintf(key, sizeof(key), "%llu:%llu:%016llx",
                          static_cast<unsigned long long>(c.dev),
                          static_cast<unsigned long long>(c.size),
                          static_cast<unsigned long long>(c.fast_fp));
            groups[key].push_back(std::move(c));
        });

        for (auto& kv : groups) {
            if (stop_flag.load()) break;
            auto& members = kv.second;

            // --- Dedup path: shrink physical usage of exact duplicates ---
            std::vector<bool> deduped(members.size(), false);
            if (members.size() > 1) {
                for (size_t i = 1; i < members.size(); ++i) {
                    if (stop_flag.load()) break;
                    throttle.maybe_pause(stop_flag);
                    const auto& src = members[0];
                    const auto& dst = members[i];
                    if (!files_byte_identical(src.path, dst.path, src.size)) continue;

                    // Re-check identity of both files immediately before commit.
                    if (!identity_unchanged(src.path, src.dev, src.ino, src.size, src.mtime_ns) ||
                        !identity_unchanged(dst.path, dst.dev, dst.ino, dst.size, dst.mtime_ns))
                        continue;

                    int src_fd = open(src.path.c_str(), O_RDONLY);
                    int dst_fd = open(dst.path.c_str(), O_RDWR);
                    bool ok = false;
                    if (src_fd >= 0 && dst_fd >= 0) {
                        uint64_t before = physical_allocation(dst.path);
                        ok = detail::dedupe_whole_file(src_fd, dst_fd, dst.size);
                        if (ok) {
                            uint64_t after = physical_allocation(dst.path);
                            std::lock_guard<std::mutex> lock(report.mtx);
                            report.shared_bytes += dst.size;
                            if (before > after) report.physical_bytes_after -= (before - after);
                        }
                    }
                    if (src_fd >= 0) close(src_fd);
                    if (dst_fd >= 0) close(dst_fd);

                    if (ok) {
                        deduped[i] = true;
                        state.mark(dst.dev, dst.ino, dst.size,
                                   detail::current_mtime_ns(dst.path, dst.mtime_ns), 0);
                        std::lock_guard<std::mutex> lock(report.mtx);
                        report.files_changed++;
                    }
                }
            }

            // --- Compression path: skip files just deduped (spec: don't
            // defrag/recompress shared files, it breaks extent sharing) ---
            for (size_t i = 0; i < members.size(); ++i) {
                if (stop_flag.load()) break;
                if (deduped[i]) continue;
                throttle.maybe_pause(stop_flag);
                const auto& f = members[i];

                double entropy = detail::sample_entropy(f.path, f.size);
                if (entropy > 7.5) { // already compressed/encrypted/random
                    state.mark(f.dev, f.ino, f.size, f.mtime_ns, 1);
                    std::lock_guard<std::mutex> lock(report.mtx);
                    report.files_skipped++;
                    continue;
                }

                if (!identity_unchanged(f.path, f.dev, f.ino, f.size, f.mtime_ns)) continue;

                int fd = open(f.path.c_str(), O_RDWR);
                if (fd < 0) continue;
                long flags = 0;
                ioctl(fd, FS_IOC_GETFLAGS, &flags);
                flags |= FS_COMPR_FL;
                ioctl(fd, FS_IOC_SETFLAGS, &flags);

                btrfs_ioctl_defrag_range_args dargs{};
                dargs.start = 0;
                dargs.len = static_cast<uint64_t>(-1);
                dargs.flags = BTRFS_DEFRAG_RANGE_COMPRESS;
                dargs.compress_type = detail::BTRFS_COMPRESS_ZSTD;

                uint64_t before = physical_allocation(f.path);
                bool ok = ioctl(fd, BTRFS_IOC_DEFRAG_RANGE, &dargs) == 0;
                close(fd);

                if (ok) {
                    uint64_t after = physical_allocation(f.path);
                    std::lock_guard<std::mutex> lock(report.mtx);
                    if (before > after) {
                        report.compression_saved_bytes += (before - after);
                        report.physical_bytes_after -= (before - after);
                    }
                    report.files_changed++;
                    state.mark(f.dev, f.ino, f.size, detail::current_mtime_ns(f.path, f.mtime_ns), 0);
                } else {
                    std::lock_guard<std::mutex> lock(report.mtx);
                    report.last_error = "BTRFS_IOC_DEFRAG_RANGE failed on " + f.path +
                                         ": " + std::strerror(errno);
                    state.mark(f.dev, f.ino, f.size, f.mtime_ns, 1);
                }
            }
        }
    }
};

class Ext4Backend : public Backend {
public:
    const char* name() const override { return "ext4-sparse"; }
    BackendCaps capabilities() const override {
        BackendCaps c;
        c.sparse_holes = true;
        return c;
    }

    void optimize_directory(const Options& opts, StateStore& state, Report& report,
                             std::atomic<bool>& stop_flag, Throttle& throttle) override {
        walk_directory(opts.directory, opts.recursive, [&](const std::string& path) {
            if (stop_flag.load()) return;
            throttle.maybe_pause(stop_flag);

            struct stat st;
            if (stat(path.c_str(), &st) != 0) return;
            if (static_cast<uint64_t>(st.st_size) < opts.min_size) return;

            int64_t mtime_ns = static_cast<int64_t>(st.st_mtim.tv_sec) * 1000000000ll + st.st_mtim.tv_nsec;
            uint64_t before = physical_allocation(path);
            {
                std::lock_guard<std::mutex> lock(report.mtx);
                report.files_examined++;
                report.logical_bytes_examined += st.st_size;
                report.physical_bytes_before += before;
                report.physical_bytes_after += before; // reduced later on real savings
            }

            if (opts.skip_optimized &&
                state.already_done(st.st_dev, st.st_ino, st.st_size, mtime_ns)) {
                std::lock_guard<std::mutex> lock(report.mtx);
                report.files_skipped++;
                return;
            }

            int fd = open(path.c_str(), O_RDWR);
            if (fd < 0) {
                std::lock_guard<std::mutex> lock(report.mtx);
                report.files_skipped++;
                return;
            }

            long blksize = st.st_blksize > 0 ? st.st_blksize : 4096;
            uint64_t offset = 0;
            constexpr size_t BUF = 1 << 20;
            std::vector<unsigned char> buf(BUF);
            std::vector<unsigned char> zero_block(blksize, 0);
            std::vector<uint64_t> zero_offsets; // collected first, applied after one identity check

            while (offset < static_cast<uint64_t>(st.st_size) && !stop_flag.load()) {
                throttle.maybe_pause(stop_flag);
                size_t want = static_cast<size_t>(
                    std::min<uint64_t>(BUF, st.st_size - offset));
                ssize_t n = pread(fd, buf.data(), want, static_cast<off_t>(offset));
                if (n <= 0) break;

                // Scan for block-aligned all-zero runs within this chunk.
                // This is a read-only pass: nothing on disk is touched yet,
                // so the file's mtime cannot change out from under us here.
                uint64_t block_start = (offset / blksize) * blksize;
                for (uint64_t b = block_start; b + blksize <= offset + static_cast<uint64_t>(n);
                     b += blksize) {
                    if (b < offset) continue; // already covered in a previous chunk
                    size_t local = static_cast<size_t>(b - offset);
                    if (local + blksize > static_cast<size_t>(n)) break;
                    if (std::memcmp(buf.data() + local, zero_block.data(), blksize) == 0) {
                        zero_offsets.push_back(b);
                    }
                }
                offset += n;
            }

            uint64_t punched = 0;
            // Single identity re-check immediately before committing any
            // physical change (spec requirement) -- done once per file
            // rather than once per hole, because punching itself can bump
            // this filesystem's mtime, which would otherwise make every
            // punch after the first look like an external modification.
            if (!zero_offsets.empty() && !stop_flag.load() &&
                identity_unchanged(path, st.st_dev, st.st_ino, st.st_size, mtime_ns)) {
                for (uint64_t b : zero_offsets) {
                    if (stop_flag.load()) break;
                    throttle.maybe_pause(stop_flag);
                    if (fallocate(fd, FALLOC_FL_PUNCH_HOLE | FALLOC_FL_KEEP_SIZE,
                                  static_cast<off_t>(b), blksize) == 0) {
                        punched += blksize;
                    }
                }
            }
            close(fd);

            uint64_t after = physical_allocation(path);
            std::lock_guard<std::mutex> lock(report.mtx);
            if (punched > 0) {
                report.files_changed++;
                if (before > after) report.physical_bytes_after -= (before - after);
            } else {
                report.files_skipped++;
            }
            // Re-stat so the recorded mtime reflects what we just did, not
            // the pre-punch value -- otherwise every future run would see a
            // "changed" mtime (caused by our own fallocate calls) and never
            // treat this file as already optimized.
            struct stat post_st;
            int64_t recorded_mtime = mtime_ns;
            if (stat(path.c_str(), &post_st) == 0) {
                recorded_mtime = static_cast<int64_t>(post_st.st_mtim.tv_sec) * 1000000000ll +
                                 post_st.st_mtim.tv_nsec;
            }
            state.mark(st.st_dev, st.st_ino, st.st_size, recorded_mtime, 0);
        });
    }
};

} // namespace fopt

#endif // __linux__
