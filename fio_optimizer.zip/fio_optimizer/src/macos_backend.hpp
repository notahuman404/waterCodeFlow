// macos_backend.hpp
// APFS backend: copy-on-write file cloning for exact duplicates via
// clonefile(2). APFS has no general filesystem-level deduplication, so this
// backend only ever produces CoW clones, never a private chunk store.
//
// IMPORTANT: this file only compiles under __APPLE__ and has not been built
// or run anywhere in this project (no macOS host was available). It follows
// Apple's published clonefile()/APFS documentation as closely as possible,
// but treat it as a first draft to validate on real hardware before trusting
// it with real data.
#pragma once
#if defined(__APPLE__)

#include <map>
#include <sys/clonefile.h>
#include <sys/stat.h>
#include <unistd.h>

#include "backend.hpp"
#include "common.hpp"

namespace fopt {

class ApfsBackend : public Backend {
public:
    const char* name() const override { return "apfs-clone"; }
    BackendCaps capabilities() const override {
        BackendCaps c;
        c.cow_clone = true;
        return c;
    }

    void optimize_directory(const Options& opts, StateStore& state, Report& report,
                             std::atomic<bool>& stop_flag, Throttle& throttle) override {
        std::map<std::string, std::vector<FileCandidate>> groups;

        walk_directory(opts.directory, opts.recursive, [&](const std::string& path) {
            if (stop_flag.load()) return;
            throttle.maybe_pause(stop_flag);

            struct stat st;
            if (stat(path.c_str(), &st) != 0) return;
            if (static_cast<uint64_t>(st.st_size) < opts.min_size) return;

            int64_t mtime_ns = static_cast<int64_t>(st.st_mtimespec.tv_sec) * 1000000000ll +
                               st.st_mtimespec.tv_nsec;
            {
                std::lock_guard<std::mutex> lock(report.mtx);
                report.files_examined++;
                report.logical_bytes_examined += st.st_size;
                uint64_t alloc = static_cast<uint64_t>(st.st_blocks) * 512ull;
                report.physical_bytes_before += alloc;
                report.physical_bytes_after += alloc;
            }

            if (opts.skip_optimized &&
                state.already_done(st.st_dev, st.st_ino, st.st_size, mtime_ns)) {
                std::lock_guard<std::mutex> lock(report.mtx);
                report.files_skipped++;
                return;
            }

            FileCandidate c;
            c.path = path;
            c.dev = st.st_dev;
            c.ino = st.st_ino;
            c.size = st.st_size;
            c.mtime_ns = mtime_ns;

            int fd = open(path.c_str(), O_RDONLY);
            if (fd < 0) return;
            constexpr size_t SAMPLE = 65536;
            std::vector<unsigned char> head(std::min<uint64_t>(SAMPLE, c.size));
            if (pread(fd, head.data(), head.size(), 0) < 0) { /* best-effort */ }
            uint64_t h = fnv1a(head.data(), head.size());
            if (c.size > SAMPLE) {
                std::vector<unsigned char> tail(std::min<uint64_t>(SAMPLE, c.size));
                if (pread(fd, tail.data(), tail.size(),
                          static_cast<off_t>(c.size - tail.size())) < 0) { /* best-effort */ }
                h = fnv1a(tail.data(), tail.size(), h);
            }
            close(fd);
            c.fast_fp = h;

            char key[64];
            std::snprintf(key, sizeof(key), "%llu:%llu:%016llx",
                          static_cast<unsigned long long>(c.dev),
                          static_cast<unsigned long long>(c.size),
                          static_cast<unsigned long long>(c.fast_fp));
            groups[key].push_back(std::move(c));
        });

        for (auto& kv : groups) {
            if (stop_flag.load()) break;
            auto& members = kv.second;
            if (members.size() < 2) {
                for (auto& f : members) state.mark(f.dev, f.ino, f.size, f.mtime_ns, 1);
                continue;
            }

            const auto& src = members[0];
            for (size_t i = 1; i < members.size(); ++i) {
                if (stop_flag.load()) break;
                throttle.maybe_pause(stop_flag);
                const auto& dst = members[i];

                if (!files_byte_identical(src.path, dst.path, src.size)) continue;
                if (!identity_unchanged(src.path, src.dev, src.ino, src.size, src.mtime_ns) ||
                    !identity_unchanged(dst.path, dst.dev, dst.ino, dst.size, dst.mtime_ns))
                    continue;

                // clonefile() cannot target an existing path, so clone into a
                // temp sibling and atomically rename over the target -- the
                // target is never observable half-written (spec requirement).
                std::string tmp = dst.path + ".fio_optimizer_clone_tmp";
                unlink(tmp.c_str()); // best-effort clear of a stale temp
                uint64_t before = static_cast<uint64_t>(
                    [&] { struct stat s; return stat(dst.path.c_str(), &s) == 0 ? s.st_blocks : 0; }()) * 512ull;

                bool ok = clonefile(src.path.c_str(), tmp.c_str(), 0) == 0;
                if (ok) {
                    // Preserve the destination's mode; clonefile copies the
                    // source's metadata by default which is what we want for
                    // an interchangeable duplicate, but permissions of the
                    // original destination file take precedence if they
                    // differ, since FIO7 file semantics must stay unchanged.
                    struct stat dst_st;
                    if (stat(dst.path.c_str(), &dst_st) == 0) {
                        chmod(tmp.c_str(), dst_st.st_mode);
                    }
                    ok = rename(tmp.c_str(), dst.path.c_str()) == 0;
                }
                if (!ok) {
                    unlink(tmp.c_str());
                    continue;
                }

                struct stat after_st;
                uint64_t after = stat(dst.path.c_str(), &after_st) == 0
                                     ? static_cast<uint64_t>(after_st.st_blocks) * 512ull
                                     : before;

                std::lock_guard<std::mutex> lock(report.mtx);
                report.files_changed++;
                report.shared_bytes += dst.size;
                if (before > after) report.physical_bytes_after -= (before - after);
                state.mark(dst.dev, dst.ino, dst.size, dst.mtime_ns, 0);
            }
            state.mark(src.dev, src.ino, src.size, src.mtime_ns, 0);

            // "Sufficiently similar" clone-then-patch-differing-ranges (spec
            // section 4, second path) is intentionally not implemented: it
            // needs a stable public partial-block-clone primitive, which
            // clonefile()/fcntl(F_CLONE) do not expose for arbitrary byte
            // ranges as of this writing. Doing it unsafely (e.g. read-modify
            // -write with no CoW guarantee) would violate the mandatory
            // exact-verification-before-share rule, so it's left as a no-op
            // rather than guessed at.
        }
    }
};

} // namespace fopt

#endif // __APPLE__
