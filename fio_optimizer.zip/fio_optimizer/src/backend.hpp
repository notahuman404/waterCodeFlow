// backend.hpp
// Backend interface implemented per-filesystem, plus small helpers shared by
// every backend: throttling, physical-allocation measurement, and mandatory
// exact-byte verification before anything is ever shared/deduplicated.
#pragma once

#include <algorithm>
#include <atomic>
#include <cstdio>
#include <fstream>
#include <thread>
#include <vector>

#include "common.hpp"

#if !defined(_WIN32)
  #include <fcntl.h>
  #include <sys/stat.h>
  #include <unistd.h>
#endif
#if defined(__linux__)
  #include <sys/syscall.h>
#endif
#if defined(_WIN32)
  #include <windows.h>
#endif

namespace fopt {

// Cooperative throttle: sleeps a fraction of the time proportional to
// cpu_percent so the optimizer stays a low-priority background task.
// io_priority (0-7, higher = lower priority, matching Linux ioprio "best
// effort" class conventions) is applied once at thread start on Linux.
class Throttle {
public:
    explicit Throttle(int cpu_percent) {
        cpu_percent = std::max(1, std::min(100, cpu_percent));
        work_ms_ = 20;
        idle_ms_ = work_ms_ * (100 - cpu_percent) / std::max(1, cpu_percent);
        last_ = std::chrono::steady_clock::now();
    }

    // Call periodically from inside long-running loops.
    void maybe_pause(const std::atomic<bool>& stop_flag) {
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_).count();
        if (elapsed < work_ms_) return;
        last_ = now;
        if (idle_ms_ <= 0) return;
        auto slept = 0;
        while (slept < idle_ms_ && !stop_flag.load()) {
            auto step = std::min<int64_t>(50, idle_ms_ - slept);
            std::this_thread::sleep_for(std::chrono::milliseconds(step));
            slept += step;
        }
    }

private:
    int64_t work_ms_;
    int64_t idle_ms_;
    std::chrono::steady_clock::time_point last_;
};

#if defined(__linux__)
inline void apply_io_priority(int io_priority) {
    // ioprio_set(IOPRIO_WHO_PROCESS, 0, IOPRIO_PRIO_VALUE(IOPRIO_CLASS_BE, prio))
    // There's no glibc wrapper; use the raw syscall number for x86_64/aarch64.
    #if defined(__NR_ioprio_set)
    constexpr int IOPRIO_WHO_PROCESS = 1;
    constexpr int IOPRIO_CLASS_BE = 2;
    int prio = std::max(0, std::min(7, io_priority));
    int value = (IOPRIO_CLASS_BE << 13) | prio;
    syscall(__NR_ioprio_set, IOPRIO_WHO_PROCESS, 0, value);
    #else
    (void)io_priority;
    #endif
}
#else
inline void apply_io_priority(int) {}
#endif

// Exact byte-for-byte comparison. This is the mandatory verification step:
// a fingerprint match is only ever a *candidate*, never proof.
inline bool files_byte_identical(const std::string& a, const std::string& b, uint64_t expected_size) {
    std::ifstream fa(a, std::ios::binary);
    std::ifstream fb(b, std::ios::binary);
    if (!fa || !fb) return false;
    constexpr size_t BUF = 1 << 20;
    std::vector<char> ba(BUF), bb(BUF);
    uint64_t remaining = expected_size;
    while (remaining > 0) {
        size_t chunk = static_cast<size_t>(std::min<uint64_t>(BUF, remaining));
        fa.read(ba.data(), chunk);
        fb.read(bb.data(), chunk);
        if (static_cast<size_t>(fa.gcount()) != chunk || static_cast<size_t>(fb.gcount()) != chunk) return false;
        if (std::memcmp(ba.data(), bb.data(), chunk) != 0) return false;
        remaining -= chunk;
    }
    return true;
}

// Physical allocation in bytes, not logical size (spec requirement).
inline uint64_t physical_allocation(const std::string& path) {
#if defined(_WIN32)
    LARGE_INTEGER size{};
    HANDLE h = CreateFileA(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                           nullptr, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, nullptr);
    if (h == INVALID_HANDLE_VALUE) return 0;
    DWORD high = 0;
    DWORD low = GetCompressedFileSizeA(path.c_str(), &high);
    CloseHandle(h);
    if (low == INVALID_FILE_SIZE) return 0;
    return (static_cast<uint64_t>(high) << 32) | low;
#else
    struct stat st;
    if (stat(path.c_str(), &st) != 0) return 0;
    // st_blocks is always in 512-byte units per POSIX, regardless of the
    // filesystem's own block size.
    return static_cast<uint64_t>(st.st_blocks) * 512ull;
#endif
}

// Re-checks identity right before a physical change is committed, so a file
// that changed between scan and commit is never touched (spec requirement).
inline bool identity_unchanged(const std::string& path, uint64_t dev, uint64_t ino,
                                uint64_t size, int64_t mtime_ns) {
#if defined(_WIN32)
    (void)path; (void)dev; (void)ino; (void)size; (void)mtime_ns;
    return true; // best-effort placeholder; see NTFS backend note
#else
    struct stat st;
    if (stat(path.c_str(), &st) != 0) return false;
    int64_t cur_mtime_ns = static_cast<int64_t>(st.st_mtim.tv_sec) * 1000000000ll + st.st_mtim.tv_nsec;
    return static_cast<uint64_t>(st.st_dev) == dev &&
           static_cast<uint64_t>(st.st_ino) == ino &&
           static_cast<uint64_t>(st.st_size) == size &&
           cur_mtime_ns == mtime_ns;
#endif
}

// Every backend implements this. `optimize_directory` must never expose a
// partially-written replacement (always operate via atomic rename or
// in-place ioctls that the kernel guarantees are all-or-nothing).
class Backend {
public:
    virtual ~Backend() = default;
    virtual const char* name() const = 0;
    virtual BackendCaps capabilities() const = 0;
    virtual void optimize_directory(const Options& opts, StateStore& state,
                                     Report& report, std::atomic<bool>& stop_flag,
                                     Throttle& throttle) = 0;
};

} // namespace fopt
