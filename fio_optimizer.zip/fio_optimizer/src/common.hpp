// common.hpp
// Cross-platform pieces of the FIO7 storage optimizer: filesystem
// identification, candidate scanning, fast fingerprinting, and the small
// rebuildable state file that makes repeated runs incremental.
//
// Nothing here touches FIO7's store()/load() format. Everything operates on
// files strictly as opaque byte streams on disk.
#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <map>
#include <mutex>
#include <string>
#include <vector>

#include <sys/stat.h>
#if defined(_WIN32)
  #include <direct.h>
#else
  #include <dirent.h>
  #include <unistd.h>
#endif

namespace fopt {

// ---------------------------------------------------------------------
// Filesystem identity
// ---------------------------------------------------------------------

enum class FsKind { BTRFS, EXT4, NTFS, APFS, UNKNOWN };

inline const char* fs_kind_name(FsKind k) {
    switch (k) {
        case FsKind::BTRFS: return "btrfs";
        case FsKind::EXT4:  return "ext4";
        case FsKind::NTFS:  return "ntfs";
        case FsKind::APFS:  return "apfs";
        default:            return "unknown";
    }
}

struct BackendCaps {
    bool native_compression = false; // Btrfs zstd, NTFS per-file compression
    bool native_dedup       = false; // Btrfs/generic FIDEDUPERANGE
    bool cow_clone          = false; // APFS clonefile
    bool sparse_holes       = false; // ext4/NTFS hole punching
    bool volume_dedup_seen  = false; // e.g. Windows Data Deduplication already on
};

#if defined(__linux__)
  #include <sys/statfs.h>
  #include <linux/magic.h>
#elif defined(_WIN32)
  #include <windows.h>
#elif defined(__APPLE__)
  #include <sys/mount.h>
  #include <sys/param.h>
#endif

// Detect the filesystem actually backing `path` before doing anything
// expensive (spec: "Detect the filesystem and its actual supported
// features before expensive work").
inline FsKind detect_filesystem(const std::string& path) {
#if defined(__linux__)
    struct statfs sfs;
    if (statfs(path.c_str(), &sfs) != 0) return FsKind::UNKNOWN;
    switch (static_cast<long>(sfs.f_type)) {
        case 0x9123683E: return FsKind::BTRFS; // BTRFS_SUPER_MAGIC
        case 0xEF53:     return FsKind::EXT4;  // shared by ext2/3/4; ext4
                                                // specifics are re-checked
                                                // via feature probing below
        default:         return FsKind::UNKNOWN;
    }
#elif defined(_WIN32)
    char root[MAX_PATH];
    if (!GetVolumePathNameA(path.c_str(), root, MAX_PATH)) return FsKind::UNKNOWN;
    char fsName[MAX_PATH] = {0};
    if (!GetVolumeInformationA(root, nullptr, 0, nullptr, nullptr, nullptr, fsName, MAX_PATH))
        return FsKind::UNKNOWN;
    if (std::string(fsName) == "NTFS") return FsKind::NTFS;
    return FsKind::UNKNOWN;
#elif defined(__APPLE__)
    struct statfs sfs;
    if (statfs(path.c_str(), &sfs) != 0) return FsKind::UNKNOWN;
    if (std::string(sfs.f_fstypename) == "apfs") return FsKind::APFS;
    return FsKind::UNKNOWN;
#else
    (void)path;
    return FsKind::UNKNOWN;
#endif
}

// ---------------------------------------------------------------------
// Reporting (spec: "Required reporting")
// ---------------------------------------------------------------------

struct Report {
    std::mutex mtx;

    Report() = default;
    Report(const Report&) = delete;
    Report& operator=(const Report&) = delete;
    // A mutex can't be moved; a moved-from/moved-to Report just gets a fresh
    // one of its own (nothing meaningful to transfer -- only the data below
    // needs to travel). This is what lets copy()/start() return/replace a
    // Report by value despite the mutex member.
    Report(Report&& other) noexcept { assign_from(other); }
    Report& operator=(Report&& other) noexcept { assign_from(other); return *this; }

    std::string filesystem = "unknown";
    std::string backend = "none";
    BackendCaps caps;

    uint64_t files_examined = 0;
    uint64_t files_changed = 0;
    uint64_t files_skipped = 0;

    uint64_t logical_bytes_examined = 0;
    uint64_t physical_bytes_before = 0;
    uint64_t physical_bytes_after = 0;

    uint64_t compression_saved_bytes = 0;
    uint64_t shared_bytes = 0; // deduplicated/cloned bytes now shared

    double cpu_time_s = 0.0;
    double wall_time_s = 0.0;

    std::string last_error;
    std::string state; // "idle" | "running" | "stopping" | "done"

    // Snapshot copy (report is read from a different thread than the one
    // mutating it).
    Report copy() const {
        std::lock_guard<std::mutex> lock(const_cast<std::mutex&>(mtx));
        Report r;
        r.assign_from(*this);
        return r;
    }

    int64_t physical_bytes_saved() const {
        // Only ever computed from measured before/after; never a theoretical
        // estimate (spec: "Never report theoretical savings as actual").
        return static_cast<int64_t>(physical_bytes_before) -
               static_cast<int64_t>(physical_bytes_after);
    }

private:
    void assign_from(const Report& other) {
        filesystem = other.filesystem;
        backend = other.backend;
        caps = other.caps;
        files_examined = other.files_examined;
        files_changed = other.files_changed;
        files_skipped = other.files_skipped;
        logical_bytes_examined = other.logical_bytes_examined;
        physical_bytes_before = other.physical_bytes_before;
        physical_bytes_after = other.physical_bytes_after;
        compression_saved_bytes = other.compression_saved_bytes;
        shared_bytes = other.shared_bytes;
        cpu_time_s = other.cpu_time_s;
        wall_time_s = other.wall_time_s;
        last_error = other.last_error;
        state = other.state;
    }
};

// ---------------------------------------------------------------------
// Options
// ---------------------------------------------------------------------

struct Options {
    std::string directory;
    int cpu_percent = 10;
    int io_priority = 7;
    uint64_t min_size = 1ull << 20;
    bool recursive = true;
    bool skip_optimized = true;
};

// ---------------------------------------------------------------------
// Candidate file record
// ---------------------------------------------------------------------

struct FileCandidate {
    std::string path;
    uint64_t dev = 0;
    uint64_t ino = 0;
    uint64_t size = 0;
    int64_t mtime_ns = 0;
    uint64_t fast_fp = 0; // cheap fingerprint, NOT proof of equality
};

// FNV-1a 64-bit. Good enough as a *candidate* filter; every match is
// exact-byte-verified before anything physical is shared (spec requirement).
inline uint64_t fnv1a(const void* data, size_t len, uint64_t seed = 1469598103934665603ull) {
    const unsigned char* p = static_cast<const unsigned char*>(data);
    uint64_t h = seed;
    for (size_t i = 0; i < len; ++i) {
        h ^= p[i];
        h *= 1099511628211ull;
    }
    return h;
}

// ---------------------------------------------------------------------
// Directory walk (skips symlinks; that's an explicit non-goal exclusion).
// ---------------------------------------------------------------------

template <typename Fn>
void walk_directory(const std::string& root, bool recursive, Fn&& on_file) {
#if defined(_WIN32)
    // Best-effort Windows walk using FindFirstFile/FindNextFile.
    std::string pattern = root + "\\*";
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pattern.c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        std::string name = fd.cFileName;
        if (name == "." || name == "..") continue;
        std::string full = root + "\\" + name;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) {
            continue; // symlink/junction: skip, per spec
        }
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            if (recursive) walk_directory(full, recursive, on_file);
        } else {
            on_file(full);
        }
    } while (FindNextFileA(h, &fd));
    FindClose(h);
#else
    DIR* dir = opendir(root.c_str());
    if (!dir) return;
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        if (name == "." || name == "..") continue;
        std::string full = root + "/" + name;

        struct stat st;
        if (lstat(full.c_str(), &st) != 0) continue;
        if (S_ISLNK(st.st_mode)) continue; // never follow symlinks
        if (S_ISDIR(st.st_mode)) {
            if (recursive) walk_directory(full, recursive, on_file);
        } else if (S_ISREG(st.st_mode)) {
            on_file(full);
        }
    }
    closedir(dir);
#endif
}

// ---------------------------------------------------------------------
// Small rebuildable state file, kept inside the optimized directory.
//
// Format (little-endian, fixed-width, versioned):
//   magic "FOP1" | u32 record_count
//   records: u64 dev, u64 ino, u64 size, i64 mtime_ns, u8 status
// status: 0 = optimized-ok (skip unless changed), 1 = skipped-unsuitable
//
// This is intentionally NOT a chunk store / dedup index of its own: it is
// only used to avoid re-scanning unchanged files (spec: "repeated runs
// incremental and cheap"), never to decide what bytes to serve.
// ---------------------------------------------------------------------

struct StateRecord {
    uint64_t dev, ino, size;
    int64_t mtime_ns;
    uint8_t status;
};

class StateStore {
public:
    explicit StateStore(const std::string& directory)
        : path_(directory + "/.fio_optimizer_state") {
        load();
    }

    bool already_done(uint64_t dev, uint64_t ino, uint64_t size, int64_t mtime_ns) const {
        auto it = map_.find(key(dev, ino));
        if (it == map_.end()) return false;
        const StateRecord& r = it->second;
        return r.size == size && r.mtime_ns == mtime_ns && r.status == 0;
    }

    void mark(uint64_t dev, uint64_t ino, uint64_t size, int64_t mtime_ns, uint8_t status) {
        map_[key(dev, ino)] = StateRecord{dev, ino, size, mtime_ns, status};
        dirty_ = true;
    }

    void flush() {
        if (!dirty_) return;
        std::ofstream f(path_, std::ios::binary | std::ios::trunc);
        if (!f) return;
        f.write("FOP1", 4);
        uint32_t count = static_cast<uint32_t>(map_.size());
        f.write(reinterpret_cast<const char*>(&count), sizeof(count));
        for (auto& kv : map_) {
            const StateRecord& r = kv.second;
            f.write(reinterpret_cast<const char*>(&r.dev), sizeof(r.dev));
            f.write(reinterpret_cast<const char*>(&r.ino), sizeof(r.ino));
            f.write(reinterpret_cast<const char*>(&r.size), sizeof(r.size));
            f.write(reinterpret_cast<const char*>(&r.mtime_ns), sizeof(r.mtime_ns));
            f.write(reinterpret_cast<const char*>(&r.status), sizeof(r.status));
        }
        dirty_ = false;
    }

private:
    static uint64_t key(uint64_t dev, uint64_t ino) {
        return fnv1a(&dev, sizeof(dev), fnv1a(&ino, sizeof(ino)));
    }

    void load() {
        std::ifstream f(path_, std::ios::binary);
        if (!f) return;
        char magic[4];
        f.read(magic, 4);
        if (f.gcount() != 4 || std::memcmp(magic, "FOP1", 4) != 0) return;
        uint32_t count = 0;
        f.read(reinterpret_cast<char*>(&count), sizeof(count));
        for (uint32_t i = 0; i < count && f; ++i) {
            StateRecord r{};
            f.read(reinterpret_cast<char*>(&r.dev), sizeof(r.dev));
            f.read(reinterpret_cast<char*>(&r.ino), sizeof(r.ino));
            f.read(reinterpret_cast<char*>(&r.size), sizeof(r.size));
            f.read(reinterpret_cast<char*>(&r.mtime_ns), sizeof(r.mtime_ns));
            f.read(reinterpret_cast<char*>(&r.status), sizeof(r.status));
            if (!f) break;
            map_[key(r.dev, r.ino)] = r;
        }
    }

    std::string path_;
    std::map<uint64_t, StateRecord> map_;
    bool dirty_ = false;
};

} // namespace fopt
