// pymodule.cpp
// Python-facing surface for the FIO7 storage optimizer. Deliberately kept
// separate from the FIO7 storage module itself (fast_io.cpp / fio7): this
// extension only ever touches files after they already exist on disk, and
// never changes the FIO7 byte format, store(), or load().
#define PY_SSIZE_T_CLEAN
#include <Python.h>

#include "optimizer.hpp"

namespace {

PyObject* py_optimize(PyObject*, PyObject* args, PyObject* kwargs) {
    static const char* kwlist[] = {
        "directory", "cpu_percent", "io_priority", "min_size",
        "recursive", "skip_optimized", nullptr};

    const char* directory = nullptr;
    int cpu_percent = 10;
    int io_priority = 7;
    unsigned long long min_size = 1ull << 20;
    int recursive = 1;
    int skip_optimized = 1;

    if (!PyArg_ParseTupleAndKeywords(
            args, kwargs, "s|iiKpp", const_cast<char**>(kwlist),
            &directory, &cpu_percent, &io_priority, &min_size,
            &recursive, &skip_optimized)) {
        return nullptr;
    }

    fopt::Options opts;
    opts.directory = directory;
    opts.cpu_percent = cpu_percent;
    opts.io_priority = io_priority;
    opts.min_size = static_cast<uint64_t>(min_size);
    opts.recursive = recursive != 0;
    opts.skip_optimized = skip_optimized != 0;

    std::string err;
    {
        // Release the GIL for the (very brief) call that spins up the
        // background thread; the thread itself never touches Python objects.
        Py_BEGIN_ALLOW_THREADS
        err = fopt::OptimizerController::instance().start(opts);
        Py_END_ALLOW_THREADS
    }

    if (!err.empty()) {
        PyErr_SetString(PyExc_RuntimeError, err.c_str());
        return nullptr;
    }
    Py_RETURN_NONE;
}

PyObject* report_to_dict(const fopt::Report& r) {
    PyObject* d = PyDict_New();
    if (!d) return nullptr;

    auto set = [&](const char* key, PyObject* value) {
        if (!value) return;
        PyDict_SetItemString(d, key, value);
        Py_DECREF(value);
    };

    set("filesystem", PyUnicode_FromString(r.filesystem.c_str()));
    set("backend", PyUnicode_FromString(r.backend.c_str()));
    set("state", PyUnicode_FromString(r.state.c_str()));
    set("last_error", r.last_error.empty() ? (Py_INCREF(Py_None), Py_None)
                                            : PyUnicode_FromString(r.last_error.c_str()));

    PyObject* caps = PyDict_New();
    PyDict_SetItemString(caps, "native_compression", PyBool_FromLong(r.caps.native_compression));
    PyDict_SetItemString(caps, "native_dedup", PyBool_FromLong(r.caps.native_dedup));
    PyDict_SetItemString(caps, "cow_clone", PyBool_FromLong(r.caps.cow_clone));
    PyDict_SetItemString(caps, "sparse_holes", PyBool_FromLong(r.caps.sparse_holes));
    PyDict_SetItemString(caps, "volume_dedup_seen", PyBool_FromLong(r.caps.volume_dedup_seen));
    set("capabilities", caps);

    set("files_examined", PyLong_FromUnsignedLongLong(r.files_examined));
    set("files_changed", PyLong_FromUnsignedLongLong(r.files_changed));
    set("files_skipped", PyLong_FromUnsignedLongLong(r.files_skipped));
    set("logical_bytes_examined", PyLong_FromUnsignedLongLong(r.logical_bytes_examined));
    set("physical_bytes_before", PyLong_FromUnsignedLongLong(r.physical_bytes_before));
    set("physical_bytes_after", PyLong_FromUnsignedLongLong(r.physical_bytes_after));
    set("physical_bytes_saved", PyLong_FromLongLong(r.physical_bytes_saved()));
    set("compression_saved_bytes", PyLong_FromUnsignedLongLong(r.compression_saved_bytes));
    set("shared_bytes", PyLong_FromUnsignedLongLong(r.shared_bytes));
    set("cpu_time_s", PyFloat_FromDouble(r.cpu_time_s));
    set("wall_time_s", PyFloat_FromDouble(r.wall_time_s));

    return d;
}

PyObject* py_optimizer_status(PyObject*, PyObject*) {
    fopt::Report snapshot;
    Py_BEGIN_ALLOW_THREADS
    snapshot = fopt::OptimizerController::instance().status();
    Py_END_ALLOW_THREADS
    return report_to_dict(snapshot);
}

PyObject* py_stop_optimization(PyObject*, PyObject*) {
    Py_BEGIN_ALLOW_THREADS
    fopt::OptimizerController::instance().stop();
    Py_END_ALLOW_THREADS
    Py_RETURN_NONE;
}

PyMethodDef kMethods[] = {
    {"optimize", reinterpret_cast<PyCFunction>(py_optimize), METH_VARARGS | METH_KEYWORDS,
     "optimize(directory, *, cpu_percent=10, io_priority=7, min_size=1<<20, "
     "recursive=True, skip_optimized=True)\n\n"
     "Start a background pass that reduces the physical disk footprint of\n"
     "already-created FIO7 files under `directory`, using the strongest safe\n"
     "native filesystem mechanism available (Btrfs compression/dedup, ext4\n"
     "hole punching, NTFS compression/sparse, or APFS cloning). Returns\n"
     "immediately; use optimizer_status() to poll progress and\n"
     "stop_optimization() to cancel. Never modifies store()/load() behavior\n"
     "or the FIO7 byte format."},
    {"optimizer_status", py_optimizer_status, METH_NOARGS,
     "optimizer_status() -> dict\n\n"
     "Snapshot of the current or most recent optimization run: filesystem,\n"
     "backend, capabilities, files examined/changed/skipped, logical and\n"
     "physical byte counts, measured savings, and timing."},
    {"stop_optimization", py_stop_optimization, METH_NOARGS,
     "stop_optimization()\n\n"
     "Requests the current run stop as soon as it's safe to do so (never\n"
     "mid-commit) and blocks until the background thread has exited."},
    {nullptr, nullptr, 0, nullptr},
};

PyModuleDef kModule = {
    PyModuleDef_HEAD_INIT,
    "fio_optimizer",
    "Background cross-filesystem storage optimizer for FIO7 files.\n"
    "Separate from the fio7 storage module; store()/load() are untouched.",
    -1,
    kMethods,
};

} // namespace

PyMODINIT_FUNC PyInit_fio_optimizer() {
    return PyModule_Create(&kModule);
}
