from setuptools import setup, Extension

module = Extension(
    "fio_optimizer",
    sources=["src/pymodule.cpp"],
    include_dirs=["src"],
    extra_compile_args=["-std=c++17", "-O2", "-Wall"],
    extra_link_args=["-lpthread"],
)

setup(
    name="fio_optimizer",
    version="0.1.0",
    description="Background cross-filesystem storage optimizer for FIO7 files",
    ext_modules=[module],
)
